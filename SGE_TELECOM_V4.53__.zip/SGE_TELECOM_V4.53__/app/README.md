# SGE TELECOM V4.27 — pacote de revisão funcional

## Estrutura
A raiz contém apenas `app/`, `database/` e `public/`. Relatórios e arquivos históricos volumosos não fazem parte do pacote ativo.

## Principais alterações
- Identidade consistente SGE TELECOM.
- Migração aditiva `database/migracao_v4_26.sql` para configuração de módulos por perfil, notificações, leitura de publicações e avaliações por estrelas.
- Ecrã de configuração de perfis e módulos, com controlos no servidor.
- Área de notificações com alertas de documentos/licenças e equipamentos.
- Feed com indicador de publicações não lidas, apresentação de anexos por tipo e avaliação por estrelas persistida.
- Melhorias de layout no login e formulário de especialista.

## Instalação segura
1. Faça cópia de segurança da base de dados e da pasta `public/uploads/`.
2. Importe as migrações em ordem, conforme a versão da sua base: `database/migracao_v4_26.sql` e depois `database/migracao_v4_27.sql` (quantidades de equipamentos).
3. Confirme permissões, contas e âmbitos com contas de teste GLOBAL, RAMO, REGIAO e UNIDADE.
4. Teste criação/edição de utilizadores, feed, anexos, alertas e todos os formulários antes de produção.

## Segurança e limites
A interface esconde módulos sem acesso, mas a autorização de servidor continua a ser a fonte de verdade. A migração é aditiva e não elimina dados. Os alertas de validade usam `documentos.data_validade`; os prazos de licenças são apresentados com base em `licencas.data_fim`. Rever os nomes de tabelas/colunas se a base local divergir do esquema fornecido.


## Revisão V4.27
- Consulta de especialistas só apresenta resultados depois de uma pesquisa/filtro; ordenação por patente e nome mantida.
- Rótulo de estado corrigido, campos de nacionalidade limitados a Angolana, ajuda visual de conta/IBAN e botões de visualização de senha consistentes.
- Ajustes de alinhamento de formulários e comportamento de tabelas; eliminação de licença com verificação CSRF.
- Antes de produção, executar os testes funcionais descritos acima e validar em base de dados de cópia.

- Migração adicional V4.27: executar `database/migracao_v4_27.sql` para ativar quantidade total/distribuída e cálculo de stock nos equipamentos.
- O Feed permite eliminar publicações para perfis com permissão de gestão; os anexos associados são removidos do armazenamento.
