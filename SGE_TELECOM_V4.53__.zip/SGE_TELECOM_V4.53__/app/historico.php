<?php
/** Registo genérico de alterações nas tabelas de configuração. */
function registar_historico(PDO $pdo, string $tabela, int $id, string $acao, ?array $antes = null, ?array $depois = null): void
{
    try {
        $stmt = $pdo->prepare("INSERT INTO historico_configuracoes
            (tabela, id_registo, acao, dados_anteriores, dados_novos, id_utilizador)
            VALUES (:tabela, :id, :acao, :antes, :depois, :utilizador)");
        $uid = (int)($_SESSION['user']['id'] ?? 0);
        $stmt->execute([
            ':tabela' => $tabela,
            ':id' => $id,
            ':acao' => $acao,
            ':antes' => $antes === null ? null : json_encode($antes, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            ':depois' => $depois === null ? null : json_encode($depois, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            ':utilizador' => $uid > 0 ? $uid : null,
        ]);
        registar_auditoria($pdo,'CONFIGURACAO',$acao,'CONFIGURACOES',$tabela,$id,'Alteração de configuração: '.$tabela.' #'.$id,$antes,$depois);
    } catch (Throwable $e) {
        // O histórico não deve impedir uma operação válida de configuração.
    }
}

function registar_estado(PDO $pdo, string $tabela, string $pk, int $id, string $novoEstado): void
{
    $q = $pdo->prepare("SELECT * FROM `{$tabela}` WHERE `{$pk}` = ? LIMIT 1");
    $q->execute([$id]);
    $antes = $q->fetch(PDO::FETCH_ASSOC) ?: null;
    if (!$antes) return;
    $pdo->prepare("UPDATE `{$tabela}` SET estado=? WHERE `{$pk}`=?")->execute([$novoEstado, $id]);
    $depois = $antes;
    $depois['estado'] = $novoEstado;
    $acao = $novoEstado === 'INATIVO' ? 'INATIVACAO' : 'REACTIVACAO';
    registar_historico($pdo, $tabela, $id, $acao, $antes, $depois);
}

function registar_historico_especialista(PDO $pdo, int $idEspecialista, string $tipoEvento, string $campo='', ?string $anterior=null, ?string $novo=null, ?string $inicio=null, ?string $fim=null, ?int $idDocumento=null, ?string $motivo=null, ?string $observacoes=null): void
{
    try {
        $stmt=$pdo->prepare("INSERT INTO historico_especialistas (id_especialista,tipo_evento,campo,valor_anterior,valor_novo,data_inicio,data_fim,id_documento,motivo,observacoes,id_utilizador) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$idEspecialista,$tipoEvento,$campo?:null,$anterior,$novo,$inicio,$fim,$idDocumento,$motivo,$observacoes,current_user_id()?:null]);
        registar_auditoria($pdo,'ESPECIALISTAS','HISTORICO_CRIADO','ESPECIALISTAS','especialistas',$idEspecialista,'Registo de histórico: '.$tipoEvento);
    } catch (Throwable $e) { /* não bloquear a operação */ }
}

function registar_historico_equipamento(PDO $pdo, int $idEquipamento, string $evento, string $campo='', ?string $anterior=null, ?string $novo=null, ?string $motivo=null): void
{
    try {
        $pdo->prepare("INSERT INTO historico_equipamentos (id_equipamento,evento,campo,valor_anterior,valor_novo,motivo,id_utilizador) VALUES (?,?,?,?,?,?,?)")
            ->execute([$idEquipamento,$evento,$campo?:null,$anterior,$novo,$motivo,current_user_id()?:null]);
        registar_auditoria($pdo,'EQUIPAMENTOS','HISTORICO_CRIADO','EQUIPAMENTOS','equipamentos',$idEquipamento,'Histórico de equipamento: '.$evento);
    } catch (Throwable $e) { }
}
