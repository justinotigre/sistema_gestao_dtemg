<?php
require_once __DIR__.'/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/**
 * Autenticação central.
 * O perfil define as permissões e o nivel_acesso define o alcance.
 * O ramo/unidade associado ao utilizador é sempre validado no servidor.
 */

function csrf_token(): string {
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['_csrf_token'];
}

function csrf_verify_post(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') return;
    $sent = (string)($_POST['csrf_token'] ?? '');
    $expected = (string)($_SESSION['_csrf_token'] ?? '');
    if ($expected === '' || $sent === '' || !hash_equals($expected, $sent)) {
        http_response_code(419);
        exit('Sessão do formulário expirada ou inválida. Atualize a página e tente novamente.');
    }
}


function registar_auditoria(PDO $pdo, string $categoria, string $evento, string $modulo='', string $entidade='', ?int $idRegisto=null, string $descricao='', ?array $antes=null, ?array $depois=null, string $resultado='SUCESSO'): void {
    try {
        $uid = current_user_id();
        $pdo->prepare("INSERT INTO auditoria (id_utilizador,categoria,evento,modulo,entidade,id_registo,descricao,dados_anteriores,dados_novos,ip,user_agent,localizacao,resultado) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)")
            ->execute([
                $uid ?: null, $categoria, $evento, $modulo ?: null, $entidade ?: null, $idRegisto ?: null, $descricao ?: null,
                $antes === null ? null : json_encode($antes, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
                $depois === null ? null : json_encode($depois, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
                $_SERVER['REMOTE_ADDR'] ?? null, substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''),0,500), $_SERVER['HTTP_HOST'] ?? null, $resultado
            ]);
    } catch (Throwable $e) { /* auditoria nunca deve bloquear a operação principal */ }
}

function login_user(string $username, string $password): bool {
    $username = trim($username);
    if ($username === '' || $password === '') return false;

    $st = db()->prepare("
        SELECT
            u.*,
            p.nome AS perfil_nome,
            p.nivel_acesso AS perfil_nivel,
            p.estado AS perfil_estado
        FROM utilizadores u
        INNER JOIN perfis p ON p.id_perfil = u.id_perfil
        WHERE u.nome_utilizador = ?
          AND u.estado = 'ATIVO'
          AND p.estado = 'ATIVO'
        LIMIT 1
    ");
    $st->execute([$username]);
    $u = $st->fetch(PDO::FETCH_ASSOC);

    if (!$u || !password_verify($password, (string)$u['senha'])) {
        try { db()->prepare("INSERT INTO auditoria (categoria,evento,modulo,descricao,ip,user_agent,localizacao,resultado) VALUES ('AUTENTICACAO','LOGIN_FALHADO','LOGIN',?,?,?,?,?)")->execute(['Tentativa de login: '.$username, $_SERVER['REMOTE_ADDR'] ?? null, substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''),0,500), $_SERVER['HTTP_HOST'] ?? null, 'FALHA']); } catch (Throwable $e) {}
        return false;
    }

    // Evita fixar uma sessão antiga depois de autenticar.
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }

    $_SESSION['user'] = [
        'id'            => (int)$u['id_utilizador'],
        'nome'          => $u['nome_utilizador'],
        'perfil'        => $u['perfil_nome'],
        'nivel'         => $u['perfil_nivel'],
        'tema'          => $u['tema'] ?? 'CLARO',
        'foto'          => $u['foto'] ?? null,
        'id_especialista' => isset($u['id_especialista']) ? (int)$u['id_especialista'] : null,
    ];

    db()->prepare("UPDATE utilizadores SET ultimo_acesso = NOW() WHERE id_utilizador = ?")
       ->execute([(int)$u['id_utilizador']]);
    registar_auditoria(db(),'AUTENTICACAO','LOGIN_REALIZADO','LOGIN','utilizadores',(int)$u['id_utilizador'],'Login realizado com sucesso.');

    return true;
}

function require_login(): void {
    if (empty($_SESSION['user']['id'])) {
        header('Location: ' . app_url('index.php'));
        exit;
    }
}

function current_user_id(): int {
    return (int)($_SESSION['user']['id'] ?? 0);
}

function current_user_level(): string {
    return (string)($_SESSION['user']['nivel'] ?? '');
}

function current_user_region_ids(): array {
    static $cache = null;
    if ($cache !== null) return $cache;
    $uid = current_user_id();
    if ($uid <= 0) return $cache = [];
    $st = db()->prepare('SELECT id_regiao FROM utilizador_regiao WHERE id_utilizador=? ORDER BY id_regiao');
    $st->execute([$uid]);
    return $cache = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

/**
 * IDs de ramo efetivamente atribuídos ao utilizador.
 */
function current_user_branch_ids(): array {
    static $cache = null;
    if ($cache !== null) return $cache;

    $uid = current_user_id();
    if ($uid <= 0) return $cache = [];

    $st = db()->prepare("SELECT id_ramo FROM utilizador_ramo WHERE id_utilizador = ? ORDER BY id_ramo");
    $st->execute([$uid]);
    return $cache = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

function user_can_manage_target_branch(int $idRamo): bool {
    if (current_user_level() === 'GLOBAL') return true;
    if ($idRamo <= 0) return false;
    return in_array($idRamo, current_user_branch_ids(), true);
}

/**
 * Constrói a cláusula de âmbito para tabelas que tenham id_ramo/id_unidade.
 * Nunca confia apenas nos filtros enviados pelo navegador.
 */
function scope_sql(array &$params, string $alias = 'v', string $entity = 'auto'): string {
    $nivel = current_user_level();
    if ($nivel === 'GLOBAL') return '1=1';

    if ($nivel === 'RAMO') {
        $ids = current_user_branch_ids();
        $locais = ($entity === 'especialista' ? user_service_locations() : []);
        $clauses=[];
        if ($ids) {
            $ph=implode(',',array_fill(0,count($ids),'?'));
            $clauses[]="$alias.id_ramo IN ($ph)";
            $params=array_merge($params,$ids);
        }
        if ($locais) {
            $ph=implode(',',array_fill(0,count($locais),'?'));
            $clauses[]="EXISTS (SELECT 1 FROM dados_servico ds_scope WHERE ds_scope.id_especialista=$alias.id_especialista AND ds_scope.local_servico IN ($ph))";
            $params=array_merge($params,$locais);
        }
        return $clauses?'('.implode(' OR ',$clauses).')':'0=1';
    }

    if ($nivel === 'REGIAO') {
        $ids = current_user_region_ids();
        if (!$ids) return '0=1';
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $params = array_merge($params, $ids);
        if ($entity === 'especialista') {
            return "EXISTS (SELECT 1 FROM dados_servico ds_scope WHERE ds_scope.id_especialista=$alias.id_especialista AND ds_scope.id_regiao IN ($ph))";
        }
        return "$alias.id_regiao IN ($ph)";
    }

    if ($nivel === 'UNIDADE') {
        $st = db()->prepare('SELECT id_unidade FROM utilizador_unidade WHERE id_utilizador=? ORDER BY id_unidade');
        $st->execute([current_user_id()]);
        $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        if (!$ids) return '0=1';
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $params = array_merge($params, $ids);
        if ($entity === 'especialista') {
            return "EXISTS (SELECT 1 FROM dados_servico ds_scope WHERE ds_scope.id_especialista=$alias.id_especialista AND ds_scope.id_unidade IN ($ph))";
        }
        return "$alias.id_unidade IN ($ph)";
    }
    return '0=1';
}

/** Âmbito de escrita: pode consultar o ramo sem poder editar quem serve fora dele. */
function user_service_locations(): array {
    if (current_user_level() === 'GLOBAL') return ['EMG','EXE','FAN','MGA'];
    static $cached = null;
    if ($cached !== null) return $cached;
    $st=db()->prepare('SELECT local_servico FROM utilizador_local_servico WHERE id_utilizador=?');
    $st->execute([current_user_id()]);
    return $cached = array_values(array_unique(array_map('strtoupper',$st->fetchAll(PDO::FETCH_COLUMN))));
}
/** Modalidade explícita de gestão, independente do âmbito de consulta. */
function current_user_edit_mode(): string {
    if (current_user_level()==='GLOBAL') return 'COMBINADO';
    static $mode=null;
    if ($mode!==null) return $mode;
    $st=db()->prepare('SELECT modalidade_gestao FROM utilizadores WHERE id_utilizador=?');
    $st->execute([current_user_id()]);
    $mode=strtoupper((string)($st->fetchColumn()?:'RAMO'));
    return in_array($mode,['RAMO','LOCAL','COMBINADO'],true)?$mode:'RAMO';
}
function user_can_edit_specialist(int $id): bool {
    if ($id <= 0) return false;
    if (current_user_level() === 'GLOBAL') return true;
    $args=[]; $where=scope_sql($args,'e','especialista');
    $ck=db()->prepare('SELECT 1 FROM especialistas e WHERE e.id_especialista=? AND ('.$where.') LIMIT 1');
    $ck->execute(array_merge([$id],$args));
    if (!$ck->fetchColumn()) return false;
    $st=db()->prepare('SELECT e.id_ramo,ds.id_unidade,ds.id_regiao,ds.local_servico,r.sigla ramo_sigla FROM especialistas e LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista LEFT JOIN ramo r ON r.id_ramo=e.id_ramo WHERE e.id_especialista=?');
    $st->execute([$id]); $e=$st->fetch(PDO::FETCH_ASSOC);
    if (!$e) return false;
    $local = strtoupper(trim((string)($e['local_servico']??'')));
    if ($local === '') return false;
    $permitidos = user_service_locations();
    if (!in_array($local,$permitidos,true)) return false;
    $nivel=current_user_level();
    if ($nivel === 'RAMO') {
        $modo=current_user_edit_mode();
        $noRamo=in_array((int)$e['id_ramo'],current_user_branch_ids(),true);
        $noLocal=in_array($local,$permitidos,true);
        $localDoRamo=$noRamo && strtoupper((string)($e['ramo_sigla']??''))===$local;
        if($modo==='RAMO') return $localDoRamo && $noLocal;
        if($modo==='LOCAL') return $noLocal;
        return ($localDoRamo || $noLocal) && ($noRamo || $noLocal);
    }
    if ($nivel === 'REGIAO') return in_array((int)$e['id_regiao'],current_user_region_ids(),true);
    if ($nivel === 'UNIDADE') return user_can_access_unit((int)$e['id_unidade']);
    return false;
}
function require_specialist_edit_scope(int $id): void {
    if (!user_can_edit_specialist($id)) {http_response_code(403);exit('Acesso apenas de consulta: o Local de Serviço está fora do seu âmbito de gestão.');}
}

function user_can_access_branch(int $idRamo): bool {
    return user_can_manage_target_branch($idRamo);
}

function user_can_access_unit(int $idUnidade): bool {
    if (current_user_level() === 'GLOBAL') return true;
    if ($idUnidade <= 0) return false;
    if (current_user_level() === 'REGIAO') {
        $st=db()->prepare('SELECT 1 FROM unidades u JOIN utilizador_regiao ur ON ur.id_regiao=u.id_regiao WHERE u.id_unidade=? AND ur.id_utilizador=? LIMIT 1');
        $st->execute([$idUnidade,current_user_id()]); return (bool)$st->fetchColumn();
    }
    $st = db()->prepare("SELECT 1 FROM utilizador_unidade WHERE id_utilizador=? AND id_unidade=? LIMIT 1");
    $st->execute([current_user_id(), $idUnidade]);
    return (bool)$st->fetchColumn();
}

function logout_user(): void {
    if (!empty($_SESSION['user']['id'])) registar_auditoria(db(),'AUTENTICACAO','LOGOUT','LOGIN','utilizadores',(int)$_SESSION['user']['id'],'Logout realizado.');
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time()-42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

/** Delegação RH: perfil e âmbitos nunca superiores aos do criador. */
function user_is_rh_admin(): bool {
    return strtoupper((string)($_SESSION['user']['perfil'] ?? '')) === 'ADMINISTRADOR_RH';
}
function user_may_delegate_profile(array $target): bool {
    if (current_user_level() === 'GLOBAL' && !user_is_rh_admin()) return true;
    if (user_is_rh_admin()) {
        return in_array(strtoupper((string)($target['nome'] ?? '')), ['ADMINISTRADOR_RH','OPERADOR_RH','GESTOR_LOCAL','CONSULTOR'], true)
            && in_array((string)($target['nivel_acesso'] ?? ''), ['RAMO','UNIDADE'], true);
    }
    return true; // regras territoriais dos restantes perfis aplicadas pelo formulário
}
function user_can_delegate_scope(array $ramos, array $locais, array $unidades, string $modo): bool {
    if (current_user_level() === 'GLOBAL') return true;
    if (array_diff($locais, user_service_locations())) return false;
    if (current_user_level() === 'RAMO' && array_diff($ramos,current_user_branch_ids())) return false;
    if (user_is_rh_admin()) {
        if ($modo !== current_user_edit_mode()) return false;
        if (array_diff($ramos,current_user_branch_ids())) return false;
        if ($unidades) {
            $ph=implode(',',array_fill(0,count($unidades),'?'));
            $st=db()->prepare("SELECT id_unidade,id_ramo FROM unidades WHERE id_unidade IN ($ph)");
            $st->execute($unidades);
            $rows=$st->fetchAll(PDO::FETCH_ASSOC);
            if (count($rows)!==count(array_unique($unidades))) return false;
            foreach($rows as $r) if(!in_array((int)$r['id_ramo'],current_user_branch_ids(),true)) return false;
        }
    }
    return true;
}
function user_can_manage_delegated_account(int $targetId): bool {
    if (current_user_level() === 'GLOBAL') return true;
    $st=db()->prepare('SELECT p.nome,p.nivel_acesso FROM utilizadores u JOIN perfis p ON p.id_perfil=u.id_perfil WHERE u.id_utilizador=?');
    $st->execute([$targetId]);$profile=$st->fetch(PDO::FETCH_ASSOC);
    if (!$profile || !user_may_delegate_profile($profile)) return false;
    $st=db()->prepare('SELECT id_ramo FROM utilizador_ramo WHERE id_utilizador=?');$st->execute([$targetId]);
    $branches=array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN));
    $st=db()->prepare('SELECT local_servico FROM utilizador_local_servico WHERE id_utilizador=?');$st->execute([$targetId]);
    $locations=array_map('strtoupper',$st->fetchAll(PDO::FETCH_COLUMN));
    $st=db()->prepare('SELECT id_unidade FROM utilizador_unidade WHERE id_utilizador=?');$st->execute([$targetId]);
    $units=array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN));
    $st=db()->prepare('SELECT modalidade_gestao FROM utilizadores WHERE id_utilizador=?');
    $st->execute([$targetId]);
    $targetMode=strtoupper((string)($st->fetchColumn() ?: 'RAMO'));
    return user_can_delegate_scope($branches,$locations,$units,$targetMode);
}

function has_permission(string $permission): bool {
    $u = $_SESSION['user'] ?? [];
    $uid = (int)($u['id'] ?? 0);
    if ($uid <= 0) return false;

    static $cache = [];
    $key = $uid . '|' . $permission;
    if (array_key_exists($key, $cache)) return $cache[$key];

    $st = db()->prepare("
        SELECT 1
        FROM perfil_permissoes pp
        INNER JOIN permissoes p ON p.id_permissao = pp.id_permissao
        INNER JOIN utilizadores u ON u.id_perfil = pp.id_perfil
        WHERE u.id_utilizador = ?
          AND u.estado = 'ATIVO'
          AND p.nome = ?
          AND p.estado = 'ATIVO'
        LIMIT 1
    ");
    $st->execute([$uid, $permission]);
    $allowed = (bool)$st->fetchColumn();
    if (user_is_rh_admin() && (str_starts_with($permission,'EQUIPAMENTOS_') || str_starts_with($permission,'CONFIGURACOES_') || str_starts_with($permission,'AUDITORIA_'))) return $cache[$key] = false;
    if (!$allowed) return $cache[$key] = false;

    // As configurações de módulos são uma camada adicional de restrição; nunca concedem
    // uma permissão que a tabela perfil_permissoes não tenha concedido.
    $moduleMap = [
        'ESPECIALISTAS'=>'RH', 'EQUIPAMENTOS'=>'RM', 'FEED'=>'FEED',
        'UTILIZADORES'=>'UTILIZADORES', 'CONFIGURACOES'=>'CONFIGURACOES',
        'AUDITORIA'=>'AUDITORIA', 'RELATORIOS'=>'RELATORIOS', 'DASHBOARD'=>'DASHBOARD',
        'NOTIFICACOES'=>'NOTIFICACOES', 'RAMOS'=>'CONFIGURACOES', 'REGIOES'=>'CONFIGURACOES',
        'UNIDADES'=>'CONFIGURACOES', 'PATENTES'=>'CONFIGURACOES', 'FUNCOES'=>'CONFIGURACOES',
        'BANCOS'=>'CONFIGURACOES', 'FORMACOES'=>'CONFIGURACOES', 'INSTITUICOES'=>'CONFIGURACOES',
        'TIPOS_LICENCA'=>'CONFIGURACOES', 'TIPOS_DOCUMENTO'=>'CONFIGURACOES',
        'MODELOS_DOCUMENTOS'=>'CONFIGURACOES', 'FEED_PERMISSOES'=>'CONFIGURACOES', 'SITUACOES_SERVICO'=>'CONFIGURACOES'
    ];
    foreach ($moduleMap as $prefix => $module) {
        if (str_starts_with(strtoupper($permission), $prefix.'_')) {
            try {
                $m = db()->prepare('SELECT pode_visualizar FROM perfil_modulos pm JOIN utilizadores ux ON ux.id_perfil=pm.id_perfil WHERE ux.id_utilizador=? AND pm.modulo=? LIMIT 1');
                $m->execute([$uid, $module]);
                $override = $m->fetchColumn();
                if ($override !== false && (int)$override === 0) return $cache[$key] = false;
                // Acções de escrita exigem também a autorização explícita de configuração.
                if (preg_match('/_(CRIAR|EDITAR|ELIMINAR|GERIR|PUBLICAR|CONFIGURAR)$/', strtoupper($permission))) {
                    $mc = db()->prepare('SELECT pode_configurar FROM perfil_modulos pm JOIN utilizadores ux ON ux.id_perfil=pm.id_perfil WHERE ux.id_utilizador=? AND pm.modulo=? LIMIT 1');
                    $mc->execute([$uid, $module]); $canConfigure=$mc->fetchColumn();
                    if ($canConfigure !== false && (int)$canConfigure === 0) return $cache[$key] = false;
                }
            } catch (Throwable $e) { /* compatibilidade antes da migração */ }
            break;
        }
    }
    return $cache[$key] = true;
}

/**
 * Proteção central dos formulários e endpoints auxiliares de especialistas.
 * A permissão funcional não substitui a verificação do Local de Serviço.
 */
function require_specialist_module_scope(string $permission): void {
    if (!preg_match('/(?:_EDITAR|_CRIAR|_ELIMINAR)$/',$permission)) return;
    $script=basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $dir=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));
    if (!str_contains($dir,'/modulos/especialista/')) return;
    if ($script==='especialista_novo.php') return; // validação no próprio cadastro
    $idEsp=0;
    if ($script==='especialista.php'||$script==='especialista_editar.php') {
        $idEsp=(int)($_GET['id']??$_POST['id']??0);
    } else {
        $tabelas=[
          'formacao'=>'formacoes','habilitacao'=>'habilitacoes_literarias',
          'familiar'=>'familiares','licenca'=>'licencas',
          'documento'=>'documentos','condecoracao'=>'condecoracoes'
        ];
        foreach($tabelas as $singular=>$tabela) {
            if (str_starts_with($script,$singular.'_')) {
                if(str_contains($script,'_nova.')||str_contains($script,'_novo.')) {
                    $idEsp=(int)($_GET['id_especialista']??$_POST['id_especialista']??0);
                } else {
                    $id=(int)($_GET['id']??$_POST['id']??0);
                    if ($id>0) {
                        $idPk=['formacao'=>'id_formacao','habilitacao'=>'id_habilitacao',
                            'familiar'=>'id_familiar','licenca'=>'id_licenca',
                            'documento'=>'id_documento','condecoracao'=>'id_condecoracao'][$singular];
                        $q=db()->prepare("SELECT id_especialista FROM $tabela WHERE $idPk=? LIMIT 1");
                        $q->execute([$id]);$idEsp=(int)$q->fetchColumn();
                    }
                }
                break;
            }
        }
    }
    if ($idEsp>0) require_specialist_edit_scope($idEsp);
}

function require_permission(string $permission): void {
    if (!has_permission($permission)) {
        http_response_code(403);
        exit('Acesso não autorizado.');
    }
    require_specialist_module_scope($permission);
}

function safe_return_url(?string $url, string $fallback): string {
    $url = trim((string)$url);
    if ($url === '' || preg_match('/^[a-z][a-z0-9+.-]*:/i', $url) || str_starts_with($url, '//')) {
        return $fallback;
    }
    return $url;
}

function app_public_path(string $relative=''): string {
    $public = realpath(__DIR__ . '/../public');
    if ($public === false) return '';
    $relative = ltrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $relative), DIRECTORY_SEPARATOR);
    return $public . DIRECTORY_SEPARATOR . $relative;
}

function app_file_url(string $relative=''): string {
    return app_url($relative);
}

// Proteção central de todos os pedidos POST que passam pela autenticação.
csrf_verify_post();
