<?php
// Insígnias são escolhidas exclusivamente nas Configurações → Patentes.
function insignia_patente_referencia(?string $ramo, ?string $nome): ?string { return null; }
function imagem_patente_resolvida(?string $guardada, ?string $ramo, ?string $nome): ?string {
    return $guardada !== null && trim($guardada) !== '' ? $guardada : null;
}
