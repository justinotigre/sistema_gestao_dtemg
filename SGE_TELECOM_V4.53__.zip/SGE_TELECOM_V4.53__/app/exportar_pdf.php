<?php
/** Exportador PDF pequeno e autónomo para listagens SGE (A4 horizontal). */
function exportar_lista_pdf(array $registos, array $colunas, array $mapa, string $titulo, string $filtros): never {
    $paginaW=842.0;$paginaH=595.0;$margem=32.0;$largura=$paginaW-2*$margem;
    $nomes=['N.º'];foreach($colunas as $col)$nomes[]=$mapa[$col][0];
    $pesos=[0.42];foreach($colunas as $col)$pesos[]=($col==='nome'?2.2:($col==='bi'||$col==='unidade'||$col==='local'?1.35:1.0));
    $soma=array_sum($pesos);$larguras=array_map(static fn($x)=>$largura*$x/$soma,$pesos);
    $short=static function($str,$len){return function_exists('mb_strimwidth')?mb_strimwidth((string)$str,0,$len,'…','UTF-8'):(strlen((string)$str)<=$len?(string)$str:substr((string)$str,0,max(0,$len-3)).'...');};
    $normal=static function($s){$o=@iconv('UTF-8','Windows-1252//TRANSLIT',(string)$s);return $o===false?'?':str_replace(['\\','(',')'],['\\\\','\\(','\\)'],$o);};
    $text=static function(&$conteudo,$s,$x,$y,$tam=9,$bold=false)use($normal){$conteudo.='BT /'.($bold?'F2':'F1').' '.(float)$tam.' Tf '.round($x,2).' '.round($y,2).' Td ('.$normal($s).") Tj ET\n";};
    $paginas=[];$conteudo='';$y=0;$pag=0;
    $novaPagina=static function()use(&$conteudo,&$y,&$pag,&$paginas,$text,$paginaW,$paginaH,$margem,$titulo,$filtros){
        if($pag>0)$paginas[]=$conteudo;$pag++;$conteudo="0 0 0 rg\n";$y=$paginaH-42;
        $text($conteudo,'SGE TELECOM — '.$titulo,$margem,$y,15,true);$y-=23;
        $text($conteudo,$filtros,$margem,$y,8);$y-=16;
        $text($conteudo,'Página '.$pag,$paginaW-$margem-48,$paginaH-30,8);$y-=14;
    };
    $cabecalho=static function()use(&$conteudo,&$y,$margem,$larguras,$nomes,$text,$short){
        $altura=25;$conteudo.='0.91 0.94 0.97 rg '.$margem.' '.($y-$altura+5).' '.array_sum($larguras).' '.$altura." re f\n0 0 0 rg\n";
        $x=$margem;
        foreach($nomes as $i=>$nome){$text($conteudo,$short((string)$nome,max(3,(int)($larguras[$i]/5.4))),$x+3,$y-11,8,true);$x+=$larguras[$i];}
        $y-=28;
    };
    $novaPagina();$cabecalho();
    foreach($registos as $idx=>$r){
        if($y<50){$novaPagina();$cabecalho();}
        $valores=[(string)($idx+1)];
        foreach($colunas as $col){$v=$col==='identificador'?($r['tipo_especialista']==='CIVIL'?($r['no_civil']??''):($r['nip']??'')):($r[$mapa[$col][1]]??'');$valores[]=(string)($v?:'—');}
        $h=22;$conteudo.=($idx%2?'0.975 0.985 0.99':'1 1 1').' rg '.$margem.' '.($y-$h+4).' '.array_sum($larguras).' '.$h." re f\n0.12 0.19 0.25 rg\n";
        $x=$margem;
        foreach($valores as $i=>$v){$v=$short($v,max(3,(int)(($larguras[$i]-7)/5.0)));$text($conteudo,$v,$x+3,$y-10,8);$x+=$larguras[$i];}
        $y-=$h;
    }
    $paginas[]=$conteudo;
    $obj=[];$obj[]=null; // indexação PDF começa no 1
    $add=static function($txt)use(&$obj){$obj[]=$txt;return count($obj)-1;};
    $font1=$add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    $font2=$add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    $contents=[];foreach($paginas as $content)$contents[]=$add('<< /Length '.strlen($content).' >>' ."\nstream\n".$content."\nendstream");
    $catalog=$add('PENDENTE');$pagesId=$add('PENDENTE');$pageIds=[];
    foreach($contents as $con)$pageIds[]=$add('<< /Type /Page /Parent '.$pagesId.' 0 R /MediaBox [0 0 '.(int)$paginaW.' '.(int)$paginaH.'] /Resources << /Font << /F1 '.$font1.' 0 R /F2 '.$font2.' 0 R >> >> /Contents '.$con.' 0 R >>');
    $obj[$catalog]='<< /Type /Catalog /Pages '.$pagesId.' 0 R >>';
    $obj[$pagesId]='<< /Type /Pages /Kids ['.implode(' ',array_map(static fn($v)=>$v.' 0 R',$pageIds)).'] /Count '.count($pageIds).' >>';
    $pdf="%PDF-1.4\n";$offsets=[0];for($i=1;$i<count($obj);$i++){$offsets[$i]=strlen($pdf);$pdf.=$i." 0 obj\n".$obj[$i]."\nendobj\n";}
    $xref=strlen($pdf);$pdf.='xref' ."\n0 ".count($obj)."\n0000000000 65535 f \n";
    for($i=1;$i<count($obj);$i++)$pdf.=sprintf('%010d 00000 n ', $offsets[$i])."\n";
    $pdf.='trailer' ."\n<< /Size ".count($obj).' /Root '.$catalog." 0 R >>\nstartxref\n".$xref."\n%%EOF";
    header('Content-Type: application/pdf');header('Content-Disposition: attachment; filename="lista_especialistas.pdf"');header('Content-Length: '.strlen($pdf));echo $pdf;exit;
}
