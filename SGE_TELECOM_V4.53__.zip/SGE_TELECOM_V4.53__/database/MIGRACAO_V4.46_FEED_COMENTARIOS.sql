-- A tabela de comentários consta já da migração v4.20. Execute apenas se ainda não existir.
CREATE TABLE IF NOT EXISTS feed_comentarios (
 id_comentario BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 id_publicacao INT UNSIGNED NOT NULL,
 id_utilizador INT NOT NULL,
 comentario TEXT NOT NULL,
 criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(id_comentario), KEY idx_feed_comentarios_publicacao(id_publicacao),
 CONSTRAINT fk_feed_comentario_publicacao FOREIGN KEY(id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
 CONSTRAINT fk_feed_comentario_utilizador FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
