-- SE TELECOM v4.23: correções de permissões, caminhos e compatibilidade.
-- A página de permissões também cria esta tabela quando ausente; executar como administrador da BD.
CREATE TABLE IF NOT EXISTS feed_permissoes_perfil (
 id_perfil INT NOT NULL PRIMARY KEY,
 pode_ler TINYINT(1) NOT NULL DEFAULT 1,
 pode_publicar TINYINT(1) NOT NULL DEFAULT 0,
 pode_submeter TINYINT(1) NOT NULL DEFAULT 1,
 pode_gerir TINYINT(1) NOT NULL DEFAULT 0,
 atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO feed_permissoes_perfil (id_perfil,pode_ler,pode_publicar,pode_submeter,pode_gerir)
SELECT id_perfil,1,CASE WHEN nome LIKE '%ADMINISTRADOR%' THEN 1 ELSE 0 END,1,CASE WHEN nome LIKE '%ADMINISTRADOR%' THEN 1 ELSE 0 END
FROM perfis WHERE estado='ATIVO';
