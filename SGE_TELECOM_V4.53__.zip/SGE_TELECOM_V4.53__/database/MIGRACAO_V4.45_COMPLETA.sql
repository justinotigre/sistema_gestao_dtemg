-- SGE TELECOM V4.45 — executar uma única vez depois de uma cópia de segurança.
-- Não executar os três ficheiros de migração V4.45 individuais depois deste.
-- Não contém UPDATE/DELETE em massa; compatível com Safe Update Mode.

SET @existe_no_civil := (
 SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
 WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='dados_servico' AND COLUMN_NAME='no_civil'
);
SET @sql := IF(@existe_no_civil=0,
 'ALTER TABLE dados_servico ADD COLUMN no_civil VARCHAR(50) NULL AFTER nip',
 'SELECT ''NO já existe'' AS mensagem');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS utilizador_local_servico (
 id_utilizador INT NOT NULL,
 local_servico VARCHAR(10) NOT NULL,
 PRIMARY KEY(id_utilizador,local_servico),
 CONSTRAINT fk_usr_local_user FOREIGN KEY(id_utilizador)
 REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS modelos_listas (
 id_modelo INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 codigo VARCHAR(40) NOT NULL UNIQUE,
 titulo VARCHAR(150) NOT NULL,
 colunas VARCHAR(250) NOT NULL,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO'
) ENGINE=InnoDB;

INSERT INTO modelos_listas (codigo,titulo,colunas,estado) VALUES
 ('efetividade','Lista de Efetividade','nome,bi,identificador,ramo,local,unidade,estado','ATIVO'),
 ('resumido','Lista Resumida','nome,identificador,unidade','ATIVO')
ON DUPLICATE KEY UPDATE codigo=VALUES(codigo);

SELECT 'Migração V4.45 concluída. Atribua Locais de Serviço aos gestores em Utilizadores.' AS mensagem;
