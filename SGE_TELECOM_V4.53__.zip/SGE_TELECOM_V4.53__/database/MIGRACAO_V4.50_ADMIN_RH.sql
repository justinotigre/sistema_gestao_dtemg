-- V4.50: Administrador RH pode gerir integralmente RH e delegar contas do âmbito.
-- Execute uma vez após cópia de segurança da base de dados.
INSERT IGNORE INTO perfil_permissoes(id_perfil,id_permissao)
SELECT pf.id_perfil,pe.id_permissao FROM perfis pf CROSS JOIN permissoes pe
WHERE pf.nome='ADMINISTRADOR_RH' AND pe.nome IN (
 'UTILIZADORES_VISUALIZAR','UTILIZADORES_CRIAR','UTILIZADORES_EDITAR',
 'ESPECIALISTAS_ELIMINAR','FOTOGRAFIAS_ELIMINAR','DOCUMENTOS_ELIMINAR',
 'FERIAS_ELIMINAR','LICENCAS_ELIMINAR');
-- Não são concedidas permissões de Recursos Materiais nem administração global.

-- Se houver regras de módulos já configuradas, ativa apenas os módulos próprios.
SET @rh_perfil := (SELECT id_perfil FROM perfis WHERE nome='ADMINISTRADOR_RH' LIMIT 1);
SET SQL_SAFE_UPDATES = 0;
UPDATE perfil_modulos SET pode_visualizar=1,pode_configurar=1 WHERE id_perfil=@rh_perfil AND modulo IN ('RH','UTILIZADORES');
UPDATE perfil_modulos SET pode_visualizar=0,pode_configurar=0 WHERE id_perfil=@rh_perfil AND modulo='RM';
SET SQL_SAFE_UPDATES = 1;
