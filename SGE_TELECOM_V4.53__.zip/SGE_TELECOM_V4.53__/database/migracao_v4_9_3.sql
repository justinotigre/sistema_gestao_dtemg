-- ============================================================
-- MIGRAÇÃO v4.9.3 — preserva os dados existentes
-- Base: sistema_especialistas_v3
-- ============================================================
USE sistema_especialistas_v3;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- Estruturas que as versões anteriores passaram a utilizar.
CREATE TABLE IF NOT EXISTS grupos_sanguineos (id_grupo_sanguineo INT AUTO_INCREMENT PRIMARY KEY,nome VARCHAR(20) NOT NULL UNIQUE,estado ENUM('ATIVO','INATIVO') DEFAULT 'ATIVO',data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS tipos_licenca (id_tipo_licenca INT AUTO_INCREMENT PRIMARY KEY,nome VARCHAR(150) NOT NULL UNIQUE,codigo VARCHAR(50) NOT NULL UNIQUE,descricao TEXT,estado ENUM('ATIVO','INATIVO') DEFAULT 'ATIVO',data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS licencas (id_licenca INT AUTO_INCREMENT PRIMARY KEY,id_especialista INT NOT NULL,id_tipo_licenca INT NOT NULL,data_inicio DATE NOT NULL,data_fim DATE NULL,numero_dias INT NULL,estado VARCHAR(50) DEFAULT 'ATIVA',observacoes TEXT,data_registo DATETIME DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,FOREIGN KEY(id_tipo_licenca) REFERENCES tipos_licenca(id_tipo_licenca) ON DELETE RESTRICT) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS vestuario (id_vestuario INT AUTO_INCREMENT PRIMARY KEY,id_especialista INT NOT NULL UNIQUE,numero_calca VARCHAR(30),numero_camisa VARCHAR(30),numero_sapato VARCHAR(30),numero_bota VARCHAR(30),numero_boina VARCHAR(30),numero_quiko VARCHAR(30),numero_casaco VARCHAR(30),outros VARCHAR(255),data_atualizacao DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS historico_configuracoes (id_historico BIGINT AUTO_INCREMENT PRIMARY KEY,tabela VARCHAR(100) NOT NULL,id_registo INT NOT NULL,acao VARCHAR(50) NOT NULL,dados_anteriores JSON NULL,dados_novos JSON NULL,id_utilizador INT NULL,data_registo DATETIME DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL) ENGINE=InnoDB;

-- Novas estruturas organizacionais
CREATE TABLE IF NOT EXISTS regioes (
 id_regiao INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(150) NOT NULL UNIQUE, sigla VARCHAR(30) UNIQUE,
 descricao TEXT, estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS regiao_provincias (
 id_regiao INT NOT NULL, id_provincia INT NOT NULL, PRIMARY KEY(id_regiao,id_provincia),
 FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE CASCADE,
 FOREIGN KEY(id_provincia) REFERENCES provincias(id_provincia) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS utilizador_regiao (
 id_utilizador INT NOT NULL, id_regiao INT NOT NULL, PRIMARY KEY(id_utilizador,id_regiao),
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE,
 FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS dados_residencia (
 id_residencia INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL UNIQUE,
 id_provincia INT NULL, id_municipio INT NULL, bairro VARCHAR(150), rua VARCHAR(200), casa VARCHAR(80), ponto_referencia VARCHAR(255),
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_provincia) REFERENCES provincias(id_provincia) ON DELETE RESTRICT,
 FOREIGN KEY(id_municipio) REFERENCES municipios(id_municipio) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS historico_especialistas (
 id_historico BIGINT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL,
 tipo_evento VARCHAR(80) NOT NULL, campo VARCHAR(100), valor_anterior VARCHAR(500), valor_novo VARCHAR(500), data_inicio DATE NULL, data_fim DATE NULL,
 id_documento INT NULL, motivo TEXT, observacoes TEXT, id_utilizador INT NULL, data_registo DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL,
 INDEX idx_he_especialista(id_especialista), INDEX idx_he_tipo(tipo_evento), INDEX idx_he_data(data_registo)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS historico_equipamentos (id_historico BIGINT AUTO_INCREMENT PRIMARY KEY,id_equipamento INT NULL,evento VARCHAR(80) NOT NULL,campo VARCHAR(100),valor_anterior VARCHAR(500),valor_novo VARCHAR(500),motivo TEXT,id_utilizador INT NULL,data_registo DATETIME DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(id_equipamento) REFERENCES equipamentos(id_equipamento) ON DELETE SET NULL,FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL,INDEX idx_heequip(id_equipamento),INDEX idx_heeq_data(data_registo)) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS modelos_relatorio (
 id_modelo_relatorio INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(200) NOT NULL UNIQUE,
 categoria VARCHAR(50) NOT NULL, entidade VARCHAR(50) NOT NULL, titulo VARCHAR(255), orientacao VARCHAR(20) DEFAULT 'PAISAGEM', campos JSON NULL, filtros JSON NULL,
 estado ENUM('ATIVO','INATIVO') DEFAULT 'ATIVO', data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP, data_atualizacao DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS auditoria (
 id_auditoria BIGINT AUTO_INCREMENT PRIMARY KEY, id_utilizador INT NULL, categoria VARCHAR(80) NOT NULL, evento VARCHAR(120) NOT NULL, modulo VARCHAR(100), entidade VARCHAR(100), id_registo INT NULL,
 descricao TEXT, dados_anteriores JSON NULL, dados_novos JSON NULL, ip VARCHAR(45), user_agent VARCHAR(500), localizacao VARCHAR(255), resultado VARCHAR(20) NOT NULL DEFAULT 'SUCESSO', data_evento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL,
 INDEX idx_aud_data(data_evento), INDEX idx_aud_user(id_utilizador), INDEX idx_aud_categoria(categoria), INDEX idx_aud_evento(evento), INDEX idx_aud_modulo(modulo)
) ENGINE=InnoDB;

-- Colunas novas: função auxiliar para não falhar quando já existirem.
SET @db=DATABASE();
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE dados_pessoais ADD COLUMN id_grupo_sanguineo INT NULL AFTER local_emissao_bi','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='dados_pessoais' AND COLUMN_NAME='id_grupo_sanguineo'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE dados_pessoais ADD COLUMN peso_kg DECIMAL(6,2) NULL AFTER id_grupo_sanguineo','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='dados_pessoais' AND COLUMN_NAME='peso_kg'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE dados_pessoais ADD COLUMN telefone_alternativo VARCHAR(30) NULL AFTER telefone','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='dados_pessoais' AND COLUMN_NAME='telefone_alternativo'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,CONCAT('ALTER TABLE tipos_formacao ADD COLUMN categoria ENUM(',CHAR(39),'MILITAR',CHAR(39),',',CHAR(39),'GERAL',CHAR(39),') NOT NULL DEFAULT ',CHAR(39),'GERAL',CHAR(39),' AFTER nome'),'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='tipos_formacao' AND COLUMN_NAME='categoria'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,CONCAT('ALTER TABLE ramo ADD COLUMN cor_principal VARCHAR(20) DEFAULT ',CHAR(39),'#327aa4',CHAR(39)),'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='ramo' AND COLUMN_NAME='cor_principal'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE ramo ADD COLUMN cor_secundaria VARCHAR(20) NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='ramo' AND COLUMN_NAME='cor_secundaria'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE ramo ADD COLUMN ordem INT NOT NULL DEFAULT 999','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='ramo' AND COLUMN_NAME='ordem'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COLUMN_TYPE NOT LIKE '%REGIAO%','ALTER TABLE perfis MODIFY nivel_acesso ENUM(\'GLOBAL\',\'REGIAO\',\'RAMO\',\'UNIDADE\') NOT NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='perfis' AND COLUMN_NAME='nivel_acesso'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE utilizadores ADD COLUMN id_regiao_responsabilidade INT NULL AFTER id_especialista','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='utilizadores' AND COLUMN_NAME='id_regiao_responsabilidade'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COLUMN_TYPE NOT LIKE '%REGIAO%','ALTER TABLE utilizadores MODIFY tipo_responsabilidade ENUM(\'REGIAO\',\'RAMO\',\'UNIDADE\',\'ESPECIALISTA\') NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='utilizadores' AND COLUMN_NAME='tipo_responsabilidade'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE unidades ADD COLUMN id_regiao INT NULL AFTER id_ramo','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='unidades' AND COLUMN_NAME='id_regiao'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE dados_servico ADD COLUMN id_regiao INT NULL AFTER id_situacao_servico','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='dados_servico' AND COLUMN_NAME='id_regiao'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE equipamentos ADD COLUMN id_regiao INT NULL AFTER id_ramo','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='equipamentos' AND COLUMN_NAME='id_regiao'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE equipamentos ADD COLUMN id_especialista_responsavel INT NULL AFTER id_unidade','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='equipamentos' AND COLUMN_NAME='id_especialista_responsavel'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,CONCAT('ALTER TABLE situacoes_servico ADD COLUMN grupo ENUM(',CHAR(39),'ATIVO',CHAR(39),',',CHAR(39),'INATIVO',CHAR(39),') NOT NULL DEFAULT ',CHAR(39),'ATIVO',CHAR(39),' AFTER nome'),'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='situacoes_servico' AND COLUMN_NAME='grupo'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE situacoes_servico ADD COLUMN descricao TEXT NULL AFTER grupo','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='situacoes_servico' AND COLUMN_NAME='descricao'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- Chaves novas (executar apenas se ainda não existirem no ambiente).
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE utilizadores ADD CONSTRAINT fk_user_regiao_resp FOREIGN KEY(id_regiao_responsabilidade) REFERENCES regioes(id_regiao) ON DELETE SET NULL','SELECT 1') FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='utilizadores' AND CONSTRAINT_NAME='fk_user_regiao_resp'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE unidades ADD CONSTRAINT fk_unidade_regiao FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE RESTRICT','SELECT 1') FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='unidades' AND CONSTRAINT_NAME='fk_unidade_regiao'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE dados_servico ADD CONSTRAINT fk_ds_regiao FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE RESTRICT','SELECT 1') FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='dados_servico' AND CONSTRAINT_NAME='fk_ds_regiao'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE equipamentos ADD CONSTRAINT fk_eq_regiao FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE RESTRICT','SELECT 1') FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='equipamentos' AND CONSTRAINT_NAME='fk_eq_regiao'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql=(SELECT IF(COUNT(*)=0,'ALTER TABLE equipamentos ADD CONSTRAINT fk_eq_responsavel FOREIGN KEY(id_especialista_responsavel) REFERENCES especialistas(id_especialista) ON DELETE SET NULL','SELECT 1') FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='equipamentos' AND CONSTRAINT_NAME='fk_eq_responsavel'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- Perfis e permissões novos.
INSERT INTO perfis(nome,descricao,nivel_acesso) VALUES
('ADMINISTRADOR_RH','Administração de Recursos Humanos no âmbito atribuído','RAMO'),
('OPERADOR_RH','Operação de Recursos Humanos no âmbito atribuído','RAMO'),
('ADMINISTRADOR_RM','Administração de Recursos Materiais no âmbito atribuído','RAMO'),
('ADMINISTRADOR_REGIAO','Administração no âmbito regional atribuído','REGIAO'),
('OPERADOR_REGIAO','Operação no âmbito regional atribuído','REGIAO'),
('PRIVILEGIADO','Consulta global privilegiada, sem administração','GLOBAL'),
('CONSULTOR','Consulta limitada ao âmbito atribuído','UNIDADE')
ON DUPLICATE KEY UPDATE nome=VALUES(nome);
INSERT INTO permissoes(nome,modulo,descricao) VALUES
('REGIOES_GERIR','CONFIGURACOES','Gerir regiões'),('AUDITORIA_VISUALIZAR','AUDITORIA','Consultar auditoria'),('AUDITORIA_GERIR','AUDITORIA','Gerir auditoria'),('HISTORICO_VISUALIZAR','HISTORICO','Consultar histórico'),('RELATORIOS_VISUALIZAR','RELATORIOS','Ver relatórios'),('RELATORIOS_IMPRIMIR','RELATORIOS','Imprimir relatórios'),('CONSULTA_FALECIDOS','CONSULTA','Consultar falecidos'),('CONSULTA_DOENTES','CONSULTA','Consultar doentes')
ON DUPLICATE KEY UPDATE nome=VALUES(nome);
INSERT IGNORE INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p CROSS JOIN permissoes x WHERE p.nome='ADMINISTRADOR_GLOBAL';
INSERT IGNORE INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p JOIN permissoes x ON x.nome IN('DASHBOARD_VISUALIZAR','ESPECIALISTAS_VISUALIZAR','EQUIPAMENTOS_VISUALIZAR','FOTOGRAFIAS_VISUALIZAR','DOCUMENTOS_VISUALIZAR','RELATORIOS_VISUALIZAR','RELATORIOS_IMPRIMIR','HISTORICO_VISUALIZAR','AUDITORIA_VISUALIZAR','CONSULTA_FALECIDOS','CONSULTA_DOENTES') WHERE p.nome='PRIVILEGIADO';

-- Atualizações funcionais.
UPDATE situacoes_servico SET estado='INATIVO', grupo='INATIVO' WHERE id_situacao_servico IN (SELECT id FROM (SELECT id_situacao_servico AS id FROM situacoes_servico WHERE UPPER(nome)='TRANSFERIDO') AS x);
UPDATE situacoes_servico SET grupo=IF(estado='ATIVO','ATIVO','INATIVO') WHERE id_situacao_servico > 0;
INSERT INTO situacoes_servico (nome,estado,grupo,descricao) SELECT 'DOENTE','ATIVO','ATIVO','Estado funcional para consulta e acompanhamento.' WHERE NOT EXISTS (SELECT 1 FROM situacoes_servico WHERE UPPER(nome)='DOENTE');
INSERT INTO regioes(nome,sigla,descricao) VALUES ('Região Norte','NORTE','Agrupamento inicial editável.'),('Região Centro','CENTRO','Agrupamento inicial editável.'),('Região Leste','LESTE','Agrupamento inicial editável.'),('Região Sul','SUL','Agrupamento inicial editável.') ON DUPLICATE KEY UPDATE nome=VALUES(nome);
INSERT INTO grupos_sanguineos(nome) VALUES ('A+'),('A-'),('B+'),('B-'),('AB+'),('AB-'),('O+'),('O-') ON DUPLICATE KEY UPDATE nome=VALUES(nome);
INSERT INTO tipos_licenca(nome,codigo,descricao) VALUES ('Licença de férias','FERIAS','Licença de férias'),('Licença de formação','FORMACAO','Licença de formação'),('Outras licenças','OUTRAS','Outras licenças') ON DUPLICATE KEY UPDATE descricao=VALUES(descricao);

-- Províncias novas, incluindo a DPA 2025. Municípios novos devem ser carregados pelo ficheiro de instalação consolidado.
INSERT INTO provincias(id_pais,nome) SELECT p.id_pais,x.nome FROM paises p JOIN (SELECT 'Bengo' nome UNION ALL SELECT 'Benguela' UNION ALL SELECT 'Bié' UNION ALL SELECT 'Cabinda' UNION ALL SELECT 'Cuando' UNION ALL SELECT 'Cuanza Norte' UNION ALL SELECT 'Cuanza Sul' UNION ALL SELECT 'Cubango' UNION ALL SELECT 'Cunene' UNION ALL SELECT 'Huambo' UNION ALL SELECT 'Huíla' UNION ALL SELECT 'Icolo e Bengo' UNION ALL SELECT 'Luanda' UNION ALL SELECT 'Lunda Norte' UNION ALL SELECT 'Lunda Sul' UNION ALL SELECT 'Malanje' UNION ALL SELECT 'Moxico' UNION ALL SELECT 'Moxico Leste' UNION ALL SELECT 'Namibe' UNION ALL SELECT 'Uíge' UNION ALL SELECT 'Zaire') x ON 1=1 WHERE p.codigo='AO' AND NOT EXISTS(SELECT 1 FROM provincias z WHERE z.id_pais=p.id_pais AND z.nome=x.nome);

SET FOREIGN_KEY_CHECKS=1;
SELECT 'v4.9.3' AS versao,'MIGRAÇÃO ESTRUTURAL CONCLUÍDA' AS estado;
