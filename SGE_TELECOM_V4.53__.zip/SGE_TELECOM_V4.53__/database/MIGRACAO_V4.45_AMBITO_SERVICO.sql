-- Cada gestor pode ler dentro do âmbito existente,
-- mas apenas altera especialistas no Local de Serviço atribuído.
CREATE TABLE IF NOT EXISTS utilizador_local_servico (
    id_utilizador INT NOT NULL,
    local_servico VARCHAR(10) NOT NULL,
    PRIMARY KEY (id_utilizador,local_servico),
    CONSTRAINT fk_usr_local_user FOREIGN KEY (id_utilizador)
      REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB;
-- A migração não atribui automaticamente qualquer local a utilizadores antigos:
-- atribua os locais de escrita em Utilizadores -> Editar.
