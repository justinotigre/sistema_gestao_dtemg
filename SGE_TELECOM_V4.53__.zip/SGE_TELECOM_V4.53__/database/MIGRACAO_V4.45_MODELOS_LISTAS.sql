CREATE TABLE IF NOT EXISTS modelos_listas (
  id_modelo INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(40) NOT NULL UNIQUE,
  titulo VARCHAR(150) NOT NULL,
  colunas VARCHAR(250) NOT NULL,
  estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO'
) ENGINE=InnoDB;
INSERT INTO modelos_listas (codigo,titulo,colunas,estado) VALUES
 ('efetividade','Lista de Efetividade','nome,bi,identificador,ramo,local,unidade,estado','ATIVO'),
 ('resumido','Lista Resumida','nome,identificador,unidade','ATIVO')
ON DUPLICATE KEY UPDATE codigo=VALUES(codigo);
