-- Sistema de Gestão de Especialistas v4.17
-- Execute esta migração uma única vez na base de dados existente.
CREATE TABLE IF NOT EXISTS feed_publicacoes (
  id_publicacao INT UNSIGNED NOT NULL AUTO_INCREMENT,
  titulo VARCHAR(180) NOT NULL,
  conteudo TEXT NOT NULL,
  area ENUM('RH','RM','TODOS') NOT NULL DEFAULT 'TODOS',
  tipo VARCHAR(30) NOT NULL DEFAULT 'COMUNICADO',
  data_limite DATE NULL,
  id_autor INT NULL,
  id_ramo INT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
  PRIMARY KEY (id_publicacao),
  KEY idx_feed_area_estado (area,estado),
  KEY idx_feed_ramo (id_ramo),
  KEY idx_feed_data (criado_em),
  CONSTRAINT fk_feed_autor FOREIGN KEY (id_autor) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL,
  CONSTRAINT fk_feed_ramo FOREIGN KEY (id_ramo) REFERENCES ramo(id_ramo) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS feed_leituras (
  id_publicacao INT UNSIGNED NOT NULL,
  id_utilizador INT NOT NULL,
  lido_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_publicacao,id_utilizador),
  KEY idx_feed_leitura_utilizador (id_utilizador),
  CONSTRAINT fk_feed_leitura_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
  CONSTRAINT fk_feed_leitura_utilizador FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS feed_candidaturas (
  id_candidatura BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_publicacao INT UNSIGNED NOT NULL,
  id_especialista INT NOT NULL,
  estado VARCHAR(30) NOT NULL DEFAULT 'SUBMETIDA',
  submetido_por INT NULL,
  submetido_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_candidatura),
  UNIQUE KEY uq_feed_candidatura (id_publicacao,id_especialista),
  KEY idx_feed_candidatura_especialista (id_especialista),
  CONSTRAINT fk_feed_candidatura_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
  CONSTRAINT fk_feed_candidatura_especialista FOREIGN KEY (id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
  CONSTRAINT fk_feed_candidatura_autor FOREIGN KEY (submetido_por) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
