-- SE TELECOM v4.20: anexos persistentes do Feed, Oportunidades e Comunicados.
-- Executar uma vez na base de dados existente, depois da migracao_v4_17_feed.sql.
CREATE TABLE IF NOT EXISTS feed_anexos (
  id_anexo BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_publicacao INT UNSIGNED NOT NULL,
  nome_original VARCHAR(240) NOT NULL,
  nome_guardado VARCHAR(80) NOT NULL,
  mime_type VARCHAR(120) NOT NULL,
  tamanho_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_anexo),
  KEY idx_feed_anexos_publicacao (id_publicacao),
  CONSTRAINT fk_feed_anexos_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
