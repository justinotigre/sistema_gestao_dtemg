-- Executar uma vez após cópia de segurança.
ALTER TABLE patentes
 ADD COLUMN grupo_hierarquico VARCHAR(40) NULL,
 ADD COLUMN codigo_equivalencia VARCHAR(40) NULL,
 ADD COLUMN imagem_insignia VARCHAR(255) NULL;
-- Os códigos de equivalência devem ser atribuídos por um administrador
-- segundo a hierarquia efetiva e as equivalências oficiais entre Ramos.
