-- SGE TELECOM V4.44. Executar UMA VEZ, após fazer cópia de segurança.
CREATE TABLE IF NOT EXISTS categorias_civis (
 id_categoria_civil INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(160) NOT NULL UNIQUE,
 ordem INT NOT NULL DEFAULT 100,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
ALTER TABLE especialistas ADD COLUMN id_categoria_civil INT NULL DEFAULT NULL;
ALTER TABLE especialistas ADD CONSTRAINT fk_especialistas_categoria_civil FOREIGN KEY (id_categoria_civil) REFERENCES categorias_civis(id_categoria_civil) ON DELETE SET NULL;
INSERT IGNORE INTO categorias_civis (nome,ordem) VALUES
('Assessor Principal',10),('Primeiro Assessor',20),('Assessor',30),
('Técnico Superior Principal',40),('Técnico Superior de 1.ª Classe',50),('Técnico Superior de 2.ª Classe',60),
('Técnico Especialista Principal',70),('Técnico Especialista de 1.ª Classe',80),('Técnico Especialista de 2.ª Classe',90),
('Técnico de 1.ª Classe',100),('Técnico de 2.ª Classe',110),('Técnico de 3.ª Classe',120),
('Técnico Operacional',130),('Técnico Administrativo',140),('Técnico Auxiliar',150),('Operário',160);
