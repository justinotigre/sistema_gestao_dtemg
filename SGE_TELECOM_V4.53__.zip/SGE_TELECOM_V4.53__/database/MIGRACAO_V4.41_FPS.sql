-- V4.41: retirar FPS com designação Civil das opções novas por desativação.
-- Registos já atribuídos são mantidos. É possível reativar em Configurações > FPS.
UPDATE quadros_servico SET estado='INATIVO' WHERE LOWER(nome) LIKE '%civil%';
