-- SGE TELECOM V4.40
-- Complemento da migração V4.39. Fazer backup antes de executar.
-- Idempotente: cada coluna só é criada quando ainda não existe.

SET @db_name = DATABASE();

SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db_name AND table_name='dados_servico' AND column_name='local_servico')=0,
  'ALTER TABLE dados_servico ADD COLUMN local_servico ENUM(''EMG'',''EXE'',''FAN'',''MGA'') NULL AFTER id_regiao', 'SELECT 1');
PREPARE sge_stmt FROM @sql; EXECUTE sge_stmt; DEALLOCATE PREPARE sge_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db_name AND table_name='dados_servico' AND column_name='local_incorporacao')=0,
  'ALTER TABLE dados_servico ADD COLUMN local_incorporacao VARCHAR(200) NULL AFTER data_incorporacao', 'SELECT 1');
PREPARE sge_stmt FROM @sql; EXECUTE sge_stmt; DEALLOCATE PREPARE sge_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db_name AND table_name='dados_servico' AND column_name='brigada')=0,
  'ALTER TABLE dados_servico ADD COLUMN brigada VARCHAR(150) NULL AFTER local_servico', 'SELECT 1');
PREPARE sge_stmt FROM @sql; EXECUTE sge_stmt; DEALLOCATE PREPARE sge_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db_name AND table_name='dados_servico' AND column_name='batalhao')=0,
  'ALTER TABLE dados_servico ADD COLUMN batalhao VARCHAR(150) NULL AFTER brigada', 'SELECT 1');
PREPARE sge_stmt FROM @sql; EXECUTE sge_stmt; DEALLOCATE PREPARE sge_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db_name AND table_name='dados_servico' AND column_name='pelotao')=0,
  'ALTER TABLE dados_servico ADD COLUMN pelotao VARCHAR(150) NULL AFTER batalhao', 'SELECT 1');
PREPARE sge_stmt FROM @sql; EXECUTE sge_stmt; DEALLOCATE PREPARE sge_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db_name AND table_name='dados_servico' AND column_name='seccao')=0,
  'ALTER TABLE dados_servico ADD COLUMN seccao VARCHAR(150) NULL AFTER pelotao', 'SELECT 1');
PREPARE sge_stmt FROM @sql; EXECUTE sge_stmt; DEALLOCATE PREPARE sge_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db_name AND table_name='especialistas' AND column_name='tipo_especialista')=0,
  'ALTER TABLE especialistas ADD COLUMN tipo_especialista ENUM(''MILITAR'',''CIVIL'') NOT NULL DEFAULT ''MILITAR'' AFTER id_patente', 'SELECT 1');
PREPARE sge_stmt FROM @sql; EXECUTE sge_stmt; DEALLOCATE PREPARE sge_stmt;

-- Atribuir o local de serviço igual ao ramo quando isso é inequívoco.
UPDATE dados_servico ds
JOIN especialistas e ON e.id_especialista=ds.id_especialista
JOIN ramo r ON r.id_ramo=e.id_ramo
SET ds.local_servico=UPPER(r.sigla)
WHERE ds.local_servico IS NULL AND UPPER(r.sigla) IN ('EXE','FAN','MGA');

-- Atenção: registos historicamente associados ao ramo EMG devem ser revistos
-- manualmente antes de os reatribuir a EXE/FAN/MGA. Não alterar o ramo por suposição.
