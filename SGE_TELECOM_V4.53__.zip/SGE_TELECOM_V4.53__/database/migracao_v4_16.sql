-- Migração v4.16: corrigir contagem no Dashboard para especialistas
-- sem ficha de dados pessoais completa. Não elimina nem altera registos.
-- Fazer backup antes de executar. Compatível com MySQL 8 / MariaDB.
CREATE OR REPLACE VIEW vw_especialistas_dashboard AS
SELECT e.id_especialista,e.id_ramo,e.id_quadro,e.id_patente,e.estado estado_cadastro,
 dp.nome_completo,sx.nome sexo,ds.nip,ds.id_unidade,ds.id_regiao,q.nome quadro,p.nome patente,p.ordem ordem_patente,
 ss.nome situacao_servico,ss.grupo grupo_situacao,r.nome ramo_nome,r.sigla ramo_sigla,r.cor_principal ramo_cor,
 rg.nome regiao_nome,dc.numero_bi,dc.data_validade_bi
FROM especialistas e
LEFT JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista
LEFT JOIN dados_pessoais dc ON dc.id_especialista=e.id_especialista
LEFT JOIN quadros_servico q ON q.id_quadro=e.id_quadro
LEFT JOIN patentes p ON p.id_patente=e.id_patente
LEFT JOIN sexos sx ON sx.id_sexo=dp.id_sexo
LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista
LEFT JOIN situacoes_servico ss ON ss.id_situacao_servico=ds.id_situacao_servico
LEFT JOIN ramo r ON r.id_ramo=e.id_ramo
LEFT JOIN regioes rg ON rg.id_regiao=ds.id_regiao;
