-- SE TELECOM v4.20: anexos, reações e comentários persistentes do Feed.
-- Executar depois de migracao_v4_17_feed.sql.
CREATE TABLE IF NOT EXISTS feed_anexos (
 id_anexo BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 id_publicacao INT UNSIGNED NOT NULL,
 nome_original VARCHAR(240) NOT NULL,
 nome_guardado VARCHAR(80) NOT NULL,
 mime_type VARCHAR(120) NOT NULL,
 tamanho_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
 criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id_anexo), KEY idx_feed_anexos_publicacao (id_publicacao),
 CONSTRAINT fk_feed_anexo_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_reacoes (
 id_publicacao INT UNSIGNED NOT NULL, id_utilizador INT NOT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id_publicacao,id_utilizador), KEY idx_feed_reacao_utilizador (id_utilizador),
 CONSTRAINT fk_feed_reacao_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
 CONSTRAINT fk_feed_reacao_utilizador FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_comentarios (
 id_comentario BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, id_publicacao INT UNSIGNED NOT NULL, id_utilizador INT NOT NULL, comentario TEXT NOT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id_comentario), KEY idx_feed_comentarios_publicacao (id_publicacao), KEY idx_feed_comentarios_utilizador (id_utilizador),
 CONSTRAINT fk_feed_comentario_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
 CONSTRAINT fk_feed_comentario_utilizador FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
