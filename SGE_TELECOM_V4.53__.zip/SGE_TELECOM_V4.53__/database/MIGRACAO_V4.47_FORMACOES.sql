-- Executar uma única vez, após cópia de segurança.
ALTER TABLE feed_oportunidade_config
 ADD COLUMN tipo_especialista_criterio VARCHAR(12) NULL,
 ADD COLUMN local_servico_criterio VARCHAR(12) NULL;
