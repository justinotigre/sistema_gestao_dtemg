-- SGE TELECOM V4.31: catálogo de cursos e filtros por idade para oportunidades.
-- Execute na base de dados ativa após criar uma cópia de segurança.
CREATE TABLE IF NOT EXISTS cursos_habilitacao (
 id_curso INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(200) NOT NULL UNIQUE,
 estado VARCHAR(12) NOT NULL DEFAULT 'ATIVO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO cursos_habilitacao(nome)
 SELECT DISTINCT TRIM(curso) FROM habilitacoes_literarias WHERE curso IS NOT NULL AND TRIM(curso)<>'';
INSERT IGNORE INTO cursos_habilitacao(nome) VALUES
 ('Engenharia Informática'),('Engenharia de Telecomunicações'),('Gestão'),('Administração Pública'),('Direito'),('Medicina'),('Enfermagem'),('Contabilidade'),('Informática'),('Logística');
-- Reexecutável: só cria as colunas se ainda não existirem.
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='feed_oportunidade_config' AND column_name='idade_minima')=0,'ALTER TABLE feed_oportunidade_config ADD COLUMN idade_minima INT NULL','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='feed_oportunidade_config' AND column_name='idade_maxima')=0,'ALTER TABLE feed_oportunidade_config ADD COLUMN idade_maxima INT NULL','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
