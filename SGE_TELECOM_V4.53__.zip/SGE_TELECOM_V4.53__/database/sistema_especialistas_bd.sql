-- ============================================================
-- SISTEMA DE GESTÃO DE ESPECIALISTAS — v4.9.3
-- Esquema consolidado RH + Recursos Materiais + Regiões + Auditoria
-- ============================================================
CREATE DATABASE IF NOT EXISTS sistema_especialistas_v3 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_especialistas_v3;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
DROP VIEW IF EXISTS vw_especialistas_dashboard;
DROP TABLE IF EXISTS auditoria, modelos_relatorio, historico_equipamentos, historico_especialistas, dados_residencia, regiao_provincias, utilizador_regiao,
 notificacoes, solicitacoes, documentos, fotografias, equipamentos, historico_configuracoes, vestuario, licencas, tipos_licenca,
 grupos_sanguineos, condecoracoes, habilitacoes_literarias, formacoes, dados_servico, familiares, dados_pessoais, especialistas,
 utilizador_unidade, utilizador_ramo, utilizadores, perfil_permissoes, permissoes, perfis, configuracoes_alertas, tipos_alerta,
 modelos_solicitacao, tipos_condecoracao, estados_equipamento, tipos_equipamento, tipos_documento, niveis_habilitacao,
 tipos_formacao, instituicoes, graus_parentesco, situacoes_servico, quadros_servico, patentes, funcoes, departamentos, unidades,
 municipios, provincias, paises, regioes, ramo, sexos, estados_civis;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE ramo (
 id_ramo INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(150) NOT NULL,
 sigla VARCHAR(30) NOT NULL UNIQUE,
 descricao TEXT,
 logo VARCHAR(500), imagem_fundo VARCHAR(500),
 cor_principal VARCHAR(20) DEFAULT '#327aa4', cor_secundaria VARCHAR(20),
 ordem INT NOT NULL DEFAULT 999,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
 data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_ramo_ordem (ordem), INDEX idx_ramo_estado (estado)
) ENGINE=InnoDB;

CREATE TABLE regioes (
 id_regiao INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(150) NOT NULL UNIQUE,
 sigla VARCHAR(30) UNIQUE,
 descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
 data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE paises (
 id_pais INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(150) NOT NULL UNIQUE,
 codigo VARCHAR(10) UNIQUE,
 nacionalidade VARCHAR(100),
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
 data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE provincias (
 id_provincia INT AUTO_INCREMENT PRIMARY KEY,
 id_pais INT NOT NULL,
 nome VARCHAR(150) NOT NULL,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
 data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_prov_pais_nome(id_pais,nome),
 FOREIGN KEY(id_pais) REFERENCES paises(id_pais) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE municipios (
 id_municipio INT AUTO_INCREMENT PRIMARY KEY,
 id_provincia INT NOT NULL,
 nome VARCHAR(150) NOT NULL,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
 data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_mun_prov_nome(id_provincia,nome),
 FOREIGN KEY(id_provincia) REFERENCES provincias(id_provincia) ON DELETE RESTRICT,
 INDEX idx_municipios_provincia(id_provincia)
) ENGINE=InnoDB;

CREATE TABLE regiao_provincias (
 id_regiao INT NOT NULL, id_provincia INT NOT NULL,
 PRIMARY KEY(id_regiao,id_provincia),
 FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE CASCADE,
 FOREIGN KEY(id_provincia) REFERENCES provincias(id_provincia) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE perfis (
 id_perfil INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL UNIQUE,
 descricao TEXT,
 nivel_acesso ENUM('GLOBAL','REGIAO','RAMO','UNIDADE') NOT NULL,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
 data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE permissoes (
 id_permissao INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(120) NOT NULL UNIQUE,
 modulo VARCHAR(100) NOT NULL,
 descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
 data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE utilizadores (
 id_utilizador INT AUTO_INCREMENT PRIMARY KEY,
 nome_utilizador VARCHAR(100) NOT NULL UNIQUE,
 senha VARCHAR(255) NOT NULL,
 email VARCHAR(150) UNIQUE,
 id_perfil INT NOT NULL,
 id_especialista INT NULL,
 tipo_responsabilidade ENUM('REGIAO','RAMO','UNIDADE','ESPECIALISTA') NULL,
 id_regiao_responsabilidade INT NULL,
 id_ramo_responsabilidade INT NULL,
 id_unidade_responsabilidade INT NULL,
 id_especialista_responsabilidade INT NULL,
 foto VARCHAR(500) NULL,
 tema ENUM('CLARO','ESCURO') NOT NULL DEFAULT 'CLARO',
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
 data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 data_atualizacao DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
 ultimo_acesso DATETIME NULL,
 FOREIGN KEY(id_perfil) REFERENCES perfis(id_perfil) ON UPDATE CASCADE ON DELETE RESTRICT,
 INDEX idx_utilizadores_perfil(id_perfil), INDEX idx_utilizadores_estado(estado),
 UNIQUE KEY uq_utilizador_especialista(id_especialista)
) ENGINE=InnoDB;

CREATE TABLE utilizador_regiao (
 id_utilizador INT NOT NULL, id_regiao INT NOT NULL,
 PRIMARY KEY(id_utilizador,id_regiao),
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE,
 FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE utilizador_ramo (
 id_utilizador INT NOT NULL, id_ramo INT NOT NULL,
 PRIMARY KEY(id_utilizador,id_ramo),
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE,
 FOREIGN KEY(id_ramo) REFERENCES ramo(id_ramo) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE perfil_permissoes (
 id_perfil INT NOT NULL, id_permissao INT NOT NULL,
 PRIMARY KEY(id_perfil,id_permissao),
 FOREIGN KEY(id_perfil) REFERENCES perfis(id_perfil) ON DELETE CASCADE,
 FOREIGN KEY(id_permissao) REFERENCES permissoes(id_permissao) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE unidades (
 id_unidade INT AUTO_INCREMENT PRIMARY KEY,
 id_ramo INT NOT NULL, id_regiao INT NULL, nome VARCHAR(200) NOT NULL, sigla VARCHAR(50), localizacao VARCHAR(200), descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_unidade_ramo_nome(id_ramo,nome), FOREIGN KEY(id_ramo) REFERENCES ramo(id_ramo) ON DELETE RESTRICT, FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE departamentos (
 id_departamento INT AUTO_INCREMENT PRIMARY KEY,
 id_unidade INT NOT NULL, nome VARCHAR(200) NOT NULL, sigla VARCHAR(50), descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_departamento_unidade_nome(id_unidade,nome), FOREIGN KEY(id_unidade) REFERENCES unidades(id_unidade) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE utilizador_unidade (
 id_utilizador INT NOT NULL, id_unidade INT NOT NULL,
 PRIMARY KEY(id_utilizador,id_unidade),
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE,
 FOREIGN KEY(id_unidade) REFERENCES unidades(id_unidade) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE funcoes (
 id_funcao INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(200) NOT NULL UNIQUE, descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE quadros_servico (
 id_quadro INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(150) NOT NULL UNIQUE, sigla VARCHAR(30), descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE patentes (
 id_patente INT AUTO_INCREMENT PRIMARY KEY,
 id_ramo INT NOT NULL, nome VARCHAR(150) NOT NULL, sigla VARCHAR(50), ordem INT NOT NULL DEFAULT 0, descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_patente_ramo_nome(id_ramo,nome), UNIQUE KEY uq_patente_ramo_id(id_ramo,id_patente),
 FOREIGN KEY(id_ramo) REFERENCES ramo(id_ramo) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE sexos (
 id_sexo INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(50) NOT NULL UNIQUE,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE estados_civis (
 id_estado_civil INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100) NOT NULL UNIQUE,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE situacoes_servico (
 id_situacao_servico INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(150) NOT NULL UNIQUE,
 grupo ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
 descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO'
) ENGINE=InnoDB;

CREATE TABLE graus_parentesco (
 id_grau_parentesco INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100) NOT NULL UNIQUE, descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE instituicoes (
 id_instituicao INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(200) NOT NULL UNIQUE, sigla VARCHAR(50), id_pais INT NULL,
 localizacao VARCHAR(200), descricao TEXT, estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_pais) REFERENCES paises(id_pais) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE tipos_formacao (
 id_tipo_formacao INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(150) NOT NULL UNIQUE,
 categoria ENUM('MILITAR','GERAL') NOT NULL DEFAULT 'GERAL', descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE niveis_habilitacao (
 id_nivel_habilitacao INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(150) NOT NULL UNIQUE, ordem INT NOT NULL DEFAULT 0, descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE tipos_documento (
 id_tipo_documento INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(150) NOT NULL UNIQUE, descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE tipos_equipamento (
 id_tipo_equipamento INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(150) NOT NULL UNIQUE, descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE estados_equipamento (
 id_estado_equipamento INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(150) NOT NULL UNIQUE, descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE tipos_condecoracao (
 id_tipo_condecoracao INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(200) NOT NULL UNIQUE, descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE grupos_sanguineos (
 id_grupo_sanguineo INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(20) NOT NULL UNIQUE,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE tipos_licenca (
 id_tipo_licenca INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(150) NOT NULL UNIQUE, codigo VARCHAR(50) NOT NULL UNIQUE, descricao TEXT,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE especialistas (
 id_especialista INT AUTO_INCREMENT PRIMARY KEY,
 id_ramo INT NOT NULL, id_quadro INT NULL, id_patente INT NULL,
 estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO', data_registo DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, observacoes TEXT,
 FOREIGN KEY(id_ramo) REFERENCES ramo(id_ramo) ON DELETE RESTRICT,
 FOREIGN KEY(id_quadro) REFERENCES quadros_servico(id_quadro) ON DELETE RESTRICT,
 FOREIGN KEY(id_patente) REFERENCES patentes(id_patente) ON DELETE RESTRICT,
 FOREIGN KEY(id_ramo,id_patente) REFERENCES patentes(id_ramo,id_patente) ON DELETE RESTRICT,
 INDEX idx_especialistas_ramo(id_ramo), INDEX idx_especialistas_quadro(id_quadro), INDEX idx_especialistas_patente(id_patente), INDEX idx_especialistas_estado(estado)
) ENGINE=InnoDB;

CREATE TABLE dados_pessoais (
 id_dados_pessoais INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL UNIQUE,
 nome_completo VARCHAR(200) NOT NULL, data_nascimento DATE,
 id_sexo INT, id_pais_nascimento INT, id_provincia_nascimento INT, id_municipio_nascimento INT,
 id_pais_nacionalidade INT, id_estado_civil INT, numero_bi VARCHAR(50) UNIQUE, data_emissao_bi DATE, data_validade_bi DATE,
 local_emissao_bi VARCHAR(150), id_grupo_sanguineo INT NULL, peso_kg DECIMAL(6,2) NULL,
 telefone VARCHAR(30), telefone_alternativo VARCHAR(30), email VARCHAR(150), morada TEXT,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_sexo) REFERENCES sexos(id_sexo) ON DELETE RESTRICT,
 FOREIGN KEY(id_pais_nascimento) REFERENCES paises(id_pais) ON DELETE RESTRICT,
 FOREIGN KEY(id_provincia_nascimento) REFERENCES provincias(id_provincia) ON DELETE RESTRICT,
 FOREIGN KEY(id_municipio_nascimento) REFERENCES municipios(id_municipio) ON DELETE RESTRICT,
 FOREIGN KEY(id_pais_nacionalidade) REFERENCES paises(id_pais) ON DELETE RESTRICT,
 FOREIGN KEY(id_estado_civil) REFERENCES estados_civis(id_estado_civil) ON DELETE RESTRICT,
 FOREIGN KEY(id_grupo_sanguineo) REFERENCES grupos_sanguineos(id_grupo_sanguineo) ON DELETE RESTRICT,
 INDEX idx_dp_nome(nome_completo), INDEX idx_dp_bi(numero_bi)
) ENGINE=InnoDB;

CREATE TABLE dados_residencia (
 id_residencia INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL UNIQUE,
 id_provincia INT NULL, id_municipio INT NULL, bairro VARCHAR(150), rua VARCHAR(200), casa VARCHAR(80), ponto_referencia VARCHAR(255),
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_provincia) REFERENCES provincias(id_provincia) ON DELETE RESTRICT,
 FOREIGN KEY(id_municipio) REFERENCES municipios(id_municipio) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE dados_servico (
 id_dados_servico INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL UNIQUE,
 nip VARCHAR(50) NULL UNIQUE, numero_processo VARCHAR(50), data_incorporacao DATE, data_promocao DATE,
 id_funcao INT, id_unidade INT, id_departamento INT, id_situacao_servico INT, id_regiao INT NULL,
 data_inicio_funcao DATE, data_fim_funcao DATE, observacoes TEXT,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_funcao) REFERENCES funcoes(id_funcao) ON DELETE RESTRICT,
 FOREIGN KEY(id_unidade) REFERENCES unidades(id_unidade) ON DELETE RESTRICT,
 FOREIGN KEY(id_departamento) REFERENCES departamentos(id_departamento) ON DELETE RESTRICT,
 FOREIGN KEY(id_situacao_servico) REFERENCES situacoes_servico(id_situacao_servico) ON DELETE RESTRICT,
 FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE RESTRICT,
 INDEX idx_ds_unidade(id_unidade), INDEX idx_ds_departamento(id_departamento), INDEX idx_ds_funcao(id_funcao), INDEX idx_ds_situacao(id_situacao_servico), INDEX idx_ds_regiao(id_regiao)
) ENGINE=InnoDB;

CREATE TABLE familiares (
 id_familiar INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL, nome VARCHAR(200) NOT NULL, id_grau_parentesco INT, data_nascimento DATE,
 profissao VARCHAR(150), telefone VARCHAR(30), morada TEXT, observacoes TEXT,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_grau_parentesco) REFERENCES graus_parentesco(id_grau_parentesco) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE formacoes (
 id_formacao INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL, categoria ENUM('MILITAR','GERAL') NOT NULL,
 id_tipo_formacao INT, designacao VARCHAR(200) NOT NULL, id_instituicao INT, id_pais INT, id_provincia INT NULL, local VARCHAR(150),
 data_inicio DATE, data_fim DATE, duracao VARCHAR(100), certificado VARCHAR(100), observacoes TEXT,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_tipo_formacao) REFERENCES tipos_formacao(id_tipo_formacao) ON DELETE RESTRICT,
 FOREIGN KEY(id_instituicao) REFERENCES instituicoes(id_instituicao) ON DELETE RESTRICT,
 FOREIGN KEY(id_pais) REFERENCES paises(id_pais) ON DELETE RESTRICT,
 FOREIGN KEY(id_provincia) REFERENCES provincias(id_provincia) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE habilitacoes_literarias (
 id_habilitacao INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL, categoria ENUM('MILITAR','GERAL') NOT NULL,
 id_nivel_habilitacao INT, curso VARCHAR(200), id_instituicao INT, id_pais INT, data_inicio DATE, data_conclusao DATE,
 numero_certificado VARCHAR(100), observacoes TEXT,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_nivel_habilitacao) REFERENCES niveis_habilitacao(id_nivel_habilitacao) ON DELETE RESTRICT,
 FOREIGN KEY(id_instituicao) REFERENCES instituicoes(id_instituicao) ON DELETE RESTRICT,
 FOREIGN KEY(id_pais) REFERENCES paises(id_pais) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE condecoracoes (
 id_condecoracao INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL, id_tipo_condecoracao INT, entidade VARCHAR(200), data_atribuicao DATE,
 motivo TEXT, numero_documento VARCHAR(100), observacoes TEXT,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_tipo_condecoracao) REFERENCES tipos_condecoracao(id_tipo_condecoracao) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE ferias (
 id_ferias INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL, ano YEAR NOT NULL, data_inicio DATE NOT NULL, data_fim DATE NOT NULL,
 numero_dias INT NOT NULL, estado ENUM('PROGRAMADA','EM_CURSO','CONCLUIDA','CANCELADA') DEFAULT 'PROGRAMADA', observacoes TEXT, data_registo DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE, INDEX idx_ferias_datas(data_inicio,data_fim,estado)
) ENGINE=InnoDB;

CREATE TABLE licencas (
 id_licenca INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL, id_tipo_licenca INT NOT NULL, data_inicio DATE NOT NULL, data_fim DATE NULL,
 numero_dias INT NULL, estado VARCHAR(50) NOT NULL DEFAULT 'ATIVA', observacoes TEXT, data_registo DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE, FOREIGN KEY(id_tipo_licenca) REFERENCES tipos_licenca(id_tipo_licenca) ON DELETE RESTRICT,
 INDEX idx_licencas_especialista(id_especialista), INDEX idx_licencas_datas(data_inicio,data_fim)
) ENGINE=InnoDB;

CREATE TABLE vestuario (
 id_vestuario INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL UNIQUE, numero_calca VARCHAR(30), numero_camisa VARCHAR(30), numero_sapato VARCHAR(30),
 numero_bota VARCHAR(30), numero_boina VARCHAR(30), numero_quiko VARCHAR(30), numero_casaco VARCHAR(30), outros VARCHAR(255),
 data_atualizacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE historico_configuracoes (
 id_historico BIGINT AUTO_INCREMENT PRIMARY KEY, tabela VARCHAR(100) NOT NULL, id_registo INT NOT NULL, acao VARCHAR(50) NOT NULL,
 dados_anteriores JSON NULL, dados_novos JSON NULL, id_utilizador INT NULL, data_registo DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL, INDEX idx_hist_tabela_registo(tabela,id_registo), INDEX idx_hist_utilizador(id_utilizador), INDEX idx_hist_data(data_registo)
) ENGINE=InnoDB;

CREATE TABLE historico_especialistas (
 id_historico BIGINT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL,
 tipo_evento ENUM('PROMOCAO','MOVIMENTACAO_UNIDADE','ALTERACAO_FUNCAO','ALTERACAO_RAMO','ALTERACAO_REGIAO','ALTERACAO_QUADRO','ALTERACAO_SITUACAO','ALTERACAO_DADOS','OUTRO') NOT NULL,
 campo VARCHAR(100), valor_anterior VARCHAR(500), valor_novo VARCHAR(500), data_inicio DATE NULL, data_fim DATE NULL,
 id_documento INT NULL, motivo TEXT, observacoes TEXT, id_utilizador INT NULL, data_registo DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL,
 INDEX idx_he_especialista(id_especialista), INDEX idx_he_tipo(tipo_evento), INDEX idx_he_data(data_registo)
) ENGINE=InnoDB;

CREATE TABLE equipamentos (
 id_equipamento INT AUTO_INCREMENT PRIMARY KEY, id_ramo INT NOT NULL, id_regiao INT NULL, id_unidade INT NULL, id_especialista_responsavel INT NULL,
 id_tipo_equipamento INT, designacao VARCHAR(200) NOT NULL, marca VARCHAR(100), modelo VARCHAR(100), numero_serie VARCHAR(100) UNIQUE,
 numero_patrimonio VARCHAR(100), data_aquisicao DATE, id_estado_equipamento INT, localizacao VARCHAR(200), descricao TEXT, observacoes TEXT,
 FOREIGN KEY(id_ramo) REFERENCES ramo(id_ramo) ON DELETE RESTRICT, FOREIGN KEY(id_regiao) REFERENCES regioes(id_regiao) ON DELETE RESTRICT,
 FOREIGN KEY(id_unidade) REFERENCES unidades(id_unidade) ON DELETE RESTRICT, FOREIGN KEY(id_especialista_responsavel) REFERENCES especialistas(id_especialista) ON DELETE SET NULL,
 FOREIGN KEY(id_tipo_equipamento) REFERENCES tipos_equipamento(id_tipo_equipamento) ON DELETE RESTRICT, FOREIGN KEY(id_estado_equipamento) REFERENCES estados_equipamento(id_estado_equipamento) ON DELETE RESTRICT,
 INDEX idx_eq_ramo_regiao(id_ramo,id_regiao), INDEX idx_eq_unidade(id_unidade), INDEX idx_eq_responsavel(id_especialista_responsavel)
) ENGINE=InnoDB;

CREATE TABLE historico_equipamentos (
 id_historico BIGINT AUTO_INCREMENT PRIMARY KEY, id_equipamento INT NOT NULL, evento VARCHAR(80) NOT NULL, campo VARCHAR(100), valor_anterior VARCHAR(500), valor_novo VARCHAR(500), motivo TEXT, id_utilizador INT NULL, data_registo DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_equipamento) REFERENCES equipamentos(id_equipamento) ON DELETE SET NULL, FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL, INDEX idx_heequip(id_equipamento), INDEX idx_heeq_data(data_registo)
) ENGINE=InnoDB;

CREATE TABLE fotografias (
 id_fotografia INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NULL, id_equipamento INT NULL, nome_ficheiro VARCHAR(255) NOT NULL,
 caminho_ficheiro VARCHAR(500) NOT NULL, data_registo DATETIME DEFAULT CURRENT_TIMESTAMP, principal BOOLEAN DEFAULT FALSE, descricao TEXT,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE, FOREIGN KEY(id_equipamento) REFERENCES equipamentos(id_equipamento) ON DELETE SET NULL,
 CONSTRAINT chk_foto_owner CHECK((id_especialista IS NOT NULL AND id_equipamento IS NULL) OR (id_especialista IS NULL AND id_equipamento IS NOT NULL)),
 INDEX idx_foto_esp(id_especialista), INDEX idx_foto_eq(id_equipamento)
) ENGINE=InnoDB;

CREATE TABLE documentos (
 id_documento INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NULL, id_equipamento INT NULL, id_tipo_documento INT NOT NULL, titulo VARCHAR(200) NOT NULL,
 nome_ficheiro VARCHAR(255) NOT NULL, caminho_ficheiro VARCHAR(500) NOT NULL, data_documento DATE, data_validade DATE, descricao TEXT, data_registo DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE, FOREIGN KEY(id_equipamento) REFERENCES equipamentos(id_equipamento) ON DELETE SET NULL,
 FOREIGN KEY(id_tipo_documento) REFERENCES tipos_documento(id_tipo_documento) ON DELETE RESTRICT,
 CONSTRAINT chk_doc_owner CHECK((id_especialista IS NOT NULL AND id_equipamento IS NULL) OR (id_especialista IS NULL AND id_equipamento IS NOT NULL)),
 CONSTRAINT chk_doc_dates CHECK(data_validade IS NULL OR data_documento IS NULL OR data_validade>=data_documento), INDEX idx_doc_validade(data_validade)
) ENGINE=InnoDB;

CREATE TABLE tipos_alerta (
 id_tipo_alerta INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(150) NOT NULL, codigo VARCHAR(100) NOT NULL UNIQUE, descricao TEXT,
 nivel_padrao ENUM('INFO','ATENCAO','URGENTE') DEFAULT 'INFO', dias_antecedencia INT DEFAULT 0, estado ENUM('ATIVO','INATIVO') DEFAULT 'ATIVO'
) ENGINE=InnoDB;

CREATE TABLE configuracoes_alertas (
 id_configuracao_alerta INT AUTO_INCREMENT PRIMARY KEY, id_tipo_alerta INT NOT NULL, id_ramo INT NULL, dias_antecedencia INT DEFAULT 0, ativo BOOLEAN DEFAULT TRUE, descricao TEXT,
 UNIQUE KEY uq_alerta_ramo(id_tipo_alerta,id_ramo), FOREIGN KEY(id_tipo_alerta) REFERENCES tipos_alerta(id_tipo_alerta) ON DELETE CASCADE, FOREIGN KEY(id_ramo) REFERENCES ramo(id_ramo) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE modelos_solicitacao (
 id_modelo INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(200) NOT NULL, codigo VARCHAR(100) NOT NULL UNIQUE, assunto VARCHAR(255), conteudo LONGTEXT,
 categoria VARCHAR(100), estado ENUM('ATIVO','INATIVO') DEFAULT 'ATIVO', data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP, data_atualizacao DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE modelos_relatorio (
 id_modelo_relatorio INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(200) NOT NULL UNIQUE, categoria ENUM('ESPECIALISTAS','EQUIPAMENTOS','EFETIVIDADE') NOT NULL,
 entidade VARCHAR(50) NOT NULL, titulo VARCHAR(255), orientacao ENUM('RETRATO','PAISAGEM') DEFAULT 'PAISAGEM', campos JSON NULL, filtros JSON NULL,
 estado ENUM('ATIVO','INATIVO') DEFAULT 'ATIVO', data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP, data_atualizacao DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE solicitacoes (
 id_solicitacao INT AUTO_INCREMENT PRIMARY KEY, id_especialista INT NOT NULL, id_modelo INT NOT NULL, id_utilizador INT NOT NULL, id_ramo INT NOT NULL,
 numero VARCHAR(50) NOT NULL UNIQUE, data_solicitacao DATETIME DEFAULT CURRENT_TIMESTAMP, estado ENUM('RASCUNHO','PENDENTE','EMITIDA','CANCELADA') DEFAULT 'RASCUNHO', conteudo_gerado LONGTEXT, observacoes TEXT,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE RESTRICT, FOREIGN KEY(id_modelo) REFERENCES modelos_solicitacao(id_modelo) ON DELETE RESTRICT,
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE RESTRICT, FOREIGN KEY(id_ramo) REFERENCES ramo(id_ramo) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE notificacoes (
 id_notificacao INT AUTO_INCREMENT PRIMARY KEY, id_ramo INT NOT NULL, id_utilizador INT NOT NULL, id_especialista INT NULL, id_equipamento INT NULL, id_tipo_alerta INT NOT NULL,
 titulo VARCHAR(255) NOT NULL, mensagem TEXT, nivel ENUM('INFO','ATENCAO','URGENTE') DEFAULT 'INFO', data_referencia DATETIME NULL, lida BOOLEAN DEFAULT FALSE, data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP, data_leitura DATETIME NULL,
 FOREIGN KEY(id_ramo) REFERENCES ramo(id_ramo) ON DELETE CASCADE, FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE,
 FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE, FOREIGN KEY(id_equipamento) REFERENCES equipamentos(id_equipamento) ON DELETE SET NULL,
 FOREIGN KEY(id_tipo_alerta) REFERENCES tipos_alerta(id_tipo_alerta) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE auditoria (
 id_auditoria BIGINT AUTO_INCREMENT PRIMARY KEY, id_utilizador INT NULL, categoria VARCHAR(80) NOT NULL, evento VARCHAR(120) NOT NULL, modulo VARCHAR(100), entidade VARCHAR(100), id_registo INT NULL,
 descricao TEXT, dados_anteriores JSON NULL, dados_novos JSON NULL, ip VARCHAR(45), user_agent VARCHAR(500), localizacao VARCHAR(255), resultado ENUM('SUCESSO','FALHA') NOT NULL DEFAULT 'SUCESSO', data_evento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL,
 INDEX idx_aud_data(data_evento), INDEX idx_aud_user(id_utilizador), INDEX idx_aud_categoria(categoria), INDEX idx_aud_evento(evento), INDEX idx_aud_modulo(modulo)
) ENGINE=InnoDB;

ALTER TABLE utilizadores
 ADD CONSTRAINT fk_user_especialista FOREIGN KEY(id_especialista) REFERENCES especialistas(id_especialista) ON UPDATE CASCADE ON DELETE SET NULL,
 ADD CONSTRAINT fk_user_regiao_resp FOREIGN KEY(id_regiao_responsabilidade) REFERENCES regioes(id_regiao) ON UPDATE CASCADE ON DELETE SET NULL,
 ADD CONSTRAINT fk_user_ramo_resp FOREIGN KEY(id_ramo_responsabilidade) REFERENCES ramo(id_ramo) ON UPDATE CASCADE ON DELETE SET NULL,
 ADD CONSTRAINT fk_user_unidade_resp FOREIGN KEY(id_unidade_responsabilidade) REFERENCES unidades(id_unidade) ON UPDATE CASCADE ON DELETE SET NULL,
 ADD CONSTRAINT fk_user_esp_resp FOREIGN KEY(id_especialista_responsabilidade) REFERENCES especialistas(id_especialista) ON UPDATE CASCADE ON DELETE SET NULL;

-- ============================================================
-- DADOS INICIAIS
-- ============================================================
INSERT INTO ramo(nome,sigla,cor_principal,cor_secundaria,ordem) VALUES
('Estado Maior','EMG','#E58A22','#F3C98B',1),
('Exército','EXE','#788B3A','#B7C28A',2),
('Força Aérea Nacional','FAN','#55AEE0','#BFE5F7',3),
('Marinha de Guerra Angolana','MGA','#FFFFFF','#B9C1C7',4);

INSERT INTO regioes(nome,sigla,descricao) VALUES
('Região Norte','NORTE','Agrupamento administrativo inicial; pode ser ajustado em Configurações.'),
('Região Centro','CENTRO','Agrupamento administrativo inicial; pode ser ajustado em Configurações.'),
('Região Leste','LESTE','Agrupamento administrativo inicial; pode ser ajustado em Configurações.'),
('Região Sul','SUL','Agrupamento administrativo inicial; pode ser ajustado em Configurações.');

INSERT INTO paises(nome,codigo,nacionalidade) VALUES
('Afeganistão','AF',NULL),('Alanda','AX',NULL),('Albânia','AL',NULL),('Alemanha','DE',NULL),('Andorra','AD',NULL),('Angola','AO',NULL),('Anguila','AI',NULL),('Antártida','AQ',NULL),('Antígua e Barbuda','AG',NULL),('Argentina','AR',NULL),('Argélia','DZ',NULL),('Arménia','AM',NULL),('Aruba','AW',NULL),('Arábia Saudita','SA',NULL),('Austrália','AU',NULL),('Azerbaijão','AZ',NULL),('Baamas','BS',NULL),('Bangladeche','BD',NULL),('Barbados','BB',NULL),('Barém','BH',NULL),('Belize','BZ',NULL),('Benim','BJ',NULL),('Bermudas','BM',NULL),('Bielorrússia','BY',NULL),('Bolívia','BO',NULL),('Botsuana','BW',NULL),('Brasil','BR',NULL),('Brunei','BN',NULL),('Bulgária','BG',NULL),('Burquina Faso','BF',NULL),('Burundi','BI',NULL),('Butão','BT',NULL),('Bélgica','BE',NULL),('Bósnia e Herzegovina','BA',NULL),('Cabo Verde','CV',NULL),('Camarões','CM',NULL),('Camboja','KH',NULL),('Canadá','CA',NULL),('Catar','QA',NULL),('Cazaquistão','KZ',NULL),('Chade','TD',NULL),('Chile','CL',NULL),('China','CN',NULL),('Chipre','CY',NULL),('Chéquia','CZ',NULL),('Cidade do Vaticano','VA',NULL),('Colômbia','CO',NULL),('Comores','KM',NULL),('Congo-Brazzaville','CG',NULL),('Congo-Kinshasa','CD',NULL),('Coreia do Norte','KP',NULL),('Coreia do Sul','KR',NULL),('Costa Rica','CR',NULL),('Croácia','HR',NULL),('Cuba','CU',NULL),('Curaçau','CW',NULL),('Côte d’Ivoire (Costa do Marfim)','CI',NULL),('Dinamarca','DK',NULL),('Domínica','DM',NULL),('Egito','EG',NULL),('Emirados Árabes Unidos','AE',NULL),('Equador','EC',NULL),('Eritreia','ER',NULL),('Eslováquia','SK',NULL),('Eslovénia','SI',NULL),('Espanha','ES',NULL),('Essuatíni','SZ',NULL),('Estados Unidos','US',NULL),('Estónia','EE',NULL),('Etiópia','ET',NULL),('Fiji','FJ',NULL),('Filipinas','PH',NULL),('Finlândia','FI',NULL),('França','FR',NULL),('Gabão','GA',NULL),('Gana','GH',NULL),('Geórgia','GE',NULL),('Gibraltar','GI',NULL),('Granada','GD',NULL),('Gronelândia','GL',NULL),('Grécia','GR',NULL),('Guadalupe','GP',NULL),('Guame','GU',NULL),('Guatemala','GT',NULL),('Guernesey','GG',NULL),('Guiana','GY',NULL),('Guiana Francesa','GF',NULL),('Guiné','GN',NULL),('Guiné Equatorial','GQ',NULL),('Guiné-Bissau','GW',NULL),('Gâmbia','GM',NULL),('Haiti','HT',NULL),('Honduras','HN',NULL),('Hong Kong, RAE da China','HK',NULL),('Hungria','HU',NULL),('Ilha Bouvet','BV',NULL),('Ilha Norfolk','NF',NULL),('Ilha de Man','IM',NULL),('Ilha do Natal','CX',NULL),('Ilhas Caimão','KY',NULL),('Ilhas Cook','CK',NULL),('Ilhas Falkland','FK',NULL),('Ilhas Faroé','FO',NULL),('Ilhas Geórgia do Sul e Sandwich do Sul','GS',NULL),('Ilhas Heard e McDonald','HM',NULL),('Ilhas Marianas do Norte','MP',NULL),('Ilhas Marshall','MH',NULL),('Ilhas Menores Afastadas dos EUA','UM',NULL),('Ilhas Pitcairn','PN',NULL),('Ilhas Salomão','SB',NULL),('Ilhas Turcas e Caicos','TC',NULL),('Ilhas Virgens Britânicas','VG',NULL),('Ilhas Virgens dos EUA','VI',NULL),('Ilhas dos Cocos (Keeling)','CC',NULL),('Indonésia','ID',NULL),('Iraque','IQ',NULL),('Irlanda','IE',NULL),('Irão','IR',NULL),('Islândia','IS',NULL),('Israel','IL',NULL),('Itália','IT',NULL),('Iémen','YE',NULL),('Jamaica','JM',NULL),('Japão','JP',NULL),('Jersey','JE',NULL),('Jibuti','DJ',NULL),('Jordânia','JO',NULL),('Koweit','KW',NULL),('Laos','LA',NULL),('Lesoto','LS',NULL),('Letónia','LV',NULL),('Libéria','LR',NULL),('Listenstaine','LI',NULL),('Lituânia','LT',NULL),('Luxemburgo','LU',NULL),('Líbano','LB',NULL),('Líbia','LY',NULL),('Macau, RAE da China','MO',NULL),('Macedónia do Norte','MK',NULL),('Madagáscar','MG',NULL),('Maiote','YT',NULL),('Maldivas','MV',NULL),('Mali','ML',NULL),('Malta','MT',NULL),('Malásia','MY',NULL),('Maláui','MW',NULL),('Marrocos','MA',NULL),('Martinica','MQ',NULL),('Mauritânia','MR',NULL),('Maurícia','MU',NULL),('Mianmar (Birmânia)','MM',NULL),('Micronésia','FM',NULL),('Moldávia','MD',NULL),('Mongólia','MN',NULL),('Monserrate','MS',NULL),('Montenegro','ME',NULL),('Moçambique','MZ',NULL),('México','MX',NULL),('Mónaco','MC',NULL),('Namíbia','NA',NULL),('Nauru','NR',NULL),('Nepal','NP',NULL),('Nicarágua','NI',NULL),('Nigéria','NG',NULL),('Niuê','NU',NULL),('Noruega','NO',NULL),('Nova Caledónia','NC',NULL),('Nova Zelândia','NZ',NULL),('Níger','NE',NULL),('Omã','OM',NULL),('Palau','PW',NULL),('Panamá','PA',NULL),('Papua-Nova Guiné','PG',NULL),('Paquistão','PK',NULL),('Paraguai','PY',NULL),('Países Baixos','NL',NULL),('Países Baixos Caribenhos','BQ',NULL),('Peru','PE',NULL),('Polinésia Francesa','PF',NULL),('Polónia','PL',NULL),('Porto Rico','PR',NULL),('Portugal','PT',NULL),('Quirguistão','KG',NULL),('Quiribáti','KI',NULL),('Quénia','KE',NULL),('Reino Unido','GB',NULL),('República Centro-Africana','CF',NULL),('República Dominicana','DO',NULL),('Reunião','RE',NULL),('Roménia','RO',NULL),('Ruanda','RW',NULL),('Rússia','RU',NULL),('Salvador','SV',NULL),('Samoa','WS',NULL),('Samoa Americana','AS',NULL),('Santa Helena','SH',NULL),('Santa Lúcia','LC',NULL),('Sara Ocidental','EH',NULL),('Seicheles','SC',NULL),('Senegal','SN',NULL),('Serra Leoa','SL',NULL),('Singapura','SG',NULL),('Somália','SO',NULL),('Sri Lanca','LK',NULL),('Sudão','SD',NULL),('Sudão do Sul','SS',NULL),('Suriname','SR',NULL),('Suécia','SE',NULL),('Suíça','CH',NULL),('Svalbard e Jan Mayen','SJ',NULL),('São Bartolomeu','BL',NULL),('São Cristóvão e Neves','KN',NULL),('São Marinho','SM',NULL),('São Martinho (Saint-Martin)','MF',NULL),('São Martinho (Sint Maarten)','SX',NULL),('São Pedro e Miquelão','PM',NULL),('São Tomé e Príncipe','ST',NULL),('São Vicente e Granadinas','VC',NULL),('Sérvia','RS',NULL),('Síria','SY',NULL),('Tailândia','TH',NULL),('Taiwan','TW',NULL),('Tajiquistão','TJ',NULL),('Tanzânia','TZ',NULL),('Território Britânico do Oceano Índico','IO',NULL),('Territórios Austrais Franceses','TF',NULL),('Territórios palestinianos','PS',NULL),('Timor-Leste','TL',NULL),('Togo','TG',NULL),('Tonga','TO',NULL),('Toquelau','TK',NULL),('Trindade e Tobago','TT',NULL),('Tunísia','TN',NULL),('Turquemenistão','TM',NULL),('Turquia','TR',NULL),('Tuvalu','TV',NULL),('Ucrânia','UA',NULL),('Uganda','UG',NULL),('Uruguai','UY',NULL),('Usbequistão','UZ',NULL),('Vanuatu','VU',NULL),('Venezuela','VE',NULL),('Vietname','VN',NULL),('Wallis e Futuna','WF',NULL),('Zimbabué','ZW',NULL),('Zâmbia','ZM',NULL),('África do Sul','ZA',NULL),('Áustria','AT',NULL),('Índia','IN',NULL)
ON DUPLICATE KEY UPDATE nome=VALUES(nome);

INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Bengo' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Benguela' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Bié' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Cabinda' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Cuando' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Cuanza Norte' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Cuanza Sul' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Cubango' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Cunene' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Huambo' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Huíla' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Icolo e Bengo' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Luanda' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Lunda Norte' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Lunda Sul' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Malanje' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Moxico' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Moxico Leste' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Namibe' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Uíge' FROM paises WHERE codigo='AO';
INSERT INTO provincias(id_pais,nome) SELECT id_pais,'Zaire' FROM paises WHERE codigo='AO';

-- Municípios da nova DPA (Lei 14/24). 21 províncias / 326 municípios.
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Bengo' provincia,'Ambriz' nome UNION ALL SELECT 'Bengo','Bula Atumba' UNION ALL SELECT 'Bengo','Dande' UNION ALL SELECT 'Bengo','Nambuangongo' UNION ALL SELECT 'Bengo','Pango Aluquém' UNION ALL SELECT 'Bengo','Quibaxe' UNION ALL SELECT 'Bengo','Muxaluando' UNION ALL SELECT 'Bengo','Piri' UNION ALL SELECT 'Bengo','Quicunzo' UNION ALL SELECT 'Bengo','Úcua' UNION ALL SELECT 'Bengo','Panguila' UNION ALL SELECT 'Bengo','Barra do Dande') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Benguela' provincia,'Baía Farta' nome UNION ALL SELECT 'Benguela','Balombo' UNION ALL SELECT 'Benguela','Benguela' UNION ALL SELECT 'Benguela','Bocoio' UNION ALL SELECT 'Benguela','Caimbambo' UNION ALL SELECT 'Benguela','Catumbela' UNION ALL SELECT 'Benguela','Chongorói' UNION ALL SELECT 'Benguela','Cubal' UNION ALL SELECT 'Benguela','Ganda' UNION ALL SELECT 'Benguela','Lobito' UNION ALL SELECT 'Benguela','Egito Praia' UNION ALL SELECT 'Benguela','Chindumbo' UNION ALL SELECT 'Benguela','Dombe Grande' UNION ALL SELECT 'Benguela','Capupa' UNION ALL SELECT 'Benguela','Biópio' UNION ALL SELECT 'Benguela','Chila' UNION ALL SELECT 'Benguela','Chicuma' UNION ALL SELECT 'Benguela','Babaera' UNION ALL SELECT 'Benguela','Iambala' UNION ALL SELECT 'Benguela','Catengue' UNION ALL SELECT 'Benguela','Bolonguera' UNION ALL SELECT 'Benguela','Canhamela' UNION ALL SELECT 'Benguela','Navegantes') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Bié' provincia,'Andulo' nome UNION ALL SELECT 'Bié','Camacupa' UNION ALL SELECT 'Bié','Catabola' UNION ALL SELECT 'Bié','Chinguar' UNION ALL SELECT 'Bié','Chitembo' UNION ALL SELECT 'Bié','Cuemba' UNION ALL SELECT 'Bié','Cunhinga' UNION ALL SELECT 'Bié','Cuito' UNION ALL SELECT 'Bié','Nharêa' UNION ALL SELECT 'Bié','Luando' UNION ALL SELECT 'Bié','Ringoma' UNION ALL SELECT 'Bié','Mumbuê' UNION ALL SELECT 'Bié','Calucinga' UNION ALL SELECT 'Bié','Chicala' UNION ALL SELECT 'Bié','Chipeta' UNION ALL SELECT 'Bié','Umpulo' UNION ALL SELECT 'Bié','Lúbia' UNION ALL SELECT 'Bié','Cambândua' UNION ALL SELECT 'Bié','Belo Horizonte') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Cabinda' provincia,'Cabinda' nome UNION ALL SELECT 'Cabinda','Cacongo' UNION ALL SELECT 'Cabinda','Buco-Zau' UNION ALL SELECT 'Cabinda','Belize' UNION ALL SELECT 'Cabinda','Miconje' UNION ALL SELECT 'Cabinda','Massabi' UNION ALL SELECT 'Cabinda','Necuto' UNION ALL SELECT 'Cabinda','Tando Zinze' UNION ALL SELECT 'Cabinda','Liambo' UNION ALL SELECT 'Cabinda','Ngoio') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Cuando' provincia,'Cuito Cuanavale' nome UNION ALL SELECT 'Cuando','Dirico' UNION ALL SELECT 'Cuando','Mavinga' UNION ALL SELECT 'Cuando','Rivungo' UNION ALL SELECT 'Cuando','Xipundo' UNION ALL SELECT 'Cuando','Dima' UNION ALL SELECT 'Cuando','Luiana' UNION ALL SELECT 'Cuando','Mucusso' UNION ALL SELECT 'Cuando','Luengue') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Cuanza Norte' provincia,'Ambaca' nome UNION ALL SELECT 'Cuanza Norte','Banga' UNION ALL SELECT 'Cuanza Norte','Bolongongo' UNION ALL SELECT 'Cuanza Norte','Cambambe' UNION ALL SELECT 'Cuanza Norte','Cazengo' UNION ALL SELECT 'Cuanza Norte','Golungo Alto' UNION ALL SELECT 'Cuanza Norte','Ngonguembo' UNION ALL SELECT 'Cuanza Norte','Lucala' UNION ALL SELECT 'Cuanza Norte','Quiculungo' UNION ALL SELECT 'Cuanza Norte','Samba Cajú' UNION ALL SELECT 'Cuanza Norte','Massangano' UNION ALL SELECT 'Cuanza Norte','Cêrca' UNION ALL SELECT 'Cuanza Norte','Tango' UNION ALL SELECT 'Cuanza Norte','Terreiro' UNION ALL SELECT 'Cuanza Norte','Aldeia Nova' UNION ALL SELECT 'Cuanza Norte','Caculo Cabaça' UNION ALL SELECT 'Cuanza Norte','Luinga') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Cuanza Sul' provincia,'Gabela' nome UNION ALL SELECT 'Cuanza Sul','Cassongue' UNION ALL SELECT 'Cuanza Sul','Conda' UNION ALL SELECT 'Cuanza Sul','Ebo' UNION ALL SELECT 'Cuanza Sul','Mussende' UNION ALL SELECT 'Cuanza Sul','Porto Amboim' UNION ALL SELECT 'Cuanza Sul','Quilenda' UNION ALL SELECT 'Cuanza Sul','Quibala' UNION ALL SELECT 'Cuanza Sul','Seles' UNION ALL SELECT 'Cuanza Sul','Sumbe' UNION ALL SELECT 'Cuanza Sul','Waku Kungo' UNION ALL SELECT 'Cuanza Sul','Calulo' UNION ALL SELECT 'Cuanza Sul','Quirimbo' UNION ALL SELECT 'Cuanza Sul','Munenga' UNION ALL SELECT 'Cuanza Sul','Quissongo' UNION ALL SELECT 'Cuanza Sul','Gungo' UNION ALL SELECT 'Cuanza Sul','Sanga' UNION ALL SELECT 'Cuanza Sul','Gangula' UNION ALL SELECT 'Cuanza Sul','Pambangala' UNION ALL SELECT 'Cuanza Sul','Condé' UNION ALL SELECT 'Cuanza Sul','Amboiva' UNION ALL SELECT 'Cuanza Sul','Lonhe' UNION ALL SELECT 'Cuanza Sul','Quenha' UNION ALL SELECT 'Cuanza Sul','Boa Entrada') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Cubango' provincia,'Menongue' nome UNION ALL SELECT 'Cubango','Cutato' UNION ALL SELECT 'Cubango','Cuchi' UNION ALL SELECT 'Cubango','Longa' UNION ALL SELECT 'Cubango','Chinguanja' UNION ALL SELECT 'Cubango','Caiundo' UNION ALL SELECT 'Cubango','Savate' UNION ALL SELECT 'Cubango','Cuangar' UNION ALL SELECT 'Cubango','Calai' UNION ALL SELECT 'Cubango','Mavengue' UNION ALL SELECT 'Cubango','Nancova') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Cunene' provincia,'Cahama' nome UNION ALL SELECT 'Cunene','Cuanhama' UNION ALL SELECT 'Cunene','Curoca' UNION ALL SELECT 'Cunene','Cuvelai' UNION ALL SELECT 'Cunene','Namacunde' UNION ALL SELECT 'Cunene','Ombadja' UNION ALL SELECT 'Cunene','Chiéde' UNION ALL SELECT 'Cunene','Nehone' UNION ALL SELECT 'Cunene','Humbe' UNION ALL SELECT 'Cunene','Mupa' UNION ALL SELECT 'Cunene','Naulila' UNION ALL SELECT 'Cunene','Chitado' UNION ALL SELECT 'Cunene','Cafima' UNION ALL SELECT 'Cunene','Chissuata') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Huambo' provincia,'Longonjo' nome UNION ALL SELECT 'Huambo','Bailundo' UNION ALL SELECT 'Huambo','Chicala Choloanga' UNION ALL SELECT 'Huambo','Mungo' UNION ALL SELECT 'Huambo','Chinjenje' UNION ALL SELECT 'Huambo','Ucuma' UNION ALL SELECT 'Huambo','Cachiungo' UNION ALL SELECT 'Huambo','Caála' UNION ALL SELECT 'Huambo','Ecunha' UNION ALL SELECT 'Huambo','Huambo' UNION ALL SELECT 'Huambo','Londuimbali' UNION ALL SELECT 'Huambo','Bimbe' UNION ALL SELECT 'Huambo','Sambo' UNION ALL SELECT 'Huambo','Galanga' UNION ALL SELECT 'Huambo','Alto Hama' UNION ALL SELECT 'Huambo','Chilata' UNION ALL SELECT 'Huambo','Cuima') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Huíla' provincia,'Caconda' nome UNION ALL SELECT 'Huíla','Cacula' UNION ALL SELECT 'Huíla','Caluquembe' UNION ALL SELECT 'Huíla','Gambos' UNION ALL SELECT 'Huíla','Chibia' UNION ALL SELECT 'Huíla','Chicomba' UNION ALL SELECT 'Huíla','Chipindo' UNION ALL SELECT 'Huíla','Cuvango' UNION ALL SELECT 'Huíla','Humpata' UNION ALL SELECT 'Huíla','Lubango' UNION ALL SELECT 'Huíla','Matala' UNION ALL SELECT 'Huíla','Quilengues' UNION ALL SELECT 'Huíla','Quipungo' UNION ALL SELECT 'Huíla','Jamba Mineira' UNION ALL SELECT 'Huíla','Dongo' UNION ALL SELECT 'Huíla','Hoque' UNION ALL SELECT 'Huíla','Capelongo' UNION ALL SELECT 'Huíla','Chituto' UNION ALL SELECT 'Huíla','Capunda Cavilongo' UNION ALL SELECT 'Huíla','Viti Vivali' UNION ALL SELECT 'Huíla','Galangue' UNION ALL SELECT 'Huíla','Palanca' UNION ALL SELECT 'Huíla','Chicungo') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Icolo e Bengo' provincia,'Sequele' nome UNION ALL SELECT 'Icolo e Bengo','Cabo Ledo' UNION ALL SELECT 'Icolo e Bengo','Bom Jesus' UNION ALL SELECT 'Icolo e Bengo','Cabiri' UNION ALL SELECT 'Icolo e Bengo','Catete' UNION ALL SELECT 'Icolo e Bengo','Calumbo' UNION ALL SELECT 'Icolo e Bengo','Quiçama') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Luanda' provincia,'Luanda' nome UNION ALL SELECT 'Luanda','Cacuaco' UNION ALL SELECT 'Luanda','Cazenga' UNION ALL SELECT 'Luanda','Viana' UNION ALL SELECT 'Luanda','Belas' UNION ALL SELECT 'Luanda','Talatona' UNION ALL SELECT 'Luanda','Mussulo' UNION ALL SELECT 'Luanda','Sambizanga' UNION ALL SELECT 'Luanda','Rangel' UNION ALL SELECT 'Luanda','Maianga' UNION ALL SELECT 'Luanda','Samba' UNION ALL SELECT 'Luanda','Camama' UNION ALL SELECT 'Luanda','Mulenvos' UNION ALL SELECT 'Luanda','Kilamba' UNION ALL SELECT 'Luanda','Hoji Ya Henda' UNION ALL SELECT 'Luanda','Ingombota') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Lunda Norte' provincia,'Cambulo' nome UNION ALL SELECT 'Lunda Norte','Capenda Camulemba' UNION ALL SELECT 'Lunda Norte','Caungula' UNION ALL SELECT 'Lunda Norte','Chitato' UNION ALL SELECT 'Lunda Norte','Cuango' UNION ALL SELECT 'Lunda Norte','Cuílo' UNION ALL SELECT 'Lunda Norte','Lubalo' UNION ALL SELECT 'Lunda Norte','Lucapa' UNION ALL SELECT 'Lunda Norte','Lóvua' UNION ALL SELECT 'Lunda Norte','Xá-Muteba' UNION ALL SELECT 'Lunda Norte','Dundo' UNION ALL SELECT 'Lunda Norte','Xá Cassau' UNION ALL SELECT 'Lunda Norte','Camaxilo' UNION ALL SELECT 'Lunda Norte','Luangue' UNION ALL SELECT 'Lunda Norte','Luremo' UNION ALL SELECT 'Lunda Norte','Canzar' UNION ALL SELECT 'Lunda Norte','Cassanje Calucala' UNION ALL SELECT 'Lunda Norte','Mussungue' UNION ALL SELECT 'Lunda Norte','Cafunfu') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Lunda Sul' provincia,'Cacolo' nome UNION ALL SELECT 'Lunda Sul','Dala' UNION ALL SELECT 'Lunda Sul','Muconda' UNION ALL SELECT 'Lunda Sul','Saurimo' UNION ALL SELECT 'Lunda Sul','Chiluage' UNION ALL SELECT 'Lunda Sul','Cassai-Sul' UNION ALL SELECT 'Lunda Sul','Xassengue' UNION ALL SELECT 'Lunda Sul','Alto Chicapa' UNION ALL SELECT 'Lunda Sul','Sombo' UNION ALL SELECT 'Lunda Sul','Muriege' UNION ALL SELECT 'Lunda Sul','Luma Cassai' UNION ALL SELECT 'Lunda Sul','Cazage' UNION ALL SELECT 'Lunda Sul','Muangueji' UNION ALL SELECT 'Lunda Sul','Cassengo') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Malanje' provincia,'Cacuso' nome UNION ALL SELECT 'Malanje','Cahombo' UNION ALL SELECT 'Malanje','Calandula' UNION ALL SELECT 'Malanje','Cambundi Catembo' UNION ALL SELECT 'Malanje','Cangandala' UNION ALL SELECT 'Malanje','Kunda dya Baze' UNION ALL SELECT 'Malanje','Luquembo' UNION ALL SELECT 'Malanje','Malanje' UNION ALL SELECT 'Malanje','Marimba' UNION ALL SELECT 'Malanje','Massango' UNION ALL SELECT 'Malanje','Quela' UNION ALL SELECT 'Malanje','Quirima' UNION ALL SELECT 'Malanje','Kiwaba Nzoji' UNION ALL SELECT 'Malanje','Cateco Cangola' UNION ALL SELECT 'Malanje','Cuale' UNION ALL SELECT 'Malanje','Pungo A Ndongo' UNION ALL SELECT 'Malanje','Ngola Luiji' UNION ALL SELECT 'Malanje','Quihuhu' UNION ALL SELECT 'Malanje','Xandel' UNION ALL SELECT 'Malanje','Cambo Suinginge' UNION ALL SELECT 'Malanje','Milando' UNION ALL SELECT 'Malanje','Quitapa' UNION ALL SELECT 'Malanje','Capunda' UNION ALL SELECT 'Malanje','Muquixe' UNION ALL SELECT 'Malanje','Quêssua' UNION ALL SELECT 'Malanje','Caculama' UNION ALL SELECT 'Malanje','Mbanji Ya Ngola') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Moxico' provincia,'Camanongue' nome UNION ALL SELECT 'Moxico','Léua' UNION ALL SELECT 'Moxico','Chiúme' UNION ALL SELECT 'Moxico','Lumbala Nguimbo' UNION ALL SELECT 'Moxico','Alto Cuito' UNION ALL SELECT 'Moxico','Lutembo' UNION ALL SELECT 'Moxico','Cangumbe' UNION ALL SELECT 'Moxico','Luena' UNION ALL SELECT 'Moxico','Cangamba' UNION ALL SELECT 'Moxico','Lucusse' UNION ALL SELECT 'Moxico','Ninda' UNION ALL SELECT 'Moxico','Lutuai') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Moxico Leste' provincia,'Cazombo' nome UNION ALL SELECT 'Moxico Leste','Luacano' UNION ALL SELECT 'Moxico Leste','Cameia' UNION ALL SELECT 'Moxico Leste','Luau' UNION ALL SELECT 'Moxico Leste','Nana Candundo' UNION ALL SELECT 'Moxico Leste','Macondo' UNION ALL SELECT 'Moxico Leste','Caianda' UNION ALL SELECT 'Moxico Leste','Lóvua do Zambeze' UNION ALL SELECT 'Moxico Leste','Lago Dilolo') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Namibe' provincia,'Moçâmedes' nome UNION ALL SELECT 'Namibe','Camucuio' UNION ALL SELECT 'Namibe','Bibala' UNION ALL SELECT 'Namibe','Virei' UNION ALL SELECT 'Namibe','Tômbua' UNION ALL SELECT 'Namibe','Lucira' UNION ALL SELECT 'Namibe','Iona' UNION ALL SELECT 'Namibe','Sacomar' UNION ALL SELECT 'Namibe','Cacimbas') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Uíge' provincia,'Uíge' nome UNION ALL SELECT 'Uíge','Ambuíla' UNION ALL SELECT 'Uíge','Bembe' UNION ALL SELECT 'Uíge','Bungo' UNION ALL SELECT 'Uíge','Milunga' UNION ALL SELECT 'Uíge','Damba' UNION ALL SELECT 'Uíge','Maquela do Zombo' UNION ALL SELECT 'Uíge','Mucaba' UNION ALL SELECT 'Uíge','Negage' UNION ALL SELECT 'Uíge','Puri' UNION ALL SELECT 'Uíge','Quimbele' UNION ALL SELECT 'Uíge','Sanza Pombo' UNION ALL SELECT 'Uíge','Songo' UNION ALL SELECT 'Uíge','Cangola' UNION ALL SELECT 'Uíge','Nova Esperança' UNION ALL SELECT 'Uíge','Dange Quitexe' UNION ALL SELECT 'Uíge','Sacandica' UNION ALL SELECT 'Uíge','Nsosso' UNION ALL SELECT 'Uíge','Lucunga' UNION ALL SELECT 'Uíge','Quipedro' UNION ALL SELECT 'Uíge','Massau' UNION ALL SELECT 'Uíge','Vista Alegre' UNION ALL SELECT 'Uíge','Alto Zaza') x ON x.provincia=p.nome;
INSERT INTO municipios(id_provincia,nome) SELECT id_provincia,nome FROM provincias p JOIN (SELECT 'Zaire' provincia,'Mbanza Kongo' nome UNION ALL SELECT 'Zaire','Soyo' UNION ALL SELECT 'Zaire','Nzeto' UNION ALL SELECT 'Zaire','Cuimba' UNION ALL SELECT 'Zaire','Nóqui' UNION ALL SELECT 'Zaire','Tomboco' UNION ALL SELECT 'Zaire','Luvo' UNION ALL SELECT 'Zaire','Lufico' UNION ALL SELECT 'Zaire','Quêlo' UNION ALL SELECT 'Zaire','Serra de Canda' UNION ALL SELECT 'Zaire','Quindeje') x ON x.provincia=p.nome;

INSERT INTO regiao_provincias(id_regiao,id_provincia)
SELECT r.id_regiao,p.id_provincia FROM regioes r JOIN provincias p ON (
 (r.sigla='NORTE' AND p.nome IN('Cabinda','Zaire','Uíge','Bengo')) OR
 (r.sigla='CENTRO' AND p.nome IN('Icolo e Bengo','Luanda','Cuanza Norte','Cuanza Sul','Malanje','Benguela','Huambo','Bié')) OR
 (r.sigla='LESTE' AND p.nome IN('Lunda Norte','Lunda Sul','Moxico','Moxico Leste','Cuando','Cubango')) OR
 (r.sigla='SUL' AND p.nome IN('Huíla','Namibe','Cunene'))
);

INSERT INTO quadros_servico(nome,sigla) VALUES ('Quadro Permanente','QP'),('Quadro Miliciano','QM'),('Quadro Especial','QE'),('Civil','CIV');
INSERT INTO sexos(nome) VALUES ('Masculino'),('Feminino');
INSERT INTO estados_civis(nome) VALUES ('Solteiro'),('Casado'),('Divorciado'),('Viúvo'),('União de facto');
INSERT INTO grupos_sanguineos(nome) VALUES ('A+'),('A-'),('B+'),('B-'),('AB+'),('AB-'),('O+'),('O-');
INSERT INTO graus_parentesco(nome) VALUES ('Cônjuge'),('Filho/a'),('Pai/Mãe'),('Irmão/Irmã'),('Outro');
INSERT INTO niveis_habilitacao(nome,ordem) VALUES ('Ensino Primário',1),('I Ciclo',2),('II Ciclo',3),('Ensino Médio',4),('Licenciatura',5),('Pós-Graduação',6),('Mestrado',7),('Doutoramento',8);
INSERT INTO tipos_licenca(nome,codigo,descricao) VALUES ('Licença de férias','FERIAS','Licença de férias'),('Licença de formação','FORMACAO','Licença para formação'),('Outras licenças','OUTRAS','Outros tipos de licença');
INSERT INTO situacoes_servico(nome,grupo,descricao) VALUES ('ATIVO','ATIVO','Em efetividade de serviço'),('FALECIDO','INATIVO','Especialista falecido'),('REFORMADO','INATIVO','Reformado'),('LICENÇA','INATIVO','Em licença'),('DOENTE','INATIVO','Em situação de doença; consulta restrita');
INSERT INTO tipos_documento(nome) VALUES ('BI'),('Certificado'),('Diploma'),('Despacho'),('Declaração'),('Contrato'),('Relatório');
INSERT INTO tipos_equipamento(nome) VALUES ('Informática'),('Comunicações'),('Viatura'),('Armamento e material'),('Mobiliário'),('Outro');
INSERT INTO estados_equipamento(nome) VALUES ('Disponível'),('Atribuído'),('Em manutenção'),('Inutilizado'),('Baixado');
INSERT INTO tipos_condecoracao(nome) VALUES ('Medalha'),('Ordem'),('Distinção'),('Louvor'),('Outra');
INSERT INTO tipos_alerta(nome,codigo,nivel_padrao,dias_antecedencia) VALUES
('Documento expirado','DOCUMENTO_EXPIRADO','URGENTE',0),('Documento a expirar','DOCUMENTO_A_EXPIRAR','ATENCAO',30),('BI expirado','BI_EXPIRADO','URGENTE',0),('BI a expirar','BI_A_EXPIRAR','ATENCAO',60),('Férias próximas','FERIAS_PROXIMAS','INFO',15),('Formação a terminar','FORMACAO_A_EXPIRAR','ATENCAO',30),('Fim de função','FIM_FUNCAO','ATENCAO',30);

INSERT INTO modelos_solicitacao(nome,codigo,assunto,conteudo,categoria) VALUES
('Declaração de Efetividade','DECL_EFETIVIDADE','Declaração de Efetividade','Declara-se que {{NOME}}, NIP {{NIP}}, {{PATENTE}}, pertence à unidade {{UNIDADE}} e exerce funções de {{FUNCAO}} no {{RAMO}}.','SOLICITACAO'),
('Adiantamento Salarial','ADIANTAMENTO_SALARIAL','Pedido de Adiantamento Salarial','Eu, {{NOME}}, NIP {{NIP}}, venho solicitar adiantamento salarial.','SOLICITACAO'),
('Autobiografia do Especialista','AUTOBIOGRAFIA','Autobiografia','{AUTOBIOGRAFIA}','AUTOBIOGRAFIA'),
('Ficha Resumida de Equipamento','FICHA_EQUIPAMENTO','Ficha Resumida de Equipamento','{FICHA_EQUIPAMENTO}','EQUIPAMENTO');

INSERT INTO perfis(nome,descricao,nivel_acesso) VALUES
('ADMINISTRADOR_GLOBAL','Acesso administrativo completo','GLOBAL'),
('ADMINISTRADOR_RH','Administração de Recursos Humanos no âmbito atribuído','RAMO'),
('OPERADOR_RH','Operação de Recursos Humanos no âmbito atribuído','RAMO'),
('ADMINISTRADOR_RM','Administração de Recursos Materiais no âmbito atribuído','RAMO'),
('ADMINISTRADOR_RAMO','Administração geral do ramo atribuído','RAMO'),
('ADMINISTRADOR_REGIAO','Administração no âmbito regional atribuído','REGIAO'),
('OPERADOR_REGIAO','Operação no âmbito regional atribuído','REGIAO'),
('GESTOR_LOCAL','Gestão da unidade atribuída','UNIDADE'),
('PRIVILEGIADO','Consulta global privilegiada, sem administração','GLOBAL'),
('CONSULTOR','Consulta limitada ao âmbito atribuído','UNIDADE');

INSERT INTO permissoes(nome,modulo,descricao) VALUES
('DASHBOARD_VISUALIZAR','DASHBOARD','Ver dashboard'),
('ESPECIALISTAS_VISUALIZAR','ESPECIALISTAS','Ver especialistas'),('ESPECIALISTAS_CRIAR','ESPECIALISTAS','Criar especialistas'),('ESPECIALISTAS_EDITAR','ESPECIALISTAS','Editar especialistas'),('ESPECIALISTAS_ELIMINAR','ESPECIALISTAS','Eliminar especialistas'),
('EQUIPAMENTOS_VISUALIZAR','EQUIPAMENTOS','Ver equipamentos'),('EQUIPAMENTOS_CRIAR','EQUIPAMENTOS','Criar equipamentos'),('EQUIPAMENTOS_EDITAR','EQUIPAMENTOS','Editar equipamentos'),('EQUIPAMENTOS_ELIMINAR','EQUIPAMENTOS','Eliminar equipamentos'),
('UTILIZADORES_VISUALIZAR','UTILIZADORES','Ver utilizadores'),('UTILIZADORES_CRIAR','UTILIZADORES','Criar utilizadores'),('UTILIZADORES_EDITAR','UTILIZADORES','Editar utilizadores'),('UTILIZADORES_ELIMINAR','UTILIZADORES','Eliminar utilizadores'),
('FOTOGRAFIAS_VISUALIZAR','FOTOGRAFIAS','Ver fotografias'),('FOTOGRAFIAS_CRIAR','FOTOGRAFIAS','Adicionar fotografias'),('FOTOGRAFIAS_EDITAR','FOTOGRAFIAS','Editar fotografias'),('FOTOGRAFIAS_ELIMINAR','FOTOGRAFIAS','Eliminar fotografias'),
('DOCUMENTOS_VISUALIZAR','DOCUMENTOS','Ver documentos'),('DOCUMENTOS_CRIAR','DOCUMENTOS','Adicionar documentos'),('DOCUMENTOS_EDITAR','DOCUMENTOS','Editar documentos'),('DOCUMENTOS_ELIMINAR','DOCUMENTOS','Eliminar documentos'),
('SOLICITACOES_VISUALIZAR','SOLICITACOES','Ver solicitações'),('SOLICITACOES_CRIAR','SOLICITACOES','Criar solicitações'),('SOLICITACOES_IMPRIMIR','SOLICITACOES','Imprimir solicitações'),
('CONFIGURACOES_VISUALIZAR','CONFIGURACOES','Ver configurações'),('CONFIGURACOES_GERIR','CONFIGURACOES','Gerir configurações'),('RAMOS_GERIR','CONFIGURACOES','Gerir ramos'),('REGIOES_GERIR','CONFIGURACOES','Gerir regiões'),
('AUDITORIA_VISUALIZAR','AUDITORIA','Consultar auditoria'),('AUDITORIA_GERIR','AUDITORIA','Gerir definições de auditoria'),
('HISTORICO_VISUALIZAR','HISTORICO','Consultar histórico'),('RELATORIOS_VISUALIZAR','RELATORIOS','Ver relatórios'),('RELATORIOS_IMPRIMIR','RELATORIOS','Imprimir relatórios'),
('FERIAS_VISUALIZAR','FERIAS','Ver férias'),('FERIAS_CRIAR','FERIAS','Criar férias'),('FERIAS_EDITAR','FERIAS','Editar férias'),('FERIAS_ELIMINAR','FERIAS','Eliminar férias'),
('LICENCAS_VISUALIZAR','LICENCAS','Ver licenças'),('LICENCAS_CRIAR','LICENCAS','Criar licenças'),('LICENCAS_EDITAR','LICENCAS','Editar licenças'),('LICENCAS_ELIMINAR','LICENCAS','Eliminar licenças'),
('CONSULTA_FALECIDOS','CONSULTA','Consultar falecidos'),('CONSULTA_DOENTES','CONSULTA','Consultar doentes');

-- Global recebe todas as permissões; privilegiado recebe apenas leitura global.
INSERT INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p CROSS JOIN permissoes x WHERE p.nome='ADMINISTRADOR_GLOBAL';
INSERT INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p JOIN permissoes x ON x.nome IN('DASHBOARD_VISUALIZAR','ESPECIALISTAS_VISUALIZAR','EQUIPAMENTOS_VISUALIZAR','FOTOGRAFIAS_VISUALIZAR','DOCUMENTOS_VISUALIZAR','RELATORIOS_VISUALIZAR','RELATORIOS_IMPRIMIR','HISTORICO_VISUALIZAR','AUDITORIA_VISUALIZAR','CONSULTA_FALECIDOS','CONSULTA_DOENTES') WHERE p.nome='PRIVILEGIADO';
INSERT INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p JOIN permissoes x ON x.nome IN('DASHBOARD_VISUALIZAR','ESPECIALISTAS_VISUALIZAR','ESPECIALISTAS_CRIAR','ESPECIALISTAS_EDITAR','FOTOGRAFIAS_VISUALIZAR','FOTOGRAFIAS_CRIAR','FOTOGRAFIAS_EDITAR','DOCUMENTOS_VISUALIZAR','DOCUMENTOS_CRIAR','DOCUMENTOS_EDITAR','FERIAS_VISUALIZAR','FERIAS_CRIAR','FERIAS_EDITAR','LICENCAS_VISUALIZAR','LICENCAS_CRIAR','LICENCAS_EDITAR','RELATORIOS_VISUALIZAR','RELATORIOS_IMPRIMIR','HISTORICO_VISUALIZAR') WHERE p.nome IN('ADMINISTRADOR_RH','OPERADOR_RH');
INSERT INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p JOIN permissoes x ON x.nome IN('DASHBOARD_VISUALIZAR','EQUIPAMENTOS_VISUALIZAR','EQUIPAMENTOS_CRIAR','EQUIPAMENTOS_EDITAR','FOTOGRAFIAS_VISUALIZAR','FOTOGRAFIAS_CRIAR','FOTOGRAFIAS_EDITAR','DOCUMENTOS_VISUALIZAR','DOCUMENTOS_CRIAR','DOCUMENTOS_EDITAR','RELATORIOS_VISUALIZAR','RELATORIOS_IMPRIMIR','HISTORICO_VISUALIZAR') WHERE p.nome='ADMINISTRADOR_RM';
INSERT INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p JOIN permissoes x ON x.nome IN('DASHBOARD_VISUALIZAR','ESPECIALISTAS_VISUALIZAR','ESPECIALISTAS_CRIAR','ESPECIALISTAS_EDITAR','ESPECIALISTAS_ELIMINAR','EQUIPAMENTOS_VISUALIZAR','EQUIPAMENTOS_CRIAR','EQUIPAMENTOS_EDITAR','EQUIPAMENTOS_ELIMINAR','UTILIZADORES_VISUALIZAR','UTILIZADORES_CRIAR','UTILIZADORES_EDITAR','FOTOGRAFIAS_VISUALIZAR','FOTOGRAFIAS_CRIAR','FOTOGRAFIAS_EDITAR','FOTOGRAFIAS_ELIMINAR','DOCUMENTOS_VISUALIZAR','DOCUMENTOS_CRIAR','DOCUMENTOS_EDITAR','DOCUMENTOS_ELIMINAR','SOLICITACOES_VISUALIZAR','SOLICITACOES_CRIAR','SOLICITACOES_IMPRIMIR','RELATORIOS_VISUALIZAR','RELATORIOS_IMPRIMIR','HISTORICO_VISUALIZAR') WHERE p.nome='ADMINISTRADOR_RAMO';
INSERT INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p JOIN permissoes x ON x.nome IN('DASHBOARD_VISUALIZAR','ESPECIALISTAS_VISUALIZAR','ESPECIALISTAS_CRIAR','ESPECIALISTAS_EDITAR','EQUIPAMENTOS_VISUALIZAR','EQUIPAMENTOS_CRIAR','EQUIPAMENTOS_EDITAR','UTILIZADORES_VISUALIZAR','UTILIZADORES_CRIAR','UTILIZADORES_EDITAR','FOTOGRAFIAS_VISUALIZAR','FOTOGRAFIAS_CRIAR','FOTOGRAFIAS_EDITAR','DOCUMENTOS_VISUALIZAR','DOCUMENTOS_CRIAR','DOCUMENTOS_EDITAR','RELATORIOS_VISUALIZAR','RELATORIOS_IMPRIMIR','HISTORICO_VISUALIZAR') WHERE p.nome IN('ADMINISTRADOR_REGIAO','OPERADOR_REGIAO');
INSERT INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p JOIN permissoes x ON x.nome IN('DASHBOARD_VISUALIZAR','ESPECIALISTAS_VISUALIZAR','ESPECIALISTAS_CRIAR','ESPECIALISTAS_EDITAR','EQUIPAMENTOS_VISUALIZAR','EQUIPAMENTOS_CRIAR','EQUIPAMENTOS_EDITAR','FOTOGRAFIAS_VISUALIZAR','FOTOGRAFIAS_CRIAR','FOTOGRAFIAS_EDITAR','DOCUMENTOS_VISUALIZAR','DOCUMENTOS_CRIAR','DOCUMENTOS_EDITAR','SOLICITACOES_VISUALIZAR','SOLICITACOES_CRIAR','SOLICITACOES_IMPRIMIR','RELATORIOS_VISUALIZAR','RELATORIOS_IMPRIMIR','HISTORICO_VISUALIZAR') WHERE p.nome='GESTOR_LOCAL';
INSERT INTO perfil_permissoes(id_perfil,id_permissao) SELECT p.id_perfil,x.id_permissao FROM perfis p JOIN permissoes x ON x.nome IN('DASHBOARD_VISUALIZAR','ESPECIALISTAS_VISUALIZAR','EQUIPAMENTOS_VISUALIZAR','FOTOGRAFIAS_VISUALIZAR','DOCUMENTOS_VISUALIZAR','RELATORIOS_VISUALIZAR') WHERE p.nome='CONSULTOR';

-- Conta inicial: senha deverá ser alterada após o primeiro acesso.
INSERT INTO utilizadores(nome_utilizador,senha,email,id_perfil,estado)
SELECT 'admin','$2y$12$buuzwkof/M/pHvE.gtrrmuwPJFI4IFFZ6dmtmjD.8gCkhErnArQOW','admin@sistema.local',p.id_perfil,'ATIVO' FROM perfis p WHERE p.nome='ADMINISTRADOR_GLOBAL';

CREATE VIEW vw_especialistas_dashboard AS
SELECT e.id_especialista,e.id_ramo,e.id_quadro,e.id_patente,e.estado estado_cadastro,
 dp.nome_completo,sx.nome sexo,ds.nip,ds.id_unidade,ds.id_regiao,q.nome quadro,p.nome patente,p.ordem ordem_patente,
 ss.nome situacao_servico,ss.grupo grupo_situacao,r.nome ramo_nome,r.sigla ramo_sigla,r.cor_principal ramo_cor,
 rg.nome regiao_nome,dc.numero_bi,dc.data_validade_bi
FROM especialistas e
LEFT JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista
LEFT JOIN dados_pessoais dc ON dc.id_especialista=e.id_especialista
LEFT JOIN quadros_servico q ON q.id_quadro=e.id_quadro
LEFT JOIN patentes p ON p.id_patente=e.id_patente
LEFT JOIN sexos sx ON sx.id_sexo=dp.id_sexo
LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista
LEFT JOIN situacoes_servico ss ON ss.id_situacao_servico=ds.id_situacao_servico
LEFT JOIN ramo r ON r.id_ramo=e.id_ramo
LEFT JOIN regioes rg ON rg.id_regiao=ds.id_regiao;
