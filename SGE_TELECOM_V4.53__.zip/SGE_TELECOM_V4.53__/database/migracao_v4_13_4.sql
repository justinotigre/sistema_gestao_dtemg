-- Migração v4.13.4: permitir NIP nulo para especialistas do quadro civil.
-- Fazer cópia de segurança antes de executar.
-- Compatível com a estrutura conhecida em sistema_especialistas_v3; confirme o nome da BD.
USE sistema_especialistas_v3;
ALTER TABLE dados_servico MODIFY COLUMN nip VARCHAR(50) NULL;
