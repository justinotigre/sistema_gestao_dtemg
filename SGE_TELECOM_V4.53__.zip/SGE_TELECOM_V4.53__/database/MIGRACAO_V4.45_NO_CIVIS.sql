-- Executar uma vez, depois da cópia de segurança.
-- Código compatível com MySQL e MariaDB recentes.
ALTER TABLE dados_servico ADD COLUMN no_civil VARCHAR(50) NULL AFTER nip;
CREATE INDEX idx_dados_servico_no_civil ON dados_servico(no_civil);
