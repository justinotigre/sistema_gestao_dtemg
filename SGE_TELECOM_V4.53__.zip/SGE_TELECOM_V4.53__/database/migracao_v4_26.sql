-- SGE TELECOM V4.26. Migração aditiva; efectuar backup antes de executar.
CREATE TABLE IF NOT EXISTS perfil_modulos (
  id_perfil INT NOT NULL, modulo VARCHAR(100) NOT NULL,
  pode_visualizar TINYINT(1) NOT NULL DEFAULT 0, pode_configurar TINYINT(1) NOT NULL DEFAULT 0,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id_perfil, modulo),
  CONSTRAINT fk_perfil_modulos_perfil_v426 FOREIGN KEY (id_perfil) REFERENCES perfis(id_perfil) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS notificacoes (
  id_notificacao BIGINT AUTO_INCREMENT PRIMARY KEY, id_utilizador INT NULL, categoria VARCHAR(50) NOT NULL,
  titulo VARCHAR(180) NOT NULL, mensagem TEXT NOT NULL, url_destino VARCHAR(500) NULL,
  entidade VARCHAR(100) NULL, id_entidade BIGINT NULL, data_evento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, lida_em DATETIME NULL,
  INDEX idx_notificacao_utilizador_lida (id_utilizador,lida_em), INDEX idx_notificacao_categoria_data (categoria,data_evento),
  CONSTRAINT fk_notificacoes_utilizador_v426 FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_leituras (
  id_publicacao INT NOT NULL, id_utilizador INT NOT NULL, lida_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_publicacao,id_utilizador),
  CONSTRAINT fk_feed_leituras_utilizador_v426 FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_avaliacoes (
  id_publicacao INT NOT NULL, id_utilizador INT NOT NULL, estrelas TINYINT UNSIGNED NOT NULL,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id_publicacao,id_utilizador),
  CONSTRAINT chk_feed_estrelas_v426 CHECK (estrelas BETWEEN 1 AND 5),
  CONSTRAINT fk_feed_avaliacoes_utilizador_v426 FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
