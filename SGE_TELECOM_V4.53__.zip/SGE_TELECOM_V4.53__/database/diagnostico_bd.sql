USE sistema_especialistas_v3;

-- 1) Objetos principais
SELECT COUNT(*) AS total_tabelas
FROM information_schema.TABLES
WHERE TABLE_SCHEMA=DATABASE() AND TABLE_TYPE='BASE TABLE';

-- 2) Localização administrativa
SELECT COUNT(*) AS total_paises FROM paises;
SELECT COUNT(*) AS provincias_angola FROM provincias p JOIN paises pa ON pa.id_pais=p.id_pais WHERE pa.codigo='AO';
SELECT COUNT(*) AS municipios_angola FROM municipios m JOIN provincias p ON p.id_provincia=m.id_provincia JOIN paises pa ON pa.id_pais=p.id_pais WHERE pa.codigo='AO';
SELECT p.nome,COUNT(m.id_municipio) AS municipios
FROM provincias p JOIN paises pa ON pa.id_pais=p.id_pais LEFT JOIN municipios m ON m.id_provincia=p.id_provincia
WHERE pa.codigo='AO' GROUP BY p.id_provincia,p.nome ORDER BY p.nome;

-- 3) Ramos e cores
SELECT sigla,nome,cor_principal,ordem,estado FROM ramo ORDER BY ordem,nome;

-- 4) Regiões
SELECT r.nome,r.sigla,r.estado,COUNT(rp.id_provincia) AS provincias
FROM regioes r LEFT JOIN regiao_provincias rp ON rp.id_regiao=r.id_regiao
GROUP BY r.id_regiao,r.nome,r.sigla,r.estado ORDER BY r.nome;

-- 5) Situações funcionais: TRANSFERIDO deve retornar 0 linhas.
SELECT id_situacao_servico,nome,grupo,estado FROM situacoes_servico ORDER BY grupo DESC,nome;
SELECT COUNT(*) AS transferido_deve_ser_zero FROM situacoes_servico WHERE UPPER(nome)='TRANSFERIDO' AND estado='ATIVO';

-- 6) Estruturas críticas
SELECT 'grupos_sanguineos' tabela,COUNT(*) total FROM grupos_sanguineos
UNION ALL SELECT 'tipos_licenca',COUNT(*) FROM tipos_licenca
UNION ALL SELECT 'licencas',COUNT(*) FROM licencas
UNION ALL SELECT 'vestuario',COUNT(*) FROM vestuario
UNION ALL SELECT 'dados_residencia',COUNT(*) FROM dados_residencia
UNION ALL SELECT 'historico_especialistas',COUNT(*) FROM historico_especialistas
UNION ALL SELECT 'historico_equipamentos',COUNT(*) FROM historico_equipamentos
UNION ALL SELECT 'auditoria',COUNT(*) FROM auditoria
UNION ALL SELECT 'modelos_relatorio',COUNT(*) FROM modelos_relatorio;

-- 7) Colunas estruturais obrigatórias
SELECT TABLE_NAME,COLUMN_NAME,COLUMN_TYPE
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA=DATABASE()
AND ((TABLE_NAME='dados_servico' AND COLUMN_NAME='id_regiao')
 OR (TABLE_NAME='dados_pessoais' AND COLUMN_NAME IN('id_grupo_sanguineo','peso_kg','telefone_alternativo'))
 OR (TABLE_NAME='equipamentos' AND COLUMN_NAME IN('id_regiao','id_especialista_responsavel'))
 OR (TABLE_NAME='utilizadores' AND COLUMN_NAME IN('id_regiao_responsabilidade','tipo_responsabilidade')))
ORDER BY TABLE_NAME,COLUMN_NAME;

-- 8) Perfis
SELECT nome,nivel_acesso,estado FROM perfis ORDER BY nome;
