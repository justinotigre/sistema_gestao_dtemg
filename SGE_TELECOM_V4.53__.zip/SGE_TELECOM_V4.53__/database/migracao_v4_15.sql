-- Sistema de Gestão de Especialistas v4.15
-- Adiciona a província à formação. Seguro para executar em base existente.
-- Fazer cópia de segurança antes de aplicar.
ALTER TABLE formacoes ADD COLUMN IF NOT EXISTS id_provincia INT NULL AFTER id_pais;
CREATE INDEX IF NOT EXISTS idx_formacoes_provincia ON formacoes(id_provincia);
