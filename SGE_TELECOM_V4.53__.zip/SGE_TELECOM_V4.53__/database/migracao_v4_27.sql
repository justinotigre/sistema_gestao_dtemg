-- SGE TELECOM V4.27: quantidade de equipamentos para controlo de distribuição e stock.
-- Faça backup antes de executar. Pode ser executada mais do que uma vez.
SET @has_qt = (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='equipamentos' AND column_name='quantidade_total');
SET @sql_qt = IF(@has_qt=0, 'ALTER TABLE equipamentos ADD COLUMN quantidade_total INT UNSIGNED NOT NULL DEFAULT 1 AFTER data_aquisicao', 'SELECT 1');
PREPARE stmt_qt FROM @sql_qt; EXECUTE stmt_qt; DEALLOCATE PREPARE stmt_qt;
SET @has_qd = (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='equipamentos' AND column_name='quantidade_distribuida');
SET @sql_qd = IF(@has_qd=0, 'ALTER TABLE equipamentos ADD COLUMN quantidade_distribuida INT UNSIGNED NOT NULL DEFAULT 0 AFTER quantidade_total', 'SELECT 1');
PREPARE stmt_qd FROM @sql_qd; EXECUTE stmt_qd; DEALLOCATE PREPARE stmt_qd;
