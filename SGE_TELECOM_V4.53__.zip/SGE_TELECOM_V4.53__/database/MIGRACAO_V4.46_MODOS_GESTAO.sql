-- Executar somente após cópia de segurança. Compatível com MySQL/MariaDB.
-- Administradores de ramo já existentes ficam no modo RAMO, sem acesso adicional.
ALTER TABLE utilizadores ADD COLUMN modalidade_gestao ENUM('RAMO','LOCAL','COMBINADO') NOT NULL DEFAULT 'RAMO';
