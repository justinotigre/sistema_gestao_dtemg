-- V4.43: os especialistas civis não possuem ramo militar.
-- Efetuar cópia de segurança da base de dados antes de executar.
-- Executar uma única vez com o esquema selecionado no MySQL Workbench.
ALTER TABLE especialistas MODIFY COLUMN id_ramo INT NULL;
-- Remover a associação militar indevida de civis existentes.
-- A cláusula por chave primária evita o erro 1175 do Safe Update Mode.
UPDATE especialistas SET id_ramo=NULL, id_quadro=NULL, id_patente=NULL
WHERE id_especialista IN (SELECT id_especialista FROM (SELECT id_especialista FROM especialistas WHERE tipo_especialista='CIVIL') AS civis);
