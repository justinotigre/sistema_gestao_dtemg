-- Executar UMA vez, após cópia de segurança e após a migração de patentes V4.47.
ALTER TABLE feed_oportunidade_config
  ADD COLUMN grupo_hierarquico_criterio VARCHAR(40) NULL AFTER id_patente_criterio;
-- Para que os filtros funcionem, confirme em Configurações > Patentes que
-- cada patente militar tem grupo_hierarquico devidamente preenchido.
