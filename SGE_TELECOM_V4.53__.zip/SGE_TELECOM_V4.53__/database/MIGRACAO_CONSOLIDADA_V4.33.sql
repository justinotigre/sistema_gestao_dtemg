-- SGE TELECOM V4.33 | MIGRAÇÃO CONSOLIDADA DE MITIGAÇÃO
-- Executar APENAS uma vez, com cópia de segurança, na base SGE JÁ EXISTENTE.
-- Mantém os dados dos especialistas e não executa DROP/DELETE/TRUNCATE.
-- Inclui Feed v4.17/v4.20/v4.21, notificações v4.26, níveis v4.30, cursos e critérios v4.31.
-- Caso parte das migrações já exista, CREATE TABLE IF NOT EXISTS e verificações reduzem duplicações.
-- IMPORTANTE: não substitui todas as migrações históricas do sistema; pressupõe base principal e tabelas de RH pré-existentes.
-- Atenção: o SQL depende de esquema compatível com os nomes/colunas referidos; se ocorrer erro, pare e faça diagnóstico.

-- ===== migracao_v4_17_feed.sql =====
-- Sistema de Gestão de Especialistas v4.17
-- Execute esta migração uma única vez na base de dados existente.
CREATE TABLE IF NOT EXISTS feed_publicacoes (
  id_publicacao INT UNSIGNED NOT NULL AUTO_INCREMENT,
  titulo VARCHAR(180) NOT NULL,
  conteudo TEXT NOT NULL,
  area ENUM('RH','RM','TODOS') NOT NULL DEFAULT 'TODOS',
  tipo VARCHAR(30) NOT NULL DEFAULT 'COMUNICADO',
  data_limite DATE NULL,
  id_autor INT NULL,
  id_ramo INT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  estado ENUM('ATIVO','INATIVO') NOT NULL DEFAULT 'ATIVO',
  PRIMARY KEY (id_publicacao),
  KEY idx_feed_area_estado (area,estado),
  KEY idx_feed_ramo (id_ramo),
  KEY idx_feed_data (criado_em),
  CONSTRAINT fk_feed_autor FOREIGN KEY (id_autor) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL,
  CONSTRAINT fk_feed_ramo FOREIGN KEY (id_ramo) REFERENCES ramo(id_ramo) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS feed_leituras (
  id_publicacao INT UNSIGNED NOT NULL,
  id_utilizador INT NOT NULL,
  lido_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_publicacao,id_utilizador),
  KEY idx_feed_leitura_utilizador (id_utilizador),
  CONSTRAINT fk_feed_leitura_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
  CONSTRAINT fk_feed_leitura_utilizador FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS feed_candidaturas (
  id_candidatura BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_publicacao INT UNSIGNED NOT NULL,
  id_especialista INT NOT NULL,
  estado VARCHAR(30) NOT NULL DEFAULT 'SUBMETIDA',
  submetido_por INT NULL,
  submetido_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_candidatura),
  UNIQUE KEY uq_feed_candidatura (id_publicacao,id_especialista),
  KEY idx_feed_candidatura_especialista (id_especialista),
  CONSTRAINT fk_feed_candidatura_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
  CONSTRAINT fk_feed_candidatura_especialista FOREIGN KEY (id_especialista) REFERENCES especialistas(id_especialista) ON DELETE CASCADE,
  CONSTRAINT fk_feed_candidatura_autor FOREIGN KEY (submetido_por) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ===== migracao_v4_20_feed_interacao.sql =====
-- SE TELECOM v4.20: anexos, reações e comentários persistentes do Feed.
-- Executar depois de migracao_v4_17_feed.sql.
CREATE TABLE IF NOT EXISTS feed_anexos (
 id_anexo BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 id_publicacao INT UNSIGNED NOT NULL,
 nome_original VARCHAR(240) NOT NULL,
 nome_guardado VARCHAR(80) NOT NULL,
 mime_type VARCHAR(120) NOT NULL,
 tamanho_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
 criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id_anexo), KEY idx_feed_anexos_publicacao (id_publicacao),
 CONSTRAINT fk_feed_anexo_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_reacoes (
 id_publicacao INT UNSIGNED NOT NULL, id_utilizador INT NOT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id_publicacao,id_utilizador), KEY idx_feed_reacao_utilizador (id_utilizador),
 CONSTRAINT fk_feed_reacao_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
 CONSTRAINT fk_feed_reacao_utilizador FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_comentarios (
 id_comentario BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, id_publicacao INT UNSIGNED NOT NULL, id_utilizador INT NOT NULL, comentario TEXT NOT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id_comentario), KEY idx_feed_comentarios_publicacao (id_publicacao), KEY idx_feed_comentarios_utilizador (id_utilizador),
 CONSTRAINT fk_feed_comentario_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
 CONSTRAINT fk_feed_comentario_utilizador FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ===== migracao_v4_21_feed_permissoes_oportunidades.sql =====
-- SE TELECOM v4.21: controlo de acesso do Feed e critérios para oportunidades.
-- Executar depois das migrações v4.17 e v4.20.
CREATE TABLE IF NOT EXISTS feed_permissoes_perfil (
 id_perfil INT NOT NULL,
 pode_ler TINYINT(1) NOT NULL DEFAULT 1,
 pode_publicar TINYINT(1) NOT NULL DEFAULT 0,
 pode_submeter TINYINT(1) NOT NULL DEFAULT 1,
 pode_gerir TINYINT(1) NOT NULL DEFAULT 0,
 atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (id_perfil),
 CONSTRAINT fk_feed_perm_perfil FOREIGN KEY (id_perfil) REFERENCES perfis(id_perfil) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_oportunidade_config (
 id_publicacao INT UNSIGNED NOT NULL,
 id_ramo_criterio INT NULL,
 id_quadro_criterio INT NULL,
 id_patente_criterio INT NULL,
 id_nivel_habilitacao INT NULL,
 criterios_texto TEXT NULL,
 atualizado_por INT NULL,
 atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (id_publicacao),
 CONSTRAINT fk_feed_opp_config_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
 CONSTRAINT fk_feed_opp_config_ramo FOREIGN KEY (id_ramo_criterio) REFERENCES ramo(id_ramo) ON DELETE SET NULL,
 CONSTRAINT fk_feed_opp_config_quadro FOREIGN KEY (id_quadro_criterio) REFERENCES quadros_servico(id_quadro) ON DELETE SET NULL,
 CONSTRAINT fk_feed_opp_config_patente FOREIGN KEY (id_patente_criterio) REFERENCES patentes(id_patente) ON DELETE SET NULL,
 CONSTRAINT fk_feed_opp_config_nivel FOREIGN KEY (id_nivel_habilitacao) REFERENCES niveis_habilitacao(id_nivel_habilitacao) ON DELETE SET NULL,
 CONSTRAINT fk_feed_opp_config_utilizador FOREIGN KEY (atualizado_por) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Valores iniciais: leitura/submissão para perfis ativos; publicação/gestão para perfis administrativos.
INSERT INTO feed_permissoes_perfil (id_perfil,pode_ler,pode_publicar,pode_submeter,pode_gerir)
SELECT p.id_perfil,1,
 CASE WHEN p.nome IN ('ADMINISTRADOR_GLOBAL','ADMINISTRADOR_RAMO','ADMINISTRADOR_REGIAO','ADMINISTRADOR_RH','ADMINISTRADOR_RM') THEN 1 ELSE 0 END,
 1,
 CASE WHEN p.nome IN ('ADMINISTRADOR_GLOBAL','ADMINISTRADOR_RAMO','ADMINISTRADOR_REGIAO','ADMINISTRADOR_RH') THEN 1 ELSE 0 END
FROM perfis p WHERE p.estado='ATIVO'
ON DUPLICATE KEY UPDATE id_perfil=VALUES(id_perfil);

-- Compatibilidade: corrige o nome de coluna da migração v4.20 antiga, se necessário.
SET @feed_rename_sql = IF(
 (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='feed_anexos' AND column_name='nome_armazenado') > 0
 AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='feed_anexos' AND column_name='nome_guardado') = 0,
 'ALTER TABLE feed_anexos CHANGE COLUMN nome_armazenado nome_guardado VARCHAR(80) NOT NULL',
 'SELECT 1'
);
PREPARE feed_rename_stmt FROM @feed_rename_sql;
EXECUTE feed_rename_stmt;
DEALLOCATE PREPARE feed_rename_stmt;


-- ===== migracao_v4_26.sql =====
-- SGE TELECOM V4.26. Migração aditiva; efectuar backup antes de executar.
CREATE TABLE IF NOT EXISTS perfil_modulos (
  id_perfil INT NOT NULL, modulo VARCHAR(100) NOT NULL,
  pode_visualizar TINYINT(1) NOT NULL DEFAULT 0, pode_configurar TINYINT(1) NOT NULL DEFAULT 0,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id_perfil, modulo),
  CONSTRAINT fk_perfil_modulos_perfil_v426 FOREIGN KEY (id_perfil) REFERENCES perfis(id_perfil) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS notificacoes (
  id_notificacao BIGINT AUTO_INCREMENT PRIMARY KEY, id_utilizador INT NULL, categoria VARCHAR(50) NOT NULL,
  titulo VARCHAR(180) NOT NULL, mensagem TEXT NOT NULL, url_destino VARCHAR(500) NULL,
  entidade VARCHAR(100) NULL, id_entidade BIGINT NULL, data_evento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, lida_em DATETIME NULL,
  INDEX idx_notificacao_utilizador_lida (id_utilizador,lida_em), INDEX idx_notificacao_categoria_data (categoria,data_evento),
  CONSTRAINT fk_notificacoes_utilizador_v426 FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_leituras (
  id_publicacao INT NOT NULL, id_utilizador INT NOT NULL, lida_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_publicacao,id_utilizador),
  CONSTRAINT fk_feed_leituras_utilizador_v426 FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_avaliacoes (
  id_publicacao INT NOT NULL, id_utilizador INT NOT NULL, estrelas TINYINT UNSIGNED NOT NULL,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id_publicacao,id_utilizador),
  CONSTRAINT chk_feed_estrelas_v426 CHECK (estrelas BETWEEN 1 AND 5),
  CONSTRAINT fk_feed_avaliacoes_utilizador_v426 FOREIGN KEY (id_utilizador) REFERENCES utilizadores(id_utilizador) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ===== Níveis V4.30; apenas inserir ausentes =====
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Alfabetização',1 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Alfabetização');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Ensino Primário',2 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Ensino Primário');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'I Ciclo do Ensino Secundário',3 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='I Ciclo do Ensino Secundário');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'II Ciclo do Ensino Secundário',4 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='II Ciclo do Ensino Secundário');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Ensino Médio',5 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Ensino Médio');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Ensino Médio Técnico',6 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Ensino Médio Técnico');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Bacharelato',7 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Bacharelato');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Licenciatura',8 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Licenciatura');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Pós-Graduação',9 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Pós-Graduação');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Mestrado',10 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Mestrado');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Doutoramento',11 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Doutoramento');
INSERT INTO niveis_habilitacao(nome,ordem) SELECT 'Pós-Doutoramento',12 WHERE NOT EXISTS (SELECT 1 FROM niveis_habilitacao WHERE nome='Pós-Doutoramento');


-- ===== Catálogo e critérios V4.31 =====
-- SGE TELECOM V4.31: catálogo de cursos e filtros por idade para oportunidades.
-- Execute na base de dados ativa após criar uma cópia de segurança.
CREATE TABLE IF NOT EXISTS cursos_habilitacao (
 id_curso INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(200) NOT NULL UNIQUE,
 estado VARCHAR(12) NOT NULL DEFAULT 'ATIVO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO cursos_habilitacao(nome)
 SELECT DISTINCT TRIM(curso) FROM habilitacoes_literarias WHERE curso IS NOT NULL AND TRIM(curso)<>'';
INSERT IGNORE INTO cursos_habilitacao(nome) VALUES
 ('Engenharia Informática'),('Engenharia de Telecomunicações'),('Gestão'),('Administração Pública'),('Direito'),('Medicina'),('Enfermagem'),('Contabilidade'),('Informática'),('Logística');
-- Reexecutável: só cria as colunas se ainda não existirem.
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='feed_oportunidade_config' AND column_name='idade_minima')=0,'ALTER TABLE feed_oportunidade_config ADD COLUMN idade_minima INT NULL','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='feed_oportunidade_config' AND column_name='idade_maxima')=0,'ALTER TABLE feed_oportunidade_config ADD COLUMN idade_maxima INT NULL','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

