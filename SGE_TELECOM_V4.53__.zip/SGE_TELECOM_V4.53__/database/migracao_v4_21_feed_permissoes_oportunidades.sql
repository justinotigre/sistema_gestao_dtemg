-- SE TELECOM v4.21: controlo de acesso do Feed e critérios para oportunidades.
-- Executar depois das migrações v4.17 e v4.20.
CREATE TABLE IF NOT EXISTS feed_permissoes_perfil (
 id_perfil INT NOT NULL,
 pode_ler TINYINT(1) NOT NULL DEFAULT 1,
 pode_publicar TINYINT(1) NOT NULL DEFAULT 0,
 pode_submeter TINYINT(1) NOT NULL DEFAULT 1,
 pode_gerir TINYINT(1) NOT NULL DEFAULT 0,
 atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (id_perfil),
 CONSTRAINT fk_feed_perm_perfil FOREIGN KEY (id_perfil) REFERENCES perfis(id_perfil) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS feed_oportunidade_config (
 id_publicacao INT UNSIGNED NOT NULL,
 id_ramo_criterio INT NULL,
 id_quadro_criterio INT NULL,
 id_patente_criterio INT NULL,
 id_nivel_habilitacao INT NULL,
 criterios_texto TEXT NULL,
 atualizado_por INT NULL,
 atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (id_publicacao),
 CONSTRAINT fk_feed_opp_config_publicacao FOREIGN KEY (id_publicacao) REFERENCES feed_publicacoes(id_publicacao) ON DELETE CASCADE,
 CONSTRAINT fk_feed_opp_config_ramo FOREIGN KEY (id_ramo_criterio) REFERENCES ramo(id_ramo) ON DELETE SET NULL,
 CONSTRAINT fk_feed_opp_config_quadro FOREIGN KEY (id_quadro_criterio) REFERENCES quadros_servico(id_quadro) ON DELETE SET NULL,
 CONSTRAINT fk_feed_opp_config_patente FOREIGN KEY (id_patente_criterio) REFERENCES patentes(id_patente) ON DELETE SET NULL,
 CONSTRAINT fk_feed_opp_config_nivel FOREIGN KEY (id_nivel_habilitacao) REFERENCES niveis_habilitacao(id_nivel_habilitacao) ON DELETE SET NULL,
 CONSTRAINT fk_feed_opp_config_utilizador FOREIGN KEY (atualizado_por) REFERENCES utilizadores(id_utilizador) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Valores iniciais: leitura/submissão para perfis ativos; publicação/gestão para perfis administrativos.
INSERT INTO feed_permissoes_perfil (id_perfil,pode_ler,pode_publicar,pode_submeter,pode_gerir)
SELECT p.id_perfil,1,
 CASE WHEN p.nome IN ('ADMINISTRADOR_GLOBAL','ADMINISTRADOR_RAMO','ADMINISTRADOR_REGIAO','ADMINISTRADOR_RH','ADMINISTRADOR_RM') THEN 1 ELSE 0 END,
 1,
 CASE WHEN p.nome IN ('ADMINISTRADOR_GLOBAL','ADMINISTRADOR_RAMO','ADMINISTRADOR_REGIAO','ADMINISTRADOR_RH') THEN 1 ELSE 0 END
FROM perfis p WHERE p.estado='ATIVO'
ON DUPLICATE KEY UPDATE id_perfil=VALUES(id_perfil);

-- Compatibilidade: corrige o nome de coluna da migração v4.20 antiga, se necessário.
SET @feed_rename_sql = IF(
 (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='feed_anexos' AND column_name='nome_armazenado') > 0
 AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='feed_anexos' AND column_name='nome_guardado') = 0,
 'ALTER TABLE feed_anexos CHANGE COLUMN nome_armazenado nome_guardado VARCHAR(80) NOT NULL',
 'SELECT 1'
);
PREPARE feed_rename_stmt FROM @feed_rename_sql;
EXECUTE feed_rename_stmt;
DEALLOCATE PREPARE feed_rename_stmt;
