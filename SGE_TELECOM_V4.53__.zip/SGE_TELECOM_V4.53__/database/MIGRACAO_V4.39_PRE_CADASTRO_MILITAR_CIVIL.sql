-- SGE TELECOM V4.39 — pré-cadastro Militar/Civil e Local de Serviço
-- Fazer backup integral da BD antes de executar. Pode ser executada mais de uma vez.
SET @db_name = DATABASE();

SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db_name AND table_name='especialistas' AND column_name='tipo_especialista')=0,
  'ALTER TABLE especialistas ADD COLUMN tipo_especialista ENUM(''MILITAR'',''CIVIL'') NOT NULL DEFAULT ''MILITAR'' AFTER id_patente', 'SELECT 1');
PREPARE sge_stmt FROM @sql; EXECUTE sge_stmt; DEALLOCATE PREPARE sge_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db_name AND table_name='dados_servico' AND column_name='local_servico')=0,
  'ALTER TABLE dados_servico ADD COLUMN local_servico ENUM(''EMG'',''EXE'',''FAN'',''MGA'') NULL AFTER id_regiao', 'SELECT 1');
PREPARE sge_stmt FROM @sql; EXECUTE sge_stmt; DEALLOCATE PREPARE sge_stmt;

-- EMG deixa de ser ramo organizacional. A atribuição histórica não é apagada.
UPDATE ramo SET estado='INATIVO' WHERE UPPER(sigla)='EMG';

-- Classificação automática conservadora dos registos cujo quadro indica explicitamente Civil.
UPDATE especialistas e
JOIN quadros_servico q ON q.id_quadro=e.id_quadro
SET e.tipo_especialista='CIVIL', e.id_patente=NULL
WHERE LOWER(q.nome) LIKE '%civil%';
