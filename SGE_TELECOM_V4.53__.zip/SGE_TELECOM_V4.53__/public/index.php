<?php
require_once __DIR__ . '/../app/auth.php';
if (!empty($_SESSION['user'])) { header('Location: sistema.php'); exit; }

$erro='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify_post();
    $username=trim($_POST['username']??'');
    $password=$_POST['password']??'';
    if ($username==='' || $password==='') $erro='Informe o utilizador e a palavra-passe.';
    elseif (login_user($username,$password)) { header('Location: sistema.php'); exit; }
    else $erro='Utilizador ou palavra-passe inválidos.';
}
?>
<!doctype html>
<html lang="pt">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Entrar — <?= htmlspecialchars(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/css/app.css">
<style>
:root{--navy:#0b2d4f;--blue:#176b9d;--gold:#f2ad19;--ink:#17324f;--muted:#7186a0;--line:#d5e2ef}
body.login{min-height:100vh;display:grid;place-items:center;padding:24px;background:radial-gradient(circle at 12% 15%,#dceaf6 0,transparent 28%),radial-gradient(circle at 88% 85%,#e6eef6 0,transparent 28%),#f3f6f9;color:var(--ink)}
.login-shell{display:grid;grid-template-columns:minmax(260px, .82fr) minmax(420px,1.18fr);width:min(100%,1100px);min-height:590px;overflow:hidden;border:1px solid #d7e3ef;border-radius:20px;background:#fff;box-shadow:0 24px 70px #17324f18}
.login-side{position:relative;overflow:hidden;padding:48px 38px;background:linear-gradient(145deg,#123c62,#092846 78%);color:#fff}
.login-side:before{content:"";position:absolute;inset:0;background-image:url("assets/images/insignia-faa.png");background-repeat:no-repeat;background-position:center 86%;background-size:min(78%, 330px) auto;opacity:.10;pointer-events:none;filter:grayscale(1)}
.login-side:after{content:none}
.login-brand{position:relative;z-index:1;display:flex;align-items:center;gap:14px;margin-bottom:38px}.login-brand-mark{width:72px;height:72px;flex:0 0 72px;border:1px solid #70a5ce;border-radius:18px;background:#0c3559;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;font-weight:850;font-size:22px;letter-spacing:-.7px}.login-brand-mark span{position:relative}.login-brand-mark span:after{content:")))";position:absolute;left:calc(100% + 2px);top:-3px;color:var(--gold);font-size:15px;letter-spacing:-5px;transform:scaleY(1.3)}.login-brand-mark i{font-size:9px;letter-spacing:2px;font-style:normal;margin-top:3px}.login-brand strong{display:none;font-size:19px;letter-spacing:.01em;color:#fff}.login-brand small{display:block;margin-top:6px;color:#bfd0e1;font-size:11px;letter-spacing:.1em;text-transform:uppercase;line-height:1.5}
.insignia-carousel{position:relative;z-index:1;display:flex;align-items:center;justify-content:center;min-height:340px;margin:0 auto;max-width:420px}.insignia-slide{display:none;width:100%;height:310px;align-items:center;justify-content:center;animation:insigniaFade .55s ease}.insignia-slide.active{display:flex}.insignia-slide img{display:block;width:auto;height:auto;max-width:88%;max-height:292px;object-fit:contain;image-rendering:auto;filter:drop-shadow(0 14px 18px #00172a66)}.carousel-arrow{position:absolute;z-index:2;top:50%;transform:translateY(-50%);width:36px;height:36px;border:1px solid #7aa9cfaa;border-radius:50%;display:grid;place-items:center;background:#0b2d4f88;color:#d9eafa;font-size:25px;line-height:1;cursor:pointer;transition:background .2s,border-color .2s}.carousel-arrow:hover{background:#176b9d;border-color:#f2ad19}.carousel-prev{left:0}.carousel-next{right:0}.carousel-dots{position:absolute;bottom:0;left:0;right:0;display:flex;justify-content:center;gap:9px}.carousel-dot{width:8px;height:8px;border-radius:50%;border:0;padding:0;background:#6b8eaf88;cursor:pointer}.carousel-dot.active{background:var(--gold);transform:scale(1.15)}@keyframes insigniaFade{from{opacity:.25;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
.login-main{display:flex;flex-direction:column;justify-content:center;padding:56px clamp(30px,5vw,76px);background:linear-gradient(145deg,#fff,#fcfdff)}.login-main h1{font-size:32px;line-height:1.2;color:#102f50;margin:0 0 10px;letter-spacing:-.03em}.login-intro{margin:0 0 35px;color:var(--muted);line-height:1.55;font-size:15px}.login-box form{display:grid;gap:9px}.login-box label{font-weight:650;color:#233e5b;font-size:14px;margin-top:8px}.field-wrap{position:relative;display:block;width:100%;}.field-wrap input{display:block;box-sizing:border-box;width:100%;min-height:52px;padding:13px 52px 13px 15px;border:1px solid var(--line);border-radius:11px;background:#fbfdff;color:#162f4c;font:inherit;outline:none;transition:border-color .18s,box-shadow .18s}.field-wrap input:focus{border-color:#3984b8;box-shadow:0 0 0 3px #3984b81c;background:#fff}.field-icon{position:absolute;left:15px;top:50%;transform:translateY(-50%);color:#7890a8;pointer-events:none}.field-wrap.has-icon input{padding-left:43px}.field-wrap .password-toggle{position:absolute!important;right:10px!important;top:50%!important;bottom:auto!important;left:auto!important;transform:translateY(-50%)!important;display:flex!important;align-items:center!important;justify-content:center!important;box-sizing:border-box!important;width:28px!important;min-width:28px!important;max-width:28px!important;height:28px!important;min-height:28px!important;max-height:28px!important;margin:0!important;padding:0!important;border:0!important;border-radius:50%!important;background:transparent!important;box-shadow:none!important;line-height:1!important;cursor:pointer;color:#526f8b!important;z-index:3}.field-wrap .password-toggle svg{display:block!important;flex:0 0 16px;width:16px!important;height:16px!important;min-width:16px!important;min-height:16px!important;margin:0!important;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.field-wrap .password-toggle:hover{background:#edf4fa!important;color:#0e4d7a!important}.password-toggle:hover{background:#edf4fa;color:#0e4d7a}.password-toggle:focus-visible{outline:2px solid #3984b8;outline-offset:2px}.login-options{display:flex;align-items:center;margin:13px 0 8px;color:#526b84;font-size:13px}.remember{display:flex;align-items:center;gap:9px;cursor:pointer}.remember input{width:16px;height:16px;accent-color:#176b9d}.login-box button[type=submit]{margin-top:13px;min-height:52px;border:0;border-radius:11px;background:linear-gradient(105deg,#103e69,#176b9d);color:#fff;font-weight:700;font-size:15px;cursor:pointer;box-shadow:0 9px 20px #123b681c;transition:transform .18s,filter .18s}.login-box button[type=submit]:hover{filter:brightness(1.08);transform:translateY(-1px)}.login-box button[type=submit] span{margin-left:8px}.login-foot{display:flex;align-items:center;gap:12px;margin-top:27px;color:#8799ad;font-size:11px;justify-content:center}.login-foot:before,.login-foot:after{content:"";height:1px;background:#e0e8f0;flex:1}.erro{padding:10px 12px;margin:0 0 12px;border:1px solid #fecaca;border-radius:9px;background:#fff1f2;color:#9f1239;font-size:13px}
@media(max-width:760px){body.login{padding:14px}.login-shell{grid-template-columns:1fr;max-width:520px}.login-side{padding:25px 25px 22px}.login-brand{margin-bottom:12px}.login-brand-mark{width:58px;height:58px;flex-basis:58px}.login-side:before{background-size:min(58%, 220px);background-position:center 82%}.insignia-carousel{min-height:230px;max-width:340px}.insignia-slide{height:205px}.insignia-slide img{max-height:185px;max-width:72%}.carousel-dots{bottom:0}.login-main{padding:32px 25px 28px}.login-main h1{font-size:27px}.login-intro{margin-bottom:22px}}
@media(max-width:390px){.login-brand strong{font-size:16px}.login-brand small{font-size:9px}}
</style>
</head>
<body class="login">
<main class="login-shell">
  <aside class="login-side" aria-label="Identidade e emblemas dos ramos">
    <div class="login-brand"><div class="login-brand-mark"><span>SGE</span><i>TELECOM</i></div><div><strong>SGE TELECOM</strong><small>Sistema de Gestão<br>de Especialidade</small></div></div>
    <div class="insignia-carousel" id="insigniaCarousel" aria-label="Emblemas dos ramos" aria-live="polite">
      <button class="carousel-arrow carousel-prev" type="button" aria-label="Emblema anterior">‹</button>
      <div class="insignia-slide active"><img src="assets/images/ramo-emg.png" alt="Emblema do Estado-Maior General"></div>
      <div class="insignia-slide"><img src="assets/images/ramo-exercito.png" alt="Emblema do Exército"></div>
      <div class="insignia-slide"><img src="assets/images/ramo-fan.png" alt="Emblema da Força Aérea Nacional"></div>
      <div class="insignia-slide"><img src="assets/images/ramo-mga.png" alt="Emblema da Marinha de Guerra"></div>
      <button class="carousel-arrow carousel-next" type="button" aria-label="Próximo emblema">›</button>
      <div class="carousel-dots" aria-label="Escolher emblema">
        <button class="carousel-dot active" type="button" aria-label="Emblema 1"></button><button class="carousel-dot" type="button" aria-label="Emblema 2"></button><button class="carousel-dot" type="button" aria-label="Emblema 3"></button><button class="carousel-dot" type="button" aria-label="Emblema 4"></button>
      </div>
    </div>
    </aside>
  <section class="login-main">
    <h1>Bem-vindo!</h1>
    <p class="login-intro">Entre com as suas credenciais para aceder à plataforma.</p>
    <?php if($erro): ?><div class="erro" role="alert"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
    <form method="post" autocomplete="on" class="login-box">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
      <label for="username">Utilizador</label>
      <div class="field-wrap has-icon"><span class="field-icon" aria-hidden="true"><svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0z"/></svg></span><input id="username" type="text" name="username" autocomplete="username" placeholder="Digite o seu utilizador" required autofocus></div>
      <label for="password">Palavra-passe</label>
      <div class="field-wrap has-icon"><span class="field-icon" aria-hidden="true"><svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="10" width="16" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="16" r="1.5"/></svg></span><input id="password" type="password" name="password" autocomplete="current-password" placeholder="Digite a sua palavra-passe" required><button class="password-toggle" type="button" id="togglePassword" aria-label="Mostrar palavra-passe" title="Mostrar palavra-passe"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg></button></div>
      <div class="login-options"><label class="remember"><input type="checkbox" name="remember" value="1"> Manter sessão ativa</label></div>
      <button type="submit">Entrar no sistema <span aria-hidden="true">→</span></button>
    </form>
    <div class="login-foot">SGE TELECOM · v4.29</div>
  </section>
</main>
<script>
document.getElementById('togglePassword').addEventListener('click',function(){
 const input=document.getElementById('password'), mostrar=input.type==='password';
 input.type=mostrar?'text':'password';
 this.setAttribute('aria-label',mostrar?'Ocultar palavra-passe':'Mostrar palavra-passe');
 this.title=mostrar?'Ocultar palavra-passe':'Mostrar palavra-passe';
 this.innerHTML=mostrar?'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M10.6 6.2A10.8 10.8 0 0 1 12 6c6.5 0 10 6 10 6a17 17 0 0 1-3.1 3.7M6.2 6.2C3.5 8 2 12 2 12s3.5 6 10 6c1.3 0 2.5-.3 3.5-.7"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg>';
});

(function(){
 const root=document.getElementById('insigniaCarousel'); if(!root) return;
 const slides=Array.from(root.querySelectorAll('.insignia-slide'));
 const dots=Array.from(root.querySelectorAll('.carousel-dot'));
 let index=0, timer;
 function show(next){index=(next+slides.length)%slides.length;slides.forEach((el,i)=>el.classList.toggle('active',i===index));dots.forEach((el,i)=>el.classList.toggle('active',i===index));}
 function restart(){clearInterval(timer);timer=setInterval(()=>show(index+1),5000);}
 root.querySelector('.carousel-prev').addEventListener('click',()=>{show(index-1);restart();});
 root.querySelector('.carousel-next').addEventListener('click',()=>{show(index+1);restart();});
 dots.forEach((dot,i)=>dot.addEventListener('click',()=>{show(i);restart();}));
 root.addEventListener('mouseenter',()=>clearInterval(timer));
 root.addEventListener('mouseleave',restart);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)clearInterval(timer);else restart();});
 restart();
})();
</script>
</body>
</html>
