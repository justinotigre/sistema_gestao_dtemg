<?php
require_once __DIR__ . '/../app/auth.php';
require_login();
header('Location: ' . app_url('modulos/dashboard.php'));
exit;
