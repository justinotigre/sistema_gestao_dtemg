<?php
require_once __DIR__.'/../app/auth.php';
require_login();
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit;}
$tema=$_POST['tema']??'';
if(!in_array($tema,['CLARO','ESCURO'],true)){http_response_code(400);exit('Tema inválido.');}
db()->prepare('UPDATE utilizadores SET tema=? WHERE id_utilizador=?')->execute([$tema,current_user_id()]);
$_SESSION['user']['tema']=$tema;
header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>true,'tema'=>$tema]);
