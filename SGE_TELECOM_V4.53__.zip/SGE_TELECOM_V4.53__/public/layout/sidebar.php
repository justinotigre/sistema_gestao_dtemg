<?php
$u = $_SESSION['user'] ?? [];
$nivel = $u['nivel'] ?? '';
$scriptAtual = str_replace('\\','/', $_SERVER['SCRIPT_NAME'] ?? '');
$moduloAtual = basename($scriptAtual);
$temRH = has_permission('ESPECIALISTAS_VISUALIZAR');
$temRM = has_permission('EQUIPAMENTOS_VISUALIZAR');
$naoLidasFeed = 0;
try {
    $condFeed = "p.estado='ATIVO'"; $parFeed=[];
    if (($u['nivel'] ?? '') === 'RAMO') { $rids=current_user_branch_ids(); if(!$rids) $condFeed.=' AND 1=0'; else { $condFeed.=' AND p.id_ramo IN ('.implode(',',array_fill(0,count($rids),'?')).')'; $parFeed=$rids; } }
    $stUnread = db()->prepare("SELECT COUNT(*) FROM feed_publicacoes p WHERE $condFeed AND NOT EXISTS (SELECT 1 FROM feed_leituras l WHERE l.id_publicacao=p.id_publicacao AND l.id_utilizador=?)"); $stUnread->execute(array_merge($parFeed,[(int)($u['id'] ?? 0)])); $naoLidasFeed=(int)$stUnread->fetchColumn();
} catch(Throwable $e) {}
$alertas = 0;
try { $paramsAlert=[]; $scopeAlert=scope_sql($paramsAlert,'e','especialista'); $stAlert=db()->prepare("SELECT COUNT(*) FROM documentos d JOIN especialistas e ON e.id_especialista=d.id_especialista WHERE d.id_especialista IS NOT NULL AND d.data_validade IS NOT NULL AND d.data_validade<=DATE_ADD(CURDATE(),INTERVAL 30 DAY) AND ($scopeAlert)"); $stAlert->execute($paramsAlert); $alertas=(int)$stAlert->fetchColumn(); } catch(Throwable $e) {}
?>
<aside id="menuLateral" class="sistema-sidebar" aria-label="Menu principal">
  <div class="sidebar-section-title">Principal</div>
  <nav class="sidebar-nav">
    <?php if (has_permission('DASHBOARD_VISUALIZAR')): ?><a class="sidebar-link <?= $moduloAtual === 'dashboard.php' ? 'ativo' : '' ?>" href="<?= htmlspecialchars(app_url('modulos/dashboard.php')) ?>"><span class="sidebar-icon">⌂</span><span>Dashboard</span></a><?php endif; ?>
  </nav>

  <?php if ($temRH): ?>
  <div class="sidebar-section-title">Recursos Humanos</div>
  <nav class="sidebar-nav">
    <a class="sidebar-link <?= $moduloAtual === 'especialistas.php' ? 'ativo' : '' ?>" href="<?= htmlspecialchars(app_url('modulos/especialista/especialistas.php')) ?>"><span class="sidebar-icon">♙</span><span>Especialistas</span></a>
  </nav>
  <?php endif; ?>

  <?php if ($temRM): ?>
  <div class="sidebar-section-title">Recursos Materiais</div>
  <nav class="sidebar-nav">
    <a class="sidebar-link <?= $moduloAtual === 'equipamentos.php' ? 'ativo' : '' ?>" href="<?= htmlspecialchars(app_url('modulos/equipamentos.php')) ?>"><span class="sidebar-icon">▣</span><span>Equipamentos</span></a>
  </nav>
  <?php endif; ?>

  <?php if (has_permission('UTILIZADORES_VISUALIZAR')): ?>
  <div class="sidebar-section-title">Administração</div>
  <nav class="sidebar-nav"><a class="sidebar-link <?= $moduloAtual === 'utilizadores.php' ? 'ativo' : '' ?>" href="<?= htmlspecialchars(app_url('modulos/utilizadores.php')) ?>"><span class="sidebar-icon">♧</span><span>Utilizadores</span></a></nav>
  <?php endif; ?>

  <div class="sidebar-separator"></div>
  <div class="sidebar-section-title">Sistema</div>
  <nav class="sidebar-nav">
    <a class="sidebar-link <?= $moduloAtual === 'feed.php' ? 'ativo' : '' ?>" href="<?= htmlspecialchars(app_url('modulos/feed.php?secao=feed')) ?>"><span class="sidebar-icon">▤</span><span>Feed</span><?php if($naoLidasFeed>0):?><b class="sidebar-badge"><?=$naoLidasFeed>99?'99+':$naoLidasFeed?></b><?php endif;?></a>
    <a class="sidebar-link <?= $moduloAtual === 'notificacoes.php' ? 'ativo' : '' ?>" href="<?= htmlspecialchars(app_url('modulos/notificacoes.php')) ?>"><span class="sidebar-icon">♧</span><span>Notificações</span><?php if($alertas>0):?><b class="sidebar-badge"><?=$alertas>99?'99+':$alertas?></b><?php endif;?></a>
    <?php if (has_permission('CONFIGURACOES_VISUALIZAR')): ?><a class="sidebar-link <?= $moduloAtual === 'configuracoes.php' ? 'ativo' : '' ?>" href="<?= htmlspecialchars(app_url('modulos/configuracoes/configuracoes.php')) ?>"><span class="sidebar-icon">⚙</span><span>Configurações</span></a><?php endif; ?>
    <?php if (has_permission('AUDITORIA_VISUALIZAR')): ?><a class="sidebar-link <?= $moduloAtual === 'auditoria.php' ? 'ativo' : '' ?>" href="<?= htmlspecialchars(app_url('modulos/configuracoes/auditoria.php')) ?>"><span class="sidebar-icon">◷</span><span>Auditoria</span></a><?php endif; ?>
  </nav>

  <div class="sidebar-info"><span class="sidebar-info-label">Perfil de acesso</span><strong><?= htmlspecialchars($u['perfil'] ?? 'Utilizador') ?></strong><small><?= htmlspecialchars($nivel ?: '—') ?></small></div>
</aside>
