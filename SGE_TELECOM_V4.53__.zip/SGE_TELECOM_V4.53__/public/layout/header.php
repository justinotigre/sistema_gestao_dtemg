<?php
if (!isset($page_title)) $page_title = APP_NAME;
$usuario = $_SESSION['user'] ?? [];
$nomeUtilizador = $usuario['nome'] ?? 'Utilizador';
$perfilUtilizador = $usuario['perfil'] ?? '';
$nivelUtilizador = strtoupper((string)($usuario['nivel'] ?? 'GLOBAL'));
$inicialUtilizador = strtoupper(substr(trim($nomeUtilizador), 0, 1));
if ($inicialUtilizador === '') $inicialUtilizador = 'U';
$fotoUtilizador = $usuario['foto'] ?? null;
$corIdentidade = $nivelUtilizador === 'GLOBAL' ? '#1687C9' : '#1687C9';
if ($nivelUtilizador === 'RAMO') {
    try {
        $stIdent = db()->prepare("SELECT r.cor_principal FROM utilizador_ramo ur JOIN ramo r ON r.id_ramo=ur.id_ramo WHERE ur.id_utilizador=? ORDER BY ur.id_ramo LIMIT 1");
        $stIdent->execute([(int)($usuario['id'] ?? 0)]);
        $c = trim((string)$stIdent->fetchColumn());
        if (preg_match('/^#[0-9a-fA-F]{6}$/', $c)) $corIdentidade = (strtoupper($c) === '#FFFFFF') ? '#8FA7B8' : $c;
    } catch (Throwable $e) {}
}
?>
<!doctype html>
<html lang="pt" class="<?= (($usuario['tema'] ?? 'CLARO') === 'ESCURO') ? 'modo-escuro' : '' ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($page_title) ?> — <?= htmlspecialchars(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= htmlspecialchars(app_url('assets/css/app.css')) ?>">
</head>
<body style="--identity-accent:<?= htmlspecialchars($corIdentidade, ENT_QUOTES, 'UTF-8') ?>;">
<div class="app-frame">
<header class="sistema-topbar">
  <button type="button" id="btnMenuLateral" class="btn-menu-lateral" aria-label="Recolher ou expandir menu" aria-expanded="true" aria-controls="menuLateral" title="Recolher menu">☰</button>
  <div class="sistema-marca">
    <div class="sistema-logo sistema-logo-stacked"><span>SGE</span><small>TELECOM</small></div>
    <div class="sistema-titulo-wrap">
      <strong>SGE TELECOM</strong>
      <small>Plataforma integrada de gestão</small>
    </div>
  </div>

  <div class="sistema-utilizador <?= $nivelUtilizador === 'GLOBAL' ? 'identity-global' : ('identity-'.strtolower($nivelUtilizador)) ?>" style="--identity-accent:<?= htmlspecialchars($corIdentidade, ENT_QUOTES, 'UTF-8') ?>;">
    <a class="perfil-utilizador perfil-utilizador-link" href="<?= htmlspecialchars(app_url('modulos/utilizador_editar.php?id=' . (int)($usuario['id'] ?? 0))) ?>" title="Editar o meu perfil">
      <?php if ($fotoUtilizador): ?>
        <img class="foto-utilizador" src="<?= htmlspecialchars(app_file_url($fotoUtilizador)) ?>" alt="Fotografia do utilizador">
      <?php else: ?>
        <span class="foto-inicial"><?= htmlspecialchars($inicialUtilizador) ?></span>
      <?php endif; ?>
    </a>
    <div class="dados-utilizador">
      <strong><?= htmlspecialchars($nomeUtilizador) ?></strong>
      <?php if ($perfilUtilizador): ?><small><?= htmlspecialchars($perfilUtilizador) ?></small><?php endif; ?>
    </div>
    <button type="button" class="btn-tema" id="btnTema" title="Alterar modo de apresentação">☾ Escuro</button>
    <a class="btn-sair" href="<?= htmlspecialchars(app_url('logout.php')) ?>">Sair</a>
  </div>
</header>
<?php require __DIR__ . '/sidebar.php'; ?>
<div class="app-shell">
<main class="app-content">
