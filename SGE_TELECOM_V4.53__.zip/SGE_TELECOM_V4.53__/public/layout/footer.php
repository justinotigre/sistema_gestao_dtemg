</main>
<footer class="app-footer">
  <span>SGE TELECOM</span>
  <span>V4.46 · <?= date('Y') ?></span>
</footer>
<link rel="stylesheet" href="<?= htmlspecialchars(app_url('assets/css/visual_final.css?v=4.47.0')) ?>">
</div>
</div>
<script>
(function(){const root=document.documentElement,btn=document.getElementById('btnTema'),storageKey='se_modo';function aplicar(modo){const escuro=modo==='escuro';root.classList.toggle('modo-escuro',escuro);if(btn){btn.textContent=escuro?'☀ Claro':'☾ Escuro';btn.setAttribute('aria-label',escuro?'Ativar modo claro':'Ativar modo escuro');}}let inicial=root.classList.contains('modo-escuro')?'escuro':(localStorage.getItem(storageKey)||'claro');aplicar(inicial);if(btn){btn.addEventListener('click',function(){const novo=root.classList.contains('modo-escuro')?'claro':'escuro';aplicar(novo);localStorage.setItem(storageKey,novo);const fd=new FormData();fd.append('csrf_token','<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>');fd.append('tema',novo.toUpperCase());fetch('<?=htmlspecialchars(app_url('tema.php'))?>',{method:'POST',body:fd,credentials:'same-origin'}).catch(function(){});});}})();

(function(){
 document.querySelectorAll('input[type="password"]').forEach(function(input){
   if(input.closest('.password-field-wrap') || input.id==='password') return;
   var wrap=document.createElement('div'); wrap.className='password-field-wrap';
   input.parentNode.insertBefore(wrap,input); wrap.appendChild(input);
   var btn=document.createElement('button'); btn.type='button'; btn.className='password-field-toggle'; btn.innerHTML='<span aria-hidden="true">◉</span>';
   btn.setAttribute('aria-label','Mostrar palavra-passe'); btn.title='Mostrar palavra-passe';
   btn.addEventListener('click',function(){var show=input.type==='password';input.type=show?'text':'password';btn.innerHTML=show?'◎':'◉';btn.setAttribute('aria-label',show?'Ocultar palavra-passe':'Mostrar palavra-passe');btn.title=show?'Ocultar palavra-passe':'Mostrar palavra-passe';});
   wrap.appendChild(btn);
 });
})();
</script>
<script>
(function(){
 const btn=document.getElementById('btnMenuLateral');if(!btn)return;
 const key='sge_menu_recolhido';const desktop=()=>matchMedia('(min-width: 761px)').matches;
 function setState(closed){document.body.classList.toggle('menu-recolhido',closed);btn.setAttribute('aria-expanded',String(!closed));btn.setAttribute('aria-label',closed?'Expandir menu':'Recolher menu');btn.title=closed?'Expandir menu':'Recolher menu';}
 try{setState(localStorage.getItem(key)==='1' && desktop());}catch(e){}
 btn.addEventListener('click',()=>{const closed=!document.body.classList.contains('menu-recolhido');setState(closed);try{localStorage.setItem(key,closed?'1':'0');}catch(e){}});
 window.addEventListener('resize',()=>{if(!desktop())setState(false)});
})();
</script>
</body>
</html>
