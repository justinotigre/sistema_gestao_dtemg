<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/historico.php';
require_login(); require_permission('ESPECIALISTAS_EDITAR');


$pdo = db();

$id = (int)($_GET['id'] ?? 0);
$returnTo = safe_return_url($_POST['return_to'] ?? $_GET['return_to'] ?? null, 'especialistas.php');

if (!$id) {
    header('Location: especialistas.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Carregar especialista
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        e.id_especialista,
        e.id_ramo,
        e.tipo_especialista,
        e.id_quadro,
        e.id_categoria_civil,
        e.id_patente,
        e.estado,
        e.observacoes,

        dp.nome_completo,
        dp.data_nascimento,
        dp.id_sexo,
        dp.id_pais_nascimento,
        dp.id_provincia_nascimento,
        dp.id_municipio_nascimento,
        dp.id_pais_nacionalidade,
        dp.id_estado_civil,
        dp.id_grupo_sanguineo,
        dp.peso_kg,
        dp.numero_bi,
        dp.data_emissao_bi,
        dp.data_validade_bi,
        dp.local_emissao_bi,
        dp.telefone,
        dp.telefone_alternativo,
        dp.email,

        dr.id_provincia AS id_provincia_residencia,
        dr.id_municipio AS id_municipio_residencia,
        dr.bairro, dr.rua, dr.casa, dr.ponto_referencia,

        ds.nip,
        ds.no_civil,
        ds.numero_processo,
        ds.data_incorporacao,
        ds.local_incorporacao,
        ds.local_servico,
        ds.brigada,
        ds.batalhao,
        ds.pelotao,
        ds.seccao,
        ds.data_promocao,
        ds.id_funcao,
        ds.id_unidade,
        ds.id_departamento,
        ds.id_situacao_servico,
        ds.id_regiao,
        ds.data_inicio_funcao,
        ds.data_fim_funcao,
        ds.observacoes AS observacoes_servico,
        db.id_banco, db.numero_conta, db.iban, db.numero_agente

    FROM especialistas e
    INNER JOIN dados_pessoais dp
        ON dp.id_especialista = e.id_especialista
    INNER JOIN dados_servico ds
        ON ds.id_especialista = e.id_especialista
    LEFT JOIN dados_residencia dr
        ON dr.id_especialista = e.id_especialista
    LEFT JOIN dados_bancarios db
        ON db.id_especialista = e.id_especialista
    WHERE e.id_especialista = ?
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$especialista = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$especialista) {
    die('Especialista não encontrado.');
}

require_specialist_edit_scope($id);

$gruposSanguineos = $pdo->query("SELECT id_grupo_sanguineo,nome FROM grupos_sanguineos WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$provincias = $pdo->query("SELECT id_provincia,nome FROM provincias WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$municipios = $pdo->query("SELECT id_municipio,id_provincia,nome FROM municipios WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$regioes = $pdo->query("SELECT id_regiao,nome,sigla FROM regioes WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);

$vestuarioStmt = $pdo->prepare('SELECT * FROM vestuario WHERE id_especialista = ? LIMIT 1');
$vestuarioStmt->execute([$id]);
$vestuario = $vestuarioStmt->fetch(PDO::FETCH_ASSOC) ?: [];

/*
|--------------------------------------------------------------------------
| Verificar acesso
|--------------------------------------------------------------------------
*/

$paramsScope = [];

if ($_SESSION['user']['nivel'] === 'RAMO') {

    $stmt = $pdo->prepare("
        SELECT 1
        FROM utilizador_ramo
        WHERE id_utilizador = ?
        AND id_ramo = ?
    ");

    $stmt->execute([
        $_SESSION['user']['id'],
        $especialista['id_ramo']
    ]);

    if (!$stmt->fetchColumn()) {
        http_response_code(403);
        die('Acesso não autorizado.');
    }

} elseif ($_SESSION['user']['nivel'] !== 'GLOBAL') {

    $stmt = $pdo->prepare("
        SELECT 1
        FROM utilizador_unidade
        WHERE id_utilizador = ?
        AND id_unidade = ?
    ");

    $stmt->execute([
        $_SESSION['user']['id'],
        $especialista['id_unidade']
    ]);

    if (!$stmt->fetchColumn()) {
        http_response_code(403);
        die('Acesso não autorizado.');
    }
}

/*
|--------------------------------------------------------------------------
| Tabelas auxiliares
|--------------------------------------------------------------------------
*/

$ramos = $pdo->query("
    SELECT id_ramo, nome
    FROM ramo
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll();

$quadros = $pdo->query("
    SELECT id_quadro, nome
    FROM quadros_servico
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll();

$sexos = $pdo->query("
    SELECT id_sexo, nome
    FROM sexos
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll();

$estadosCivis = $pdo->query("
    SELECT id_estado_civil, nome
    FROM estados_civis
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll();

$paises = $pdo->query("SELECT id_pais,nome FROM paises WHERE estado='ATIVO' ORDER BY nome")->fetchAll();
$provincias = $pdo->query("SELECT id_provincia,id_pais,nome FROM provincias WHERE estado='ATIVO' ORDER BY nome")->fetchAll();
$municipios = $pdo->query("SELECT id_municipio,id_provincia,nome FROM municipios WHERE estado='ATIVO' ORDER BY nome")->fetchAll();

$funcoes = $pdo->query("
    SELECT id_funcao, nome
    FROM funcoes
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll();


$unidades = $pdo->query("
    SELECT id_unidade, nome, id_ramo
    FROM unidades
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll();

$departamentos = $pdo->query("
    SELECT id_departamento, nome, id_unidade
    FROM departamentos
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll();

$situacoes = $pdo->query("
    SELECT id_situacao_servico, nome, grupo
    FROM situacoes_servico
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll();
$bancos = $pdo->query("SELECT id_banco,nome,sigla FROM bancos WHERE estado='ATIVO' ORDER BY nome")->fetchAll();

/*
|--------------------------------------------------------------------------
| Processar formulário
|--------------------------------------------------------------------------
*/

$erro = '';
$sucesso = '';

/* Edição por secção: protege os outros grupos contra alterações acidentais. */
$seccoesPermitidas = ['geral','pessoais','bi','contactos','residencia','funcao','bancarios','vestuario','observacoes'];
$seccaoEdicao = (string)($_POST['seccao_edicao'] ?? $_GET['sec'] ?? 'todas');
if (!in_array($seccaoEdicao, array_merge($seccoesPermitidas,['todas']), true)) $seccaoEdicao='todas';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($seccaoEdicao !== 'todas') {
        $gruposCampos = [
            'geral'=>['id_ramo','id_quadro','id_patente','id_categoria_civil'],
            'pessoais'=>['nome_completo','data_nascimento','id_sexo','id_pais_nascimento','id_provincia_nascimento','id_municipio_nascimento','id_pais_nacionalidade','id_estado_civil','id_grupo_sanguineo','peso_kg'],
            'bi'=>['numero_bi','data_emissao_bi','data_validade_bi','local_emissao_bi'],
            'contactos'=>['telefone','telefone_alternativo','email'],
            'residencia'=>['id_provincia_residencia','id_municipio_residencia','bairro','rua','casa','ponto_referencia'],
            'funcao'=>['nip','numero_processo','data_incorporacao','local_incorporacao','local_servico','brigada','batalhao','pelotao','seccao','data_promocao','id_funcao','id_unidade','id_departamento','id_situacao_servico','id_regiao','data_inicio_funcao'],
            'bancarios'=>['id_banco','numero_conta','iban','numero_agente'],
            'vestuario'=>['numero_calca','numero_camisa','numero_sapato','numero_bota','numero_boina','numero_quiko','numero_casaco','outros_vestuario'],
            'observacoes'=>['observacoes','observacoes_servico']
        ];
        foreach ($gruposCampos as $grupo=>$campos) {
            if ($grupo === $seccaoEdicao) continue;
            foreach ($campos as $campo) {
                $origem = $especialista[$campo] ?? ($campo==='outros_vestuario' ? ($vestuario['outros']??'') : ($vestuario[$campo]??''));
                $_POST[$campo] = $origem === null ? '' : (string)$origem;
            }
        }
        if ($seccaoEdicao !== 'geral') $_POST['id_categoria_civil'] = (string)($especialista['id_categoria_civil'] ?? '');
        $_POST['data_fim_funcao'] = (string)($especialista['data_fim_funcao'] ?? '');
        if ($seccaoEdicao !== 'geral') $_POST['estado'] = (string)($especialista['estado'] ?? 'ATIVO');
    }

    try {

        $nome = trim($_POST['nome_completo'] ?? '');
        $nip = trim($_POST['nip'] ?? '');

        if ($nome === '') {
            throw new Exception('O nome completo é obrigatório.');
        }

        $idQuadro=(int)($_POST['id_quadro']??0);
        $categoriaCivil=(int)($_POST['id_categoria_civil']??0);
        $tipoEsp = strtoupper((string)($especialista['tipo_especialista'] ?? 'MILITAR'));
        if ($tipoEsp === 'CIVIL') { $nip = ''; $idQuadro = 0; if($categoriaCivil>0){$c=$pdo->prepare("SELECT 1 FROM categorias_civis WHERE id_categoria_civil=? AND estado='ATIVO'");$c->execute([$categoriaCivil]);if(!$c->fetchColumn())throw new Exception('Categoria inválida.');} } else { $categoriaCivil=0; if ($nip === '') throw new Exception('O NIP é obrigatório para especialistas militares.'); }

        $idRamo = $tipoEsp === 'CIVIL' ? null : (int)($_POST['id_ramo'] ?? 0);
        if ($tipoEsp === 'CIVIL') foreach (['numero_processo','data_incorporacao','local_incorporacao','data_promocao','brigada','batalhao','pelotao','seccao'] as $militar) $_POST[$militar] = '';
        $idPatente = ($tipoEsp === 'CIVIL') ? null : (!empty($_POST['id_patente']) ? (int)$_POST['id_patente'] : null);

        $localServico = strtoupper(trim($_POST['local_servico'] ?? ''));
        if (!in_array($localServico, ['EMG','EXE','FAN','MGA'], true)) throw new Exception('Selecione o Local de Serviço.');
        if (($_SESSION['user']['nivel'] ?? '') === 'RAMO' && $localServico === 'EMG') throw new Exception('Só um administrador geral pode atribuir Local de Serviço EMG.');
        $siglaRamoStmt=$pdo->prepare('SELECT UPPER(sigla) FROM ramo WHERE id_ramo=? LIMIT 1');
        $siglaRamoStmt->execute([$idRamo]);
        $siglaRamo=(string)$siglaRamoStmt->fetchColumn();
        if ($tipoEsp !== 'CIVIL' && $localServico !== 'EMG' && $localServico !== $siglaRamo) throw new Exception('O especialista só pode trabalhar no seu ramo ou no EMG.');
        $idUnidade = !empty($_POST['id_unidade']) ? (int)$_POST['id_unidade'] : null;
        $idRegiao = !empty($_POST['id_regiao']) ? (int)$_POST['id_regiao'] : null;

        /*
        |--------------------------------------------------------------------------
        | Validar acesso ao ramo/unidade
        |--------------------------------------------------------------------------
        */

        if ($_SESSION['user']['nivel'] === 'RAMO') {

            $stmt = $pdo->prepare("
                SELECT 1
                FROM utilizador_ramo
                WHERE id_utilizador = ?
                AND id_ramo = ?
            ");

            $stmt->execute([
                $_SESSION['user']['id'],
                $idRamo
            ]);

            if (!$stmt->fetchColumn()) {
                throw new Exception('Não possui permissão para este ramo.');
            }

        } elseif ($_SESSION['user']['nivel'] === 'REGIAO') {
            if (!$idRegiao) throw new Exception('A região é obrigatória para este utilizador.');
            $stmt=$pdo->prepare('SELECT 1 FROM utilizador_regiao WHERE id_utilizador=? AND id_regiao=?');
            $stmt->execute([$_SESSION['user']['id'],$idRegiao]);
            if (!$stmt->fetchColumn()) throw new Exception('Não possui permissão para esta região.');
        } elseif ($_SESSION['user']['nivel'] === 'UNIDADE') {
            if (!$idUnidade) throw new Exception('A unidade é obrigatória para este utilizador.');
            $stmt=$pdo->prepare('SELECT 1 FROM utilizador_unidade WHERE id_utilizador=? AND id_unidade=?');
            $stmt->execute([$_SESSION['user']['id'],$idUnidade]);
            if (!$stmt->fetchColumn()) throw new Exception('Não possui permissão para esta unidade.');
        }

        /*
        |--------------------------------------------------------------------------
        | Validar patente
        |--------------------------------------------------------------------------
        */

        if ($idPatente) {

            $stmt = $pdo->prepare("
                SELECT 1
                FROM patentes
                WHERE id_patente = ?
                AND id_ramo = ?
                AND estado = 'ATIVO'
            ");

            $stmt->execute([
                $idPatente,
                $idRamo
            ]);

            if (!$stmt->fetchColumn()) {
                throw new Exception('A patente selecionada não pertence ao ramo.');
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Verificar NIP duplicado
        |--------------------------------------------------------------------------
        */

        if($nip!==''){ $stmt=$pdo->prepare("SELECT id_especialista FROM dados_servico WHERE nip=? AND id_especialista<>?");$stmt->execute([$nip,$id]);if($stmt->fetchColumn())throw new Exception('Este NIP já está associado a outro especialista.'); }

        /*
        |--------------------------------------------------------------------------
        | Actualização
        |--------------------------------------------------------------------------
        */

        if (!empty($_POST['id_municipio_nascimento']) && !empty($_POST['id_provincia_nascimento'])) {
            $q=$pdo->prepare('SELECT 1 FROM municipios WHERE id_municipio=? AND id_provincia=? LIMIT 1');$q->execute([(int)$_POST['id_municipio_nascimento'],(int)$_POST['id_provincia_nascimento']]);if(!$q->fetchColumn())throw new Exception('O município de nascimento não pertence à província selecionada.');
        }
        if (!empty($_POST['id_municipio_residencia']) && !empty($_POST['id_provincia_residencia'])) {
            $q=$pdo->prepare('SELECT 1 FROM municipios WHERE id_municipio=? AND id_provincia=? LIMIT 1');$q->execute([(int)$_POST['id_municipio_residencia'],(int)$_POST['id_provincia_residencia']]);if(!$q->fetchColumn())throw new Exception('O município de residência não pertence à província selecionada.');
        }
        $historicoAntes = $especialista;
        $pdo->beginTransaction();

        /*
        | Especialista
        */

        $stmt = $pdo->prepare("
            UPDATE especialistas
            SET
                id_ramo = ?,
                id_quadro = ?,
                id_patente = ?,
                id_categoria_civil = ?,
                estado = ?,
                observacoes = ?
            WHERE id_especialista = ?
        ");

        $stmt->execute([
            $idRamo,
            $idQuadro ?: null,
            $idPatente,
            $categoriaCivil ?: null,
            $_POST['estado'] ?? 'ATIVO',
            trim($_POST['observacoes'] ?? ''),
            $id
        ]);

        /*
        | Dados pessoais
        */

        $stmt = $pdo->prepare("
            UPDATE dados_pessoais
            SET
                nome_completo = ?,
                data_nascimento = ?,
                id_sexo = ?,
                id_pais_nascimento = ?,
                id_provincia_nascimento = ?,
                id_municipio_nascimento = ?,
                id_pais_nacionalidade = ?,
                id_estado_civil = ?,
                id_grupo_sanguineo = ?,
                peso_kg = ?,
                numero_bi = ?,
                data_emissao_bi = ?,
                data_validade_bi = ?,
                local_emissao_bi = ?,
                telefone = ?,
                telefone_alternativo = ?,
                email = ?
            WHERE id_especialista = ?
        ");

        $stmt->execute([
            $nome,
            $_POST['data_nascimento'] ?: null,
            !empty($_POST['id_sexo']) ? (int)$_POST['id_sexo'] : null,
            !empty($_POST['id_pais_nascimento']) ? (int)$_POST['id_pais_nascimento'] : null,
            !empty($_POST['id_provincia_nascimento']) ? (int)$_POST['id_provincia_nascimento'] : null,
            !empty($_POST['id_municipio_nascimento']) ? (int)$_POST['id_municipio_nascimento'] : null,
            !empty($_POST['id_pais_nacionalidade']) ? (int)$_POST['id_pais_nacionalidade'] : null,
            !empty($_POST['id_estado_civil']) ? (int)$_POST['id_estado_civil'] : null,
            !empty($_POST['id_grupo_sanguineo']) ? (int)$_POST['id_grupo_sanguineo'] : null,
            ($_POST['peso_kg'] ?? '') !== '' ? (float)$_POST['peso_kg'] : null,
            trim($_POST['numero_bi'] ?? ''),
            $_POST['data_emissao_bi'] ?: null,
            $_POST['data_validade_bi'] ?: null,
            trim($_POST['local_emissao_bi'] ?? ''),
            trim($_POST['telefone'] ?? ''),
            trim($_POST['telefone_alternativo'] ?? ''),
            trim($_POST['email'] ?? ''),
            $id
        ]);

        /*
        | Dados de serviço
        */

        $stmt = $pdo->prepare("
            UPDATE dados_servico
            SET
                nip = ?,
                no_civil = ?,
                numero_processo = ?,
                data_incorporacao = ?,
                local_incorporacao = ?,
                local_servico = ?,
                brigada = ?,
                batalhao = ?,
                pelotao = ?,
                seccao = ?,
                data_promocao = ?,
                id_funcao = ?,
                id_unidade = ?,
                id_regiao = ?,
                id_departamento = ?,
                id_situacao_servico = ?,
                data_inicio_funcao = ?,
                data_fim_funcao = ?,
                observacoes = ?
            WHERE id_especialista = ?
        ");

        $stmt->execute([
            $nip,
            $tipoEsp === 'CIVIL' ? (trim((string)($_POST['no_civil'] ?? '')) ?: null) : null,
            trim($_POST['numero_processo'] ?? ''),
            $_POST['data_incorporacao'] ?: null,
            trim($_POST['local_incorporacao'] ?? '') ?: null,
            $localServico,
            trim($_POST['brigada'] ?? '') ?: null,
            trim($_POST['batalhao'] ?? '') ?: null,
            trim($_POST['pelotao'] ?? '') ?: null,
            trim($_POST['seccao'] ?? '') ?: null,
            $_POST['data_promocao'] ?: null,
            !empty($_POST['id_funcao']) ? (int)$_POST['id_funcao'] : null,
            $idUnidade,
            $idRegiao,
            !empty($_POST['id_departamento']) ? (int)$_POST['id_departamento'] : null,
            !empty($_POST['id_situacao_servico'])
                ? (int)$_POST['id_situacao_servico']
                : null,
            $_POST['data_inicio_funcao'] ?: null,
            $_POST['data_fim_funcao'] ?: null,
            trim($_POST['observacoes_servico'] ?? ''),
            $id
        ]);

        
        $pdo->prepare("INSERT INTO dados_residencia (id_especialista,id_provincia,id_municipio,bairro,rua,casa,ponto_referencia) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE id_provincia=VALUES(id_provincia),id_municipio=VALUES(id_municipio),bairro=VALUES(bairro),rua=VALUES(rua),casa=VALUES(casa),ponto_referencia=VALUES(ponto_referencia)")->execute([
            $id,
            !empty($_POST['id_provincia_residencia']) ? (int)$_POST['id_provincia_residencia'] : null,
            !empty($_POST['id_municipio_residencia']) ? (int)$_POST['id_municipio_residencia'] : null,
            trim($_POST['bairro'] ?? '') ?: null, trim($_POST['rua'] ?? '') ?: null, trim($_POST['casa'] ?? '') ?: null, trim($_POST['ponto_referencia'] ?? '') ?: null
        ]);

        // Atualizar vestuário do especialista.
        $vestStmt = $pdo->prepare("
            INSERT INTO vestuario (id_especialista,numero_calca,numero_camisa,numero_sapato,numero_bota,numero_boina,numero_quiko,numero_casaco,outros)
            VALUES (?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE
                numero_calca=VALUES(numero_calca), numero_camisa=VALUES(numero_camisa), numero_sapato=VALUES(numero_sapato),
                numero_bota=VALUES(numero_bota), numero_boina=VALUES(numero_boina), numero_quiko=VALUES(numero_quiko),
                numero_casaco=VALUES(numero_casaco), outros=VALUES(outros)
        ");
        $vestStmt->execute([
            $id, trim($_POST['numero_calca'] ?? '') ?: null, trim($_POST['numero_camisa'] ?? '') ?: null,
            trim($_POST['numero_sapato'] ?? '') ?: null, trim($_POST['numero_bota'] ?? '') ?: null,
            trim($_POST['numero_boina'] ?? '') ?: null, trim($_POST['numero_quiko'] ?? '') ?: null,
            trim($_POST['numero_casaco'] ?? '') ?: null, trim($_POST['outros_vestuario'] ?? '') ?: null
        ]);

        $pdo->prepare("INSERT INTO dados_bancarios (id_especialista,id_banco,numero_conta,iban,numero_agente) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE id_banco=VALUES(id_banco),numero_conta=VALUES(numero_conta),iban=VALUES(iban),numero_agente=VALUES(numero_agente)")
            ->execute([$id,!empty($_POST['id_banco'])?(int)$_POST['id_banco']:null,trim($_POST['numero_conta']??'')?:null,trim($_POST['iban']??'')?:null,trim($_POST['numero_agente']??'')?:null]);

/* A alteração e o histórico são confirmados na mesma transação. */

        if ((string)($historicoAntes['nome_completo']??'') !== $nome) registar_historico_especialista($pdo,$id,'ALTERACAO_DADOS','nome_completo',(string)($historicoAntes['nome_completo']??''),$nome);
        if ((string)($historicoAntes['numero_bi']??'') !== trim($_POST['numero_bi']??'')) registar_historico_especialista($pdo,$id,'ALTERACAO_DADOS','numero_bi',(string)($historicoAntes['numero_bi']??''),trim($_POST['numero_bi']??''));
        if ((int)($historicoAntes['id_patente']??0) !== (int)$idPatente) registar_historico_especialista($pdo,$id,'PROMOCAO','patente',(string)($historicoAntes['id_patente']??''),(string)($idPatente??''));
        if ((int)($historicoAntes['id_funcao']??0) !== (int)($_POST['id_funcao']??0)) registar_historico_especialista($pdo,$id,'ALTERACAO_FUNCAO','funcao',(string)($historicoAntes['id_funcao']??''),(string)($_POST['id_funcao']??''));
        if ((string)($historicoAntes['local_servico']??'') !== $localServico) registar_historico_especialista($pdo,$id,'MOVIMENTACAO_UNIDADE','local_servico',(string)($historicoAntes['local_servico']??''),$localServico);
        if ((int)($historicoAntes['id_unidade']??0) !== (int)$idUnidade) registar_historico_especialista($pdo,$id,'MOVIMENTACAO_UNIDADE','unidade',(string)($historicoAntes['id_unidade']??''),(string)($idUnidade??''));
        if ((int)($historicoAntes['id_ramo']??0) !== (int)$idRamo) registar_historico_especialista($pdo,$id,'ALTERACAO_RAMO','ramo',(string)($historicoAntes['id_ramo']??''),(string)$idRamo);
        if ((int)($historicoAntes['id_regiao']??0) !== (int)$idRegiao) registar_historico_especialista($pdo,$id,'ALTERACAO_REGIAO','regiao',(string)($historicoAntes['id_regiao']??''),(string)($idRegiao??''));
        registar_auditoria($pdo,'ESPECIALISTAS','ALTERACAO','ESPECIALISTAS','especialistas',$id,'Ficha do especialista atualizada.');
        $pdo->commit();

        header('Location: ' . $returnTo . (str_contains($returnTo,'?')?'&':'?') . 'atualizado=1');
        exit;

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $erro = $e->getMessage();
    }
}

/*
|--------------------------------------------------------------------------
| Valores do formulário
|--------------------------------------------------------------------------
*/

$v = function ($campo) use ($especialista) {
    return htmlspecialchars(
        $_POST[$campo] ?? $especialista[$campo] ?? '',
        ENT_QUOTES,
        'UTF-8'
    );
};

function selected($valor, $atual)
{
    return ((string)$valor === (string)$atual) ? 'selected' : '';
}
$page_title = "Especialista Editar";
require __DIR__ . '/../../layout/header.php';
?>

<div class="module-page module-especialista-editar">
<style>


.module-page.module-especialista-editar .form-section {
    margin-bottom:25px;
    padding:20px;
    background:#fff;
    border-radius:10px;
}

.module-page.module-especialista-editar .form-grid {
    display:grid;
    grid-template-columns:minmax(0,1.15fr) minmax(0,1fr) minmax(0,1fr);
    gap:15px;
}

.module-page.module-especialista-editar .campo-opcional{font-weight:500;opacity:.65;font-size:12px}.module-page.module-especialista-editar .form-group[hidden]{display:none!important}
.module-page.module-especialista-editar .form-group {
    display:flex;
    flex-direction:column;
    gap:6px;
    min-width:0;
}

.module-page.module-especialista-editar .form-group.full {
    grid-column:1/-1;
}

.module-page.module-especialista-editar .form-group label {
    font-weight:600;
}

.module-page.module-especialista-editar .form-group input, .module-page.module-especialista-editar .form-group select, .module-page.module-especialista-editar .form-group textarea {
    width:100%;
    box-sizing:border-box;
    min-height:42px;
    padding:10px;
    border:1px solid #ccc;
    border-radius:6px;
}

.module-page.module-especialista-editar .form-group textarea {
    min-height:90px;
}

.module-page.module-especialista-editar .acoes {
    display:flex;
    gap:10px;
    margin-top:20px;
}

@media(max-width:900px){
    .module-page.module-especialista-editar .form-grid {
        grid-template-columns:1fr;
    }
}


</style>
<?php if ($seccaoEdicao !== 'todas'): ?>
<style>
.module-especialista-editar .form-section{display:none!important}
.module-especialista-editar .form-section[data-edicao="<?=htmlspecialchars($seccaoEdicao,ENT_QUOTES)?>"]{display:block!important}
</style>
<?php endif; ?>
<main>

<h1>Editar Especialista</h1>

<p>
    <a class="btn btn-secondary" href="<?=htmlspecialchars($returnTo)?>">← Voltar</a>
</p>

<?php if ($erro): ?>

<div class="erro">
    <?=htmlspecialchars($erro)?>
</div>

<?php endif; ?>


<script>
document.addEventListener('DOMContentLoaded',function(){
 const form=document.querySelector('.module-especialista-editar form[method="post"]');
 const ativo=<?=json_encode($seccaoEdicao)?>;
 if(!form || ativo==='todas') return;
 form.querySelectorAll('.form-section').forEach(section=>{
   if(section.dataset.edicao!==ativo) section.querySelectorAll('input,select,textarea').forEach(field=>field.disabled=true);
 });
});
</script>
<form method="post">
<input type="hidden" name="seccao_edicao" value="<?=htmlspecialchars($seccaoEdicao,ENT_QUOTES)?>">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="return_to" value="<?=htmlspecialchars($returnTo,ENT_QUOTES)?>">


<!-- ========================================================= -->
<!-- DADOS DO ESPECIALISTA -->
<!-- ========================================================= -->

<section class="form-section" data-edicao="geral">

<h2>Dados do Especialista</h2>

<div class="form-grid">
<?php if (strtoupper((string)($especialista['tipo_especialista'] ?? 'MILITAR')) === 'CIVIL'): ?>
<div class="form-group"><label>Categoria</label><select name="id_categoria_civil"><option value="">Selecionar</option>
<?php foreach ($pdo->query("SELECT id_categoria_civil,nome FROM categorias_civis WHERE estado='ATIVO' ORDER BY ordem,nome")->fetchAll(PDO::FETCH_ASSOC) as $cat): ?>
<option value="<?= (int)$cat['id_categoria_civil'] ?>" <?= selected($cat['id_categoria_civil'],$_POST['id_categoria_civil']??$especialista['id_categoria_civil']) ?>><?= htmlspecialchars($cat['nome'],ENT_QUOTES,'UTF-8') ?></option>
<?php endforeach; ?></select></div>
<?php endif; ?>

<div class="form-group">

<label>Ramo *</label>

<select name="id_ramo" id="id_ramo" <?= strtoupper((string)($especialista['tipo_especialista'] ?? 'MILITAR')) === 'CIVIL' ? '' : 'required' ?>>

<option value="">Seleccione</option>

<?php foreach ($ramos as $r): ?>

<option
    value="<?=$r['id_ramo']?>"
    <?=selected(
        $r['id_ramo'],
        $_POST['id_ramo'] ?? $especialista['id_ramo']
    )?>
>
    <?=htmlspecialchars($r['nome'])?>
</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">

<label>Forma de Prestação de Serviço (FPS)</label>

<select name="id_quadro">

<option value="">Seleccione</option>

<?php foreach ($quadros as $q): ?>

<option
    value="<?=$q['id_quadro']?>"
    data-quadro-nome="<?=htmlspecialchars($q['nome'],ENT_QUOTES,'UTF-8')?>"
    <?=selected(
        $q['id_quadro'],
        $_POST['id_quadro'] ?? $especialista['id_quadro']
    )?>
>
    <?=htmlspecialchars($q['nome'])?>
</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group" id="campo-patente-editar" style="<?= strtoupper((string)($especialista['tipo_especialista'] ?? 'MILITAR')) === 'CIVIL' ? 'display:none' : '' ?>">

<label>Patente</label>

<select name="id_patente" id="id_patente">

<option value="">Seleccione</option>

</select>

</div>


<input type="hidden" name="estado" value="<?=htmlspecialchars((string)$v('estado'), ENT_QUOTES, 'UTF-8')?>">



</div>

</section>


<!-- ========================================================= -->
<!-- DADOS PESSOAIS -->
<!-- ========================================================= -->

<section class="form-section" data-edicao="pessoais">

<h2>Dados Pessoais</h2>

<div class="form-grid">

<div class="form-group full">

<label>Nome completo *</label>

<input
    type="text"
    name="nome_completo"
    value="<?=$v('nome_completo')?>"
    required
>

</div>


<div class="form-group">

<label>Data de nascimento</label>

<input
    type="date"
    name="data_nascimento"
    value="<?=$v('data_nascimento')?>"
>

</div>


<div class="form-group">

<label>Sexo</label>

<select name="id_sexo">

<option value="">Seleccione</option>

<?php foreach ($sexos as $s): ?>

<option
    value="<?=$s['id_sexo']?>"
    <?=selected(
        $s['id_sexo'],
        $_POST['id_sexo'] ?? $especialista['id_sexo']
    )?>
>
    <?=htmlspecialchars($s['nome'])?>
</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">

<label>Estado civil</label>

<select name="id_estado_civil">

<option value="">Seleccione</option>

<?php foreach ($estadosCivis as $e): ?>

<option
    value="<?=$e['id_estado_civil']?>"
    <?=selected(
        $e['id_estado_civil'],
        $_POST['id_estado_civil'] ?? $especialista['id_estado_civil']
    )?>
>
    <?=htmlspecialchars($e['nome'])?>
</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">
<label>Grupo sanguíneo</label>
<select name="id_grupo_sanguineo">
<option value="">Seleccione</option>
<?php foreach ($gruposSanguineos as $gs): ?>
<option value="<?= (int)$gs['id_grupo_sanguineo'] ?>" <?= selected($gs['id_grupo_sanguineo'],$_POST['id_grupo_sanguineo']??$especialista['id_grupo_sanguineo']) ?>><?= htmlspecialchars($gs['nome']) ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="form-group">
<label>Peso (kg)</label>
<input type="number" name="peso_kg" min="1" max="500" step="0.01" value="<?=htmlspecialchars($_POST['peso_kg']??$especialista['peso_kg']??'')?>">
</div>

<div class="form-group">

<label>Nacionalidade</label>

<?php $paisAngola = $pdo->query("SELECT id_pais FROM paises WHERE codigo='AO' LIMIT 1")->fetchColumn(); ?>
<select name="id_pais_nacionalidade"><option value="<?= (int)$paisAngola ?>" <?= selected($paisAngola, $_POST['id_pais_nacionalidade'] ?? $especialista['id_pais_nacionalidade']) ?>>Angolana</option></select>

</div>


<div class="form-group">

<label>País de nascimento</label>

<select name="id_pais_nascimento">

<option value="">Seleccione</option>

<?php foreach ($paises as $p): ?>

<option
    value="<?=$p['id_pais']?>"
    <?=selected(
        $p['id_pais'],
        $_POST['id_pais_nascimento'] ?? $especialista['id_pais_nascimento']
    )?>
>
    <?=htmlspecialchars($p['nome'])?>
</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">

<label>Província de nascimento</label>

<select name="id_provincia_nascimento" id="id_provincia_nascimento"><option value="">Seleccione</option><?php foreach($provincias as $p): ?><option value="<?=$p['id_provincia']?>" data-pais="<?=$p['id_pais']?>" <?=selected($p['id_provincia'],$_POST['id_provincia_nascimento']??$especialista['id_provincia_nascimento'])?>><?=htmlspecialchars($p['nome'])?></option><?php endforeach; ?></select>

</div>


<div class="form-group">

<label>Município de nascimento</label>

<select name="id_municipio_nascimento" id="id_municipio_nascimento"><option value="">Seleccione</option><?php foreach($municipios as $m): ?><option value="<?=$m['id_municipio']?>" data-provincia="<?=$m['id_provincia']?>" <?=selected($m['id_municipio'],$_POST['id_municipio_nascimento']??$especialista['id_municipio_nascimento'])?>><?=htmlspecialchars($m['nome'])?></option><?php endforeach; ?></select>

</div>

</div>

</section>


<!-- ========================================================= -->
<!-- BILHETE DE IDENTIDADE -->
<!-- ========================================================= -->

<section class="form-section" data-edicao="bi">

<h2>Bilhete de Identidade</h2>

<div class="form-grid">

<div class="form-group">

<label>Número do BI</label>

<input
    type="text"
    name="numero_bi"
    value="<?=$v('numero_bi')?>"
>

</div>


<div class="form-group">

<label>Data de emissão</label>

<input
    type="date"
    name="data_emissao_bi"
    value="<?=$v('data_emissao_bi')?>"
>

</div>


<div class="form-group">

<label>Data de validade</label>

<input
    type="date"
    name="data_validade_bi"
    value="<?=$v('data_validade_bi')?>"
>

</div>


<div class="form-group">

<label>Local de emissão</label>

<select name="local_emissao_bi">
<option value="">Seleccione</option>
<?php foreach($provincias as $p): ?>
<option value="<?=htmlspecialchars($p['nome'])?>" <?=selected($p['nome'],$_POST['local_emissao_bi']??$especialista['local_emissao_bi'])?>><?=htmlspecialchars($p['nome'])?></option>
<?php endforeach; ?>
</select>

</div>

</div>

</section>


<!-- ========================================================= -->
<!-- CONTACTOS -->
<!-- ========================================================= -->

<section class="form-section" data-edicao="contactos">

<h2>Contactos</h2>

<div class="form-grid">

<div class="form-group">

<label>Telefone</label>

<input
    type="text"
    name="telefone"
    value="<?=$v('telefone')?>"
>

</div>


<div class="form-group">

<label>Número alternativo</label>

<input
    type="text"
    name="telefone_alternativo"
    value="<?=$v('telefone_alternativo')?>"
>

</div>


<div class="form-group">

<label>E-mail</label>

<input
    type="email"
    name="email"
    value="<?=$v('email')?>"
>

</div>




</div>

</section>


<!-- ========================================================= -->
<!-- RESIDÊNCIA -->
<!-- ========================================================= -->
<section class="form-section" data-edicao="residencia">
<h2>Dados de Residência</h2>
<p class="form-help">Todos estes campos são opcionais.</p>
<div class="form-grid">
<div class="form-group"><label>Província</label><select name="id_provincia_residencia" id="id_provincia_residencia"><option value="">Selecionar</option><?php foreach($provincias as $pv): ?><option value="<?=$pv['id_provincia']?>" <?=((int)($especialista['id_provincia_residencia']??0)==(int)$pv['id_provincia'])?'selected':''?>><?=htmlspecialchars($pv['nome'])?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Município</label><select name="id_municipio_residencia" id="id_municipio_residencia"><option value="">Selecionar</option><?php foreach($municipios as $mv): ?><option value="<?=$mv['id_municipio']?>" data-provincia="<?=$mv['id_provincia']?>" <?=((int)($especialista['id_municipio_residencia']??0)==(int)$mv['id_municipio'])?'selected':''?>><?=htmlspecialchars($mv['nome'])?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Bairro</label><input name="bairro" value="<?=htmlspecialchars($especialista['bairro']??'')?>"></div>
<div class="form-group"><label>Rua</label><input name="rua" value="<?=htmlspecialchars($especialista['rua']??'')?>"></div>
<div class="form-group"><label>Casa</label><input name="casa" value="<?=htmlspecialchars($especialista['casa']??'')?>"></div>
<div class="form-group"><label>Ponto de referência</label><input name="ponto_referencia" value="<?=htmlspecialchars($especialista['ponto_referencia']??'')?>"></div>
</div></section>

<!-- ========================================================= -->
<!-- DADOS DE SERVIÇO -->
<!-- ========================================================= -->

<style>.form-grid{align-items:start;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 22px}.form-group{min-width:0;display:flex;flex-direction:column;gap:7px}.form-group input,.form-group select{width:100%;min-width:0;box-sizing:border-box;min-height:43px}.form-group label{min-height:20px;line-height:1.35}.form-section{margin-bottom:22px}@media(max-width:700px){.form-grid{grid-template-columns:1fr}}<?php if (strtoupper((string)($especialista['tipo_especialista'] ?? 'MILITAR')) === 'CIVIL'): ?>
.form-group:has([name="id_ramo"]), .form-group:has([name="id_quadro"]), .form-group:has([name="id_patente"]),
.form-group:has([name="nip"]), .form-group:has([name="numero_processo"]),
.form-group:has([name="data_incorporacao"]), .form-group:has([name="local_incorporacao"]),
.form-group:has([name="data_promocao"]), .form-group:has([name="brigada"]),
.form-group:has([name="batalhao"]), .form-group:has([name="pelotao"]), .form-group:has([name="seccao"]) {display:none!important}
<?php endif; ?>
</style>
<section class="form-section" data-edicao="funcao">

<h2>Função</h2>

<div class="form-grid">

<?php if (strtoupper((string)($especialista['tipo_especialista']??''))==='CIVIL'): ?>
<div class="form-group"><label>NO</label><input name="no_civil" maxlength="50" value="<?=$v('no_civil')?>"></div>
<?php endif; ?>
<div class="form-group" id="campo-nip">

<label>NIP <span id="nip-required-mark">*</span></label>

<input
    type="text"
    name="nip"
    value="<?=$v('nip')?>"
>

</div><div class="form-group">

<label>Número de processo</label>

<input
    type="text"
    name="numero_processo"
    value="<?=$v('numero_processo')?>"
>

</div>




<div class="form-group">

<label>Data de incorporação</label>

<input
    type="date"
    name="data_incorporacao"
    value="<?=$v('data_incorporacao')?>"
>

</div>


<div class="form-group">
<label>Local de incorporação</label>
<input type="text" name="local_incorporacao" maxlength="200" value="<?=$v('local_incorporacao')?>">
</div>

<div class="form-group">
<label>Local de Serviço</label>
<select name="local_servico" required>
<option value="">Seleccione</option>
<?php foreach (['EMG'=>'EMG','EXE'=>'EXE','FAN'=>'FAN','MGA'=>'MGA'] as $sigla=>$nome): ?>
<option value="<?=$sigla?>" <?=strtoupper((string)($especialista['local_servico']??''))===$sigla?'selected':''?>><?=$nome?></option>
<?php endforeach; ?>
</select>
<?php if (strtoupper((string)($especialista['tipo_especialista']??'MILITAR'))!=='CIVIL'): ?><small>O especialista pode servir no seu ramo ou no EMG.</small><?php endif; ?>
</div>

<?php foreach (['brigada'=>'Brigada','batalhao'=>'Batalhão','pelotao'=>'Pelotão','seccao'=>'Secção'] as $campo=>$rotulo): ?>
<div class="form-group"><label><?=$rotulo?></label><input type="text" name="<?=$campo?>" maxlength="150" value="<?=htmlspecialchars((string)($especialista[$campo]??''),ENT_QUOTES,'UTF-8')?>"></div>
<?php endforeach; ?>

<div class="form-group">

<label>Data de promoção</label>

<input
    type="date"
    name="data_promocao"
    value="<?=$v('data_promocao')?>"
>

</div>


<div class="form-group">
<label>Região</label>
<select name="id_regiao"><option value="">Selecionar</option><?php foreach($regioes as $rg): ?><option value="<?=$rg['id_regiao']?>" <?=((int)($especialista['id_regiao']??0)==(int)$rg['id_regiao'])?'selected':''?>><?=htmlspecialchars($rg['nome'])?></option><?php endforeach; ?></select>
</div>

<div class="form-group">

<label>Função</label>

<select name="id_funcao">

<option value="">Seleccione</option>

<?php foreach ($funcoes as $f): ?>

<option
    value="<?=$f['id_funcao']?>"
    <?=selected(
        $f['id_funcao'],
        $_POST['id_funcao'] ?? $especialista['id_funcao']
    )?>
>
    <?=htmlspecialchars($f['nome'])?>
</option>

<?php endforeach; ?>

</select>

</div>




<div class="form-group">

<label>Unidade</label>

<select name="id_unidade" id="id_unidade">

<option value="">Seleccione</option>

<?php foreach ($unidades as $u): ?>

<option
    value="<?=$u['id_unidade']?>"
    data-ramo="<?=$u['id_ramo']?>"
    <?=selected(
        $u['id_unidade'],
        $_POST['id_unidade'] ?? $especialista['id_unidade']
    )?>
>
    <?=htmlspecialchars($u['nome'])?>
</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">

<label>Repartição</label>

<select name="id_departamento" id="id_departamento">

<option value="">Seleccione</option>

<?php foreach ($departamentos as $d): ?>

<option
    value="<?=$d['id_departamento']?>"
    data-unidade="<?=$d['id_unidade']?>"
    <?=selected(
        $d['id_departamento'],
        $_POST['id_departamento'] ?? $especialista['id_departamento']
    )?>
>
    <?=htmlspecialchars($d['nome'])?>
</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">

<label>Estado</label>

<select name="id_situacao_servico">

<option value="">Seleccione</option>

<optgroup label="Ativo">
<?php foreach ($situacoes as $s): if($s['grupo']!=='ATIVO') continue; ?>
<option value="<?=$s['id_situacao_servico']?>" <?=selected($s['id_situacao_servico'],$_POST['id_situacao_servico'] ?? $especialista['id_situacao_servico'])?>><?=htmlspecialchars($s['nome'])?></option>
<?php endforeach; ?>
</optgroup>
<optgroup label="Inativo">
<?php foreach ($situacoes as $s): if($s['grupo']!=='INATIVO') continue; ?>
<option value="<?=$s['id_situacao_servico']?>" <?=selected($s['id_situacao_servico'],$_POST['id_situacao_servico'] ?? $especialista['id_situacao_servico'])?>><?=htmlspecialchars($s['nome'])?></option>
<?php endforeach; ?>
</optgroup>

</select>

</div>


<div class="form-group">

<label>Início da função</label>

<input
    type="date"
    name="data_inicio_funcao"
    value="<?=$v('data_inicio_funcao')?>"
>

</div>





<div class="form-group full">

<label>Observações de serviço</label>

<textarea name="observacoes_servico"><?= $v('observacoes_servico') ?></textarea>

</div>

</div>

</section>


<section class="form-section" data-edicao="bancarios">
<h2>Dados bancários</h2><p class="form-help">Informação bancária do especialista. O número de conta é opcional.</p>
<div class="form-grid">
<div class="form-group"><label>Banco</label><select name="id_banco"><option value="">Seleccione</option><?php foreach($bancos as $b): ?><option value="<?=$b['id_banco']?>" <?=selected($b['id_banco'],$_POST['id_banco']??$especialista['id_banco'])?>><?=htmlspecialchars($b['nome'])?><?= $b['sigla']?' ('.htmlspecialchars($b['sigla']).')':'' ?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Número de conta <span class="campo-opcional">(opcional)</span></label><input type="text" name="numero_conta" inputmode="numeric" autocomplete="off" placeholder="Número de conta bancária" value="<?=htmlspecialchars($_POST['numero_conta']??$especialista['numero_conta']??'')?>"></div>
<div class="form-group"><label>IBAN</label><input type="text" name="iban" maxlength="34" inputmode="text" autocomplete="off" placeholder="AO06 0000 0000 0000 0000 0000 0" value="<?=htmlspecialchars($_POST['iban']??$especialista['iban']??'')?>"></div>
<div class="form-group"><label>Nº de agente</label><input type="text" name="numero_agente" value="<?=htmlspecialchars($_POST['numero_agente']??$especialista['numero_agente']??'')?>"></div>
</div></section>

<section class="form-section" data-edicao="vestuario">
<h2>Vestuário</h2>
<div class="form-grid">
<div class="form-group"><label>Número da calça</label><input type="text" name="numero_calca" value="<?=htmlspecialchars($_POST['numero_calca']??$vestuario['numero_calca']??'')?>"></div>
<div class="form-group"><label>Número da camisa</label><input type="text" name="numero_camisa" value="<?=htmlspecialchars($_POST['numero_camisa']??$vestuario['numero_camisa']??'')?>"></div>
<div class="form-group"><label>Número do sapato</label><input type="text" name="numero_sapato" value="<?=htmlspecialchars($_POST['numero_sapato']??$vestuario['numero_sapato']??'')?>"></div>
<div class="form-group"><label>Número da bota</label><input type="text" name="numero_bota" value="<?=htmlspecialchars($_POST['numero_bota']??$vestuario['numero_bota']??'')?>"></div>
<div class="form-group"><label>Número da boina</label><input type="text" name="numero_boina" value="<?=htmlspecialchars($_POST['numero_boina']??$vestuario['numero_boina']??'')?>"></div>
<div class="form-group"><label>Número do Quiko</label><input type="text" name="numero_quiko" value="<?=htmlspecialchars($_POST['numero_quiko']??$vestuario['numero_quiko']??'')?>"></div>
<div class="form-group"><label>Número do casaco</label><input type="text" name="numero_casaco" value="<?=htmlspecialchars($_POST['numero_casaco']??$vestuario['numero_casaco']??'')?>"></div>
<div class="form-group"><label>Outros</label><input type="text" name="outros_vestuario" value="<?=htmlspecialchars($_POST['outros_vestuario']??$vestuario['outros']??'')?>"></div>
</div></section>

<section class="form-section" data-edicao="observacoes">
<h2>Observações</h2>
<div class="form-grid">
<div class="form-group full">
<textarea name="observacoes" rows="4" placeholder="Observações gerais sobre o especialista..."><?= $v('observacoes') ?></textarea>
</div>
</div>
</section>

<div class="acoes">

<button type="submit">
    Guardar alterações
</button>

<a href="<?=htmlspecialchars($returnTo)?>" class="btn btn-secondary">
    Voltar
</a>

</div>

</form>

</main>


<script>

async function carregarPatentes(idRamo, selecionada = '') {

    const select = document.getElementById('id_patente');

    select.innerHTML = '<option value="">A carregar...</option>';

    if (!idRamo) {
        select.innerHTML = '<option value="">Seleccione</option>';
        return;
    }

    try {

        const resposta = await fetch(
            '../configuracoes/api_patentes.php?id_ramo=' + encodeURIComponent(idRamo)
        );

        const dados = await resposta.json();

        select.innerHTML = '<option value="">Seleccione</option>';

        dados.forEach(function(patente) {

            const option = document.createElement('option');

            option.value = patente.id_patente;

            option.textContent =
                patente.sigla
                ? patente.sigla + ' - ' + patente.nome
                : patente.nome;

            if (String(patente.id_patente) === String(selecionada)) {
                option.selected = true;
            }

            select.appendChild(option);
        });

    } catch (erro) {

        select.innerHTML =
            '<option value="">Erro ao carregar patentes</option>';

    }
}


const ramo = document.getElementById('id_ramo');

const patenteAtual =
    <?=json_encode(
        $_POST['id_patente']
        ?? $especialista['id_patente']
    )?>;

carregarPatentes(
    ramo.value,
    patenteAtual
);


ramo.addEventListener('change', function() {

    carregarPatentes(this.value, '');

    /*
    | Filtrar unidades pelo ramo
    */

    const unidade = document.getElementById('id_unidade');

    Array.from(unidade.options).forEach(function(option) {

        if (!option.value) return;

        option.hidden =
            option.dataset.ramo !== this.value;

    }, this);

});


/*
|--------------------------------------------------------------------------
| Filtrar departamentos pela unidade
|--------------------------------------------------------------------------
*/

const unidade = document.getElementById('id_unidade');
const departamento = document.getElementById('id_departamento');
const paisNascimento=document.querySelector('[name="id_pais_nascimento"]');
const provinciaNascimento=document.getElementById('id_provincia_nascimento');
const municipioNascimento=document.getElementById('id_municipio_nascimento');
function filtrarProvincias(){const p=paisNascimento?.value||'';Array.from(provinciaNascimento.options).forEach(o=>{if(!o.value)return;o.hidden=o.dataset.pais!==p;o.disabled=o.hidden;});filtrarMunicipios();}
function filtrarMunicipios(){const p=provinciaNascimento?.value||'';Array.from(municipioNascimento.options).forEach(o=>{if(!o.value)return;o.hidden=o.dataset.provincia!==p;o.disabled=o.hidden;});}
paisNascimento?.addEventListener('change',filtrarProvincias);provinciaNascimento?.addEventListener('change',filtrarMunicipios);filtrarProvincias();

function filtrarDepartamentos() {

    const idUnidade = unidade.value;

    Array.from(departamento.options).forEach(function(option) {

        if (!option.value) return;

        option.hidden =
            option.dataset.unidade !== idUnidade;

    });
}

unidade.addEventListener('change', filtrarDepartamentos);

filtrarDepartamentos();

</script>
</div>

<script>
(function(){const p=document.getElementById('id_provincia_residencia'),m=document.getElementById('id_municipio_residencia');if(!p||!m)return;function f(){const v=p.value;[...m.options].forEach(o=>{if(!o.dataset.provincia)return;o.hidden=!!v&&o.dataset.provincia!==v;if(o.hidden)o.selected=false;});}p.addEventListener('change',f);f();})();
</script>
<script>
(function(){const q=document.querySelector('[name="id_quadro"]'),box=document.getElementById('campo-nip'),nip=document.querySelector('[name="nip"]'),mark=document.getElementById('nip-required-mark');if(!q||!box||!nip)return;function sync(){const o=q.options[q.selectedIndex],civil=!!o&&/civil/i.test(o.dataset.quadroNome||o.textContent||'');box.hidden=civil;nip.required=!civil && <?= strtoupper((string)($especialista['tipo_especialista'] ?? 'MILITAR')) === 'CIVIL' ? 'false' : 'true' ?>;if(mark)mark.style.display=civil?'none':'inline';if(civil)nip.value='';}q.addEventListener('change',sync);sync();})();
(function(){const p=document.getElementById('id_provincia_residencia'),m=document.getElementById('id_municipio_residencia');if(!p||!m)return;function sync(){const v=p.value;Array.from(m.options).forEach(o=>{if(!o.value)return;const ok=!v||o.dataset.provincia===v;o.hidden=!ok;o.disabled=!ok;if(!ok&&o.selected)o.selected=false;});}p.addEventListener('change',sync);sync();})();

(function(){var iban=document.querySelector('input[name="iban"]');if(iban){function format(){var v=iban.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,34);iban.value=v.replace(/(.{4})/g,'$1 ').trim();}iban.addEventListener('input',format);iban.addEventListener('blur',format);}})();
</script>
<?php require __DIR__ . '/../../layout/footer.php'; ?>
