<?php
require_once __DIR__ . '/../../../app/auth.php';
require_login();
require_permission('ESPECIALISTAS_EDITAR');
$pdo=db();
$id_especialista=(int)($_GET['id_especialista']??0);
if(!$id_especialista){header('Location: especialistas.php');exit;}
$st=$pdo->prepare("SELECT e.id_especialista,e.id_ramo,ds.id_unidade,dp.nome_completo FROM especialistas e JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista WHERE e.id_especialista=?");
$st->execute([$id_especialista]);$especialista=$st->fetch(PDO::FETCH_ASSOC);
if(!$especialista)die('Especialista não encontrado.');
if($_SESSION['user']['nivel']==='RAMO'){
 $st=$pdo->prepare('SELECT 1 FROM utilizador_ramo WHERE id_utilizador=? AND id_ramo=?');$st->execute([$_SESSION['user']['id'],$especialista['id_ramo']]);if(!$st->fetchColumn())die('Acesso não autorizado.');
}elseif($_SESSION['user']['nivel']==='UNIDADE'){
 $st=$pdo->prepare('SELECT 1 FROM utilizador_unidade WHERE id_utilizador=? AND id_unidade=?');$st->execute([$_SESSION['user']['id'],$especialista['id_unidade']]);if(!$st->fetchColumn())die('Acesso não autorizado.');
}
$tipos=$pdo->query("SELECT id_tipo_formacao,nome,categoria FROM tipos_formacao WHERE estado='ATIVO' ORDER BY categoria,nome")->fetchAll(PDO::FETCH_ASSOC);
$tipoNovoId=(int)($_GET['tipo_id']??0);
$instituicoes=$pdo->query("SELECT id_instituicao,nome FROM instituicoes WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$paises=$pdo->query("SELECT id_pais,nome FROM paises WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$provincias=$pdo->query("SELECT id_provincia,nome,id_pais FROM provincias WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$erro='';$info='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_verify_post();
 if(($_POST['acao']??'')==='nova_instituicao') {
  $novo=trim((string)($_POST['nova_instituicao']??''));
  if($novo===''||mb_strlen($novo)>200) $erro='Indique o nome da instituição (até 200 caracteres).';
  else {try{$q=$pdo->prepare("INSERT INTO instituicoes(nome) VALUES (?) ON DUPLICATE KEY UPDATE id_instituicao=LAST_INSERT_ID(id_instituicao),estado='ATIVO'");$q->execute([$novo]);header('Location: formacao_nova.php?id_especialista='.$id_especialista.'&instituicao_id='.(int)$pdo->lastInsertId().'&categoria='.urlencode((string)($_POST['categoria']??'')));exit;}catch(Throwable $e){$erro='Não foi possível adicionar a instituição.';}}
 }
 if(($_POST['acao']??'')==='novo_tipo_formacao'){
  $nome=trim($_POST['novo_tipo_formacao']??'');$cat=$_POST['categoria']??'GERAL';
  if($nome!==''&&in_array($cat,['MILITAR','GERAL'],true)){
   try{$q=$pdo->prepare('INSERT INTO tipos_formacao(nome,categoria) VALUES(?,?)');$q->execute([$nome,$cat]);header('Location: formacao_nova.php?id_especialista='.$id_especialista.'&categoria='.$cat.'&tipo_novo=1&tipo_id='.(int)$q->lastInsertId());exit;}catch(Throwable $e){$erro='Não foi possível adicionar o tipo de formação: '.$e->getMessage();}
  }else $erro='Informe o nome e a categoria do novo tipo de formação.';
 }
 if(in_array(($_POST['acao']??''),['novo_tipo_formacao','nova_instituicao'],true) && !$erro) { $erro='Não foi possível adicionar o tipo de formação.'; }
 if(in_array(($_POST['acao']??''),['novo_tipo_formacao','nova_instituicao'],true)) { /* não guardar formação no mesmo pedido */ } else {
 $categoria=$_POST['categoria']??'';$id_tipo=!empty($_POST['id_tipo_formacao'])?(int)$_POST['id_tipo_formacao']:null;$designacao=trim($_POST['designacao']??'');$id_inst=!empty($_POST['id_instituicao'])?(int)$_POST['id_instituicao']:null;$id_pais=!empty($_POST['id_pais'])?(int)$_POST['id_pais']:null;$id_provincia=!empty($_POST['id_provincia'])?(int)$_POST['id_provincia']:null;$ini=$_POST['data_inicio']?:null;$fim=$_POST['data_fim']?:null;$dur=trim($_POST['duracao']??'');$cert=trim($_POST['certificado']??'');$obs=trim($_POST['observacoes']??'');
 if(!$erro && !in_array($categoria,['MILITAR','GERAL'],true))$erro='Selecione a categoria.';
 if(!$erro && !$id_tipo)$erro='Selecione o nome da formação ou adicione um novo nome.';
 if(!$erro && $designacao===''){ $qNome=$pdo->prepare("SELECT nome FROM tipos_formacao WHERE id_tipo_formacao=? AND categoria=? AND estado='ATIVO'");$qNome->execute([$id_tipo,$categoria]);$designacao=(string)$qNome->fetchColumn(); }
 if(!$erro && $ini&&$fim&&$fim<$ini)$erro='A data final não pode ser anterior à inicial.';
 if(!$erro && $id_tipo){$q=$pdo->prepare("SELECT 1 FROM tipos_formacao WHERE id_tipo_formacao=? AND categoria=? AND estado='ATIVO'");$q->execute([$id_tipo,$categoria]);if(!$q->fetchColumn())$erro='O tipo selecionado não pertence à categoria escolhida.';}
 if(!$erro){$q=$pdo->prepare('INSERT INTO formacoes(id_especialista,categoria,id_tipo_formacao,designacao,id_instituicao,id_pais,id_provincia,data_inicio,data_fim,duracao,certificado,observacoes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');$q->execute([$id_especialista,$categoria,$id_tipo,$designacao,$id_inst,$id_pais,$id_provincia,$ini,$fim,$dur?:null,$cert?:null,$obs?:null]);header('Location: especialista.php?id='.$id_especialista.'&formacao=adicionada#formacoes');exit;}
 }
}
$catAtual=$_POST['categoria']??($_GET['categoria']??'');$page_title='Nova Formação';require __DIR__.'/../../layout/header.php';
?>
<div class="module-page module-formacao-nova"><main class="page"><div class="panel form-box">
<h1>Nova Formação</h1><p>Especialista: <strong><?=htmlspecialchars($especialista['nome_completo'])?></strong></p>
<?php if($erro):?><div class="erro"><?=htmlspecialchars($erro)?></div><?php endif;?>
<?php if(isset($_GET['tipo_novo'])):?><div class="alert-success">Tipo de formação adicionado à BD. Pode selecioná-lo abaixo.</div><?php endif;?>
<form method="post" class="form-grid">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
<div class="form-group"><label>Categoria *</label><select name="categoria" id="categoriaFormacao" required><option value="">Selecione</option><option value="MILITAR" <?=$catAtual==='MILITAR'?'selected':''?>>Formação Militar</option><option value="GERAL" <?=$catAtual==='GERAL'?'selected':''?>>Formação Geral</option></select></div>
<div class="form-group"><label>Nome da Formação *</label><div class="campo-com-acoes"><select name="id_tipo_formacao" id="tipoFormacao" required><option value="">Selecione</option><?php foreach($tipos as $t):?><option value="<?=$t['id_tipo_formacao']?>" data-categoria="<?=$t['categoria']?>" <?=((int)($_POST['id_tipo_formacao']??$tipoNovoId)==$t['id_tipo_formacao'])?'selected':''?>><?=htmlspecialchars($t['nome'])?></option><?php endforeach;?></select><button type="button" class="btn-mini" onclick="document.getElementById('novoTipo').classList.toggle('ativo')" title="Adicionar tipo">+</button></div><div id="novoTipo" class="subform-rapido"><input type="text" name="novo_tipo_formacao" placeholder="Nome da Formação"><button class="btn btn-secondary" type="submit" formnovalidate name="acao" value="novo_tipo_formacao">+ Adicionar nome da formação</button></div></div>

<div class="form-group"><label>Instituição</label><div class="campo-com-acoes"><select name="id_instituicao"><option value="">Selecione</option><?php foreach($instituicoes as $i):?><option value="<?=$i['id_instituicao']?>" <?=((int)($_POST['id_instituicao']??$_GET['instituicao_id']??0)==$i['id_instituicao'])?'selected':''?>><?=htmlspecialchars($i['nome'])?></option><?php endforeach;?></select><button type="button" class="btn-mini" onclick="document.getElementById('sge-inst-formacao').hidden=!document.getElementById('sge-inst-formacao').hidden">+</button></div><div id="sge-inst-formacao" hidden><input name="nova_instituicao" maxlength="200" placeholder="Nome da instituição"><button type="submit" formnovalidate name="acao" value="nova_instituicao" class="btn btn-secondary">Adicionar instituição</button></div></div>
<div class="form-group"><label>País</label><select name="id_pais" id="paisFormacao"><option value="">Selecione</option><?php foreach($paises as $p):?><option value="<?=$p['id_pais']?>" <?=((int)($_POST['id_pais']??0)==$p['id_pais'])?'selected':''?>><?=htmlspecialchars($p['nome'])?></option><?php endforeach;?></select></div>
<div class="form-group"><label>Província</label><select name="id_provincia" id="provinciaFormacao"><option value="">Selecione</option><?php foreach($provincias as $pv):?><option value="<?=$pv['id_provincia']?>" data-pais="<?=$pv['id_pais']?>" <?=((int)($_POST['id_provincia']??0)==$pv['id_provincia'])?'selected':''?>><?=htmlspecialchars($pv['nome'])?></option><?php endforeach;?></select></div>
<div class="form-group"><label>Data de início</label><input type="date" name="data_inicio" value="<?=htmlspecialchars($_POST['data_inicio']??'')?>"></div>
<div class="form-group"><label>Data de fim</label><input type="date" name="data_fim" value="<?=htmlspecialchars($_POST['data_fim']??'')?>"></div>
<div class="form-group"><label>Duração</label><input name="duracao" value="<?=htmlspecialchars($_POST['duracao']??'')?>"></div>
<div class="form-group"><label>Certificado</label><input name="certificado" value="<?=htmlspecialchars($_POST['certificado']??'')?>"></div>
<div class="form-group full"><label>Observações</label><textarea name="observacoes" rows="4"><?=htmlspecialchars($_POST['observacoes']??'')?></textarea></div>
<div class="actions full"><button class="btn btn-primary">Guardar</button><a class="btn btn-secondary" href="especialista.php?id=<?=$id_especialista?>#formacoes">Cancelar</a></div>
</form></div></main></div>
<script>
(function(){const c=document.getElementById('categoriaFormacao'),s=document.getElementById('tipoFormacao');function f(){const v=c.value;[...s.options].forEach(o=>{if(!o.dataset.categoria){o.hidden=false;return;}o.hidden=!!v&&o.dataset.categoria!==v;if(o.hidden&&o.selected)o.selected=false;});}c.addEventListener('change',f);f();const pais=document.getElementById('paisFormacao'),prov=document.getElementById('provinciaFormacao');function filtrarProvincias(){const id=pais.value;[...prov.options].forEach(o=>{if(!o.dataset.pais){o.hidden=false;return;}o.hidden=!!id&&o.dataset.pais!==id;if(o.hidden&&o.selected)o.selected=false;});}pais.addEventListener('change',filtrarProvincias);filtrarProvincias();})();
</script>
<?php require __DIR__.'/../../layout/footer.php'; ?>
