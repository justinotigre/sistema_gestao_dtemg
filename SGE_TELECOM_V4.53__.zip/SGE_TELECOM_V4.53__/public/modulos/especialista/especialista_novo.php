<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/historico.php';
require_login(); require_permission('ESPECIALISTAS_CRIAR');


$pdo = db();

$erro = '';
$sucesso = '';
$tipoEspecialista = strtoupper(trim($_POST['tipo_especialista'] ?? $_GET['tipo'] ?? 'MILITAR'));
if (!in_array($tipoEspecialista, ['MILITAR','CIVIL'], true)) $tipoEspecialista = 'MILITAR';

/*
|--------------------------------------------------------------------------
| Carregar listas
|--------------------------------------------------------------------------
*/

$ramos = $pdo->query("
    SELECT id_ramo, nome, sigla
    FROM ramo
    WHERE estado = 'ATIVO' AND UPPER(sigla) IN ('EXE','FAN','MGA')
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);

$categoriasCivis = $pdo->query("SELECT id_categoria_civil,nome FROM categorias_civis WHERE estado='ATIVO' ORDER BY ordem,nome")->fetchAll(PDO::FETCH_ASSOC);
$quadros = $pdo->query("
    SELECT id_quadro, nome, sigla
    FROM quadros_servico
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);

$sexos = $pdo->query("
    SELECT id_sexo, nome
    FROM sexos
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);

$estados_civis = $pdo->query("
    SELECT id_estado_civil, nome
    FROM estados_civis
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);

$paises = $pdo->query("
    SELECT id_pais, nome
    FROM paises
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);

$provincias = $pdo->query("SELECT id_provincia,id_pais,nome FROM provincias WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$municipios = $pdo->query("SELECT id_municipio,id_provincia,nome FROM municipios WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$regioes = $pdo->query("SELECT id_regiao,nome,sigla FROM regioes WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);

$funcoes = $pdo->query("
    SELECT id_funcao, nome
    FROM funcoes
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);


$unidades = $pdo->query("
    SELECT u.id_unidade,u.id_ramo,u.nome,u.sigla FROM unidades u WHERE u.estado = 'ATIVO' ORDER BY u.nome
")->fetchAll(PDO::FETCH_ASSOC);
$departamentos = $pdo->query("SELECT id_departamento,id_unidade,nome FROM departamentos WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);

$situacoes = $pdo->query("
    SELECT
        id_situacao_servico,
        nome,
        grupo
    FROM situacoes_servico
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);
$bancos = $pdo->query("SELECT id_banco,nome,sigla FROM bancos WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| Valores enviados
|--------------------------------------------------------------------------
*/

$gruposSanguineos = $pdo->query("SELECT id_grupo_sanguineo,nome FROM grupos_sanguineos WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);

$dados = [
    'nome_completo' => '',
    'data_nascimento' => '',
    'id_sexo' => '',
    'id_pais_nascimento' => '',
    'id_provincia_nascimento' => '',
    'id_municipio_nascimento' => '',
    'id_pais_nacionalidade' => '',
    'id_estado_civil' => '',
    'id_grupo_sanguineo' => '',
    'peso_kg' => '',
    'numero_bi' => '',
    'data_emissao_bi' => '',
    'data_validade_bi' => '',
    'local_emissao_bi' => '',
    'telefone' => '',
    'telefone_alternativo' => '',
    'email' => '',
    'id_provincia_residencia' => '',
    'id_municipio_residencia' => '',
    'bairro' => '',
    'rua' => '',
    'casa' => '',
    'ponto_referencia' => '',

    'id_ramo' => '',
    'id_quadro' => '',
    'id_categoria_civil' => '',
    'id_patente' => '',

    'nip' => '',
    'no_civil' => '',
    'local_incorporacao' => '',
    'local_servico' => '',
    'numero_processo' => '',
    'data_incorporacao' => '',
    'data_promocao' => '',
    'id_funcao' => '',
    'id_unidade' => '',
    'id_regiao' => '',
    'id_departamento' => '',
    'id_situacao_servico' => '',
    'data_inicio_funcao' => '',
    'data_fim_funcao' => '',
    'observacoes' => '',
    'id_banco' => '', 'numero_conta' => '', 'iban' => '', 'numero_agente' => ''
];


/*
|--------------------------------------------------------------------------
| POST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipoEspecialista = strtoupper(trim($_POST['tipo_especialista'] ?? 'MILITAR'));
    if (!in_array($tipoEspecialista, ['MILITAR','CIVIL'], true)) $tipoEspecialista = 'MILITAR';

    foreach ($dados as $campo => $valor) {
        $dados[$campo] = trim($_POST[$campo] ?? '');
    }

    if ($dados['nome_completo'] === '') {
        $erro = 'O nome completo é obrigatório.';
    }

    elseif ($tipoEspecialista === 'MILITAR' && $dados['id_ramo'] === '') {
        $erro = 'Selecione o ramo.';
    } elseif ($tipoEspecialista === 'MILITAR' && $dados['id_quadro'] === '') {
        $erro = 'Selecione a Forma de Prestação de Serviço (FPS).';
    } elseif ($tipoEspecialista === 'MILITAR' && $dados['nip'] === '') {
        $erro = 'O NIP é obrigatório para especialistas militares.';
    }

    if ($erro === '' && $tipoEspecialista === 'CIVIL' && $dados['id_categoria_civil'] !== '') {
        $ck=$pdo->prepare("SELECT COUNT(*) FROM categorias_civis WHERE id_categoria_civil=? AND estado='ATIVO'");
        $ck->execute([(int)$dados['id_categoria_civil']]);
        if (!(int)$ck->fetchColumn()) $erro='Selecione uma Categoria válida.';
    }
    if ($erro === '' && !in_array($dados['local_servico'], ['EMG','EXE','FAN','MGA'], true)) $erro = 'Selecione o Local de Serviço.';

    /*
    |--------------------------------------------------------------------------
    | Verificar âmbito de acesso
    |--------------------------------------------------------------------------
    */

    if ($tipoEspecialista === 'CIVIL') {
        foreach (['nip','id_patente','id_quadro','id_ramo','numero_processo','data_incorporacao','local_incorporacao','data_promocao'] as $campoMilitar) $dados[$campoMilitar] = '';
    }

    if ($erro === '' && $tipoEspecialista === 'CIVIL' && in_array(($_SESSION['user']['nivel'] ?? ''), ['RAMO','UNIDADE'], true)) $erro = 'O pré-cadastro civil exige permissões gerais.';

    if ($erro === '') {

        $ramoId = (int)$dados['id_ramo'];
        if ($tipoEspecialista === 'CIVIL' && in_array(($_SESSION['user']['nivel'] ?? ''), ['RAMO','UNIDADE'], true)) {
            $erro = 'O pré-cadastro civil deve ser realizado por um utilizador com permissão geral.';
        }
        $unidadeId = (int)$dados['id_unidade'];

        $usuario = $_SESSION['user'];

        if ($usuario['nivel'] === 'RAMO') {

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM utilizador_ramo
                WHERE id_utilizador = ?
                AND id_ramo = ?
            ");

            $stmt->execute([
                $usuario['id'],
                $ramoId
            ]);

            if (!(int)$stmt->fetchColumn()) {
                $erro = 'Não tem permissão para cadastrar especialistas neste ramo.';
            }
        }

        elseif ($usuario['nivel'] === 'UNIDADE') {

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM utilizador_unidade
                WHERE id_utilizador = ?
                AND id_unidade = ?
            ");

            $stmt->execute([
                $usuario['id'],
                $unidadeId
            ]);

            if (!$unidadeId || !(int)$stmt->fetchColumn()) {
                $erro = 'Não tem permissão para cadastrar especialistas nesta unidade.';
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Validar patente
    |--------------------------------------------------------------------------
    */

    if ($erro === '' && $dados['id_patente'] !== '') {

        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM patentes
            WHERE id_patente = ?
            AND id_ramo = ?
            AND estado = 'ATIVO'
        ");

        $stmt->execute([
            (int)$dados['id_patente'],
            (int)$dados['id_ramo']
        ]);

        if (!(int)$stmt->fetchColumn()) {
            $erro = 'A patente selecionada não pertence ao ramo escolhido.';
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Gravar
    |--------------------------------------------------------------------------
    */

    if ($erro === '') {

        $etapaGravacao = 'validação dos dados geográficos';
        try {

            if (!empty($dados['id_municipio_nascimento']) && !empty($dados['id_provincia_nascimento'])) {
            $q=$pdo->prepare('SELECT 1 FROM municipios WHERE id_municipio=? AND id_provincia=? LIMIT 1');$q->execute([(int)$dados['id_municipio_nascimento'],(int)$dados['id_provincia_nascimento']]);if(!$q->fetchColumn())throw new Exception('O município de nascimento não pertence à província selecionada.');
        }
        if (!empty($dados['id_municipio_residencia']) && !empty($dados['id_provincia_residencia'])) {
            $q=$pdo->prepare('SELECT 1 FROM municipios WHERE id_municipio=? AND id_provincia=? LIMIT 1');$q->execute([(int)$dados['id_municipio_residencia'],(int)$dados['id_provincia_residencia']]);if(!$q->fetchColumn())throw new Exception('O município de residência não pertence à província selecionada.');
        }
        $etapaGravacao = 'início da transação';
        $pdo->beginTransaction();


            /*
            |--------------------------------------------------------------------------
            | Especialista
            |--------------------------------------------------------------------------
            */

            $etapaGravacao = 'criação do registo principal em especialistas';
            $stmt = $pdo->prepare("
                INSERT INTO especialistas
                (
                    id_ramo,
                    id_quadro,
                    id_patente,
                    tipo_especialista,
                    id_categoria_civil,
                    estado,
                    observacoes
                )
                VALUES (?, ?, ?, ?, ?, 'ATIVO', ?)
            ");

            $stmt->execute([
                ($tipoEspecialista === 'CIVIL' ? null : (int)$dados['id_ramo']),
                $dados['id_quadro'] !== '' ? (int)$dados['id_quadro'] : null,
                $dados['id_patente'] !== ''
                    ? (int)$dados['id_patente']
                    : null,
                $tipoEspecialista,
                $tipoEspecialista === 'CIVIL' && $dados['id_categoria_civil'] !== '' ? (int)$dados['id_categoria_civil'] : null,
                $dados['observacoes']
            ]);

            // Obter o ID gerado nesta mesma ligação e validar imediatamente
            // que pertence ao registo principal acabado de criar.
            $idEspecialista = (int)$pdo->query('SELECT LAST_INSERT_ID()')->fetchColumn();
            if ($idEspecialista < 1) {
                throw new RuntimeException('A base de dados não devolveu um identificador válido para o especialista.');
            }
            $verificarEspecialista = $pdo->prepare(
                'SELECT id_especialista FROM especialistas WHERE id_especialista = ? LIMIT 1'
            );
            $verificarEspecialista->execute([$idEspecialista]);
            if (!$verificarEspecialista->fetchColumn()) {
                throw new RuntimeException(
                    'O ID gerado (' . $idEspecialista . ') não foi encontrado em especialistas. '
                    . 'Confirme a base de dados e a versão do ficheiro PHP em execução.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Dados pessoais
            |--------------------------------------------------------------------------
            */

            $etapaGravacao = 'gravação dos dados pessoais';
            $stmt = $pdo->prepare("
                INSERT INTO dados_pessoais
                (
                    id_especialista,
                    nome_completo,
                    data_nascimento,
                    id_sexo,
                    id_pais_nascimento,
                    id_provincia_nascimento,
                    id_municipio_nascimento,
                    id_pais_nacionalidade,
                    id_estado_civil,
                    id_grupo_sanguineo,
                    peso_kg,
                    numero_bi,
                    data_emissao_bi,
                    data_validade_bi,
                    local_emissao_bi,
                    telefone,
                    telefone_alternativo,
                    email
                )
                VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $idEspecialista,
                $dados['nome_completo'],
                $dados['data_nascimento'] ?: null,
                $dados['id_sexo'] !== ''
                    ? (int)$dados['id_sexo']
                    : null,
                $dados['id_pais_nascimento'] !== ''
                    ? (int)$dados['id_pais_nascimento']
                    : null,
                $dados['id_provincia_nascimento'] !== ''
                    ? (int)$dados['id_provincia_nascimento']
                    : null,
                $dados['id_municipio_nascimento'] !== ''
                    ? (int)$dados['id_municipio_nascimento']
                    : null,
                $dados['id_pais_nacionalidade'] !== ''
                    ? (int)$dados['id_pais_nacionalidade']
                    : null,
                $dados['id_estado_civil'] !== ''
                    ? (int)$dados['id_estado_civil']
                    : null,
                $dados['id_grupo_sanguineo'] !== '' ? (int)$dados['id_grupo_sanguineo'] : null,
                $dados['peso_kg'] !== '' ? (float)$dados['peso_kg'] : null,
                $dados['numero_bi'] !== ''
                    ? $dados['numero_bi']
                    : null,
                $dados['data_emissao_bi'] ?: null,
                $dados['data_validade_bi'] ?: null,
                $dados['local_emissao_bi'],
                $dados['telefone'],
                $dados['telefone_alternativo'],
                $dados['email']
            ]);


            // Morada/residência: estes campos já existem no formulário e devem ser persistidos.
            $etapaGravacao = 'gravação da residência';
            $stmt = $pdo->prepare("
                INSERT INTO dados_residencia
                    (id_especialista, id_provincia, id_municipio, bairro, rua, casa, ponto_referencia)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $idEspecialista,
                $dados['id_provincia_residencia'] !== '' ? (int)$dados['id_provincia_residencia'] : null,
                $dados['id_municipio_residencia'] !== '' ? (int)$dados['id_municipio_residencia'] : null,
                $dados['bairro'] !== '' ? $dados['bairro'] : null,
                $dados['rua'] !== '' ? $dados['rua'] : null,
                $dados['casa'] !== '' ? $dados['casa'] : null,
                $dados['ponto_referencia'] !== '' ? $dados['ponto_referencia'] : null
            ]);

            /*
            |--------------------------------------------------------------------------
            | Dados de serviço
            |--------------------------------------------------------------------------
            */

            $etapaGravacao = 'gravação dos dados de serviço';
            $stmtRamoSigla = $pdo->prepare('SELECT UPPER(sigla) FROM ramo WHERE id_ramo=? LIMIT 1');
            $stmtRamoSigla->execute([(int)$dados['id_ramo']]);
            $siglaRamoInicial = (string)$stmtRamoSigla->fetchColumn();
            $localServicoInicial = $dados['local_servico'];
            if ($tipoEspecialista === 'MILITAR' && $localServicoInicial !== 'EMG' && $localServicoInicial !== $siglaRamoInicial) throw new RuntimeException('O local de serviço deve corresponder ao ramo ou ao EMG.');
            if (current_user_level() !== 'GLOBAL' && !in_array($localServicoInicial, user_service_locations(), true)) throw new RuntimeException('Não tem autorização para criar especialistas neste Local de Serviço.');
            if ($tipoEspecialista === 'MILITAR' && !in_array($siglaRamoInicial, ['EXE','FAN','MGA'], true)) {
                throw new RuntimeException('O ramo selecionado não é válido para o novo modelo organizacional.');
            }
            $stmt = $pdo->prepare("
                INSERT INTO dados_servico
                (
                    id_especialista,
                    nip,
                    no_civil,
                    numero_processo,
                    data_incorporacao,
                    local_incorporacao,
                    data_promocao,
                    id_funcao,
                    id_unidade,
                    id_regiao,
                    local_servico,
                    id_departamento,
                    id_situacao_servico,
                    data_inicio_funcao,
                    data_fim_funcao,
                    observacoes
                )
                VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $idEspecialista,
                $dados['nip'] !== '' ? $dados['nip'] : null,
                $tipoEspecialista === 'CIVIL' && $dados['no_civil'] !== '' ? $dados['no_civil'] : null,
                $dados['numero_processo'] !== ''
                    ? $dados['numero_processo']
                    : null,
                $dados['data_incorporacao'] ?: null,
                $dados['local_incorporacao'] !== '' ? $dados['local_incorporacao'] : null,
                $dados['data_promocao'] ?: null,
                $dados['id_funcao'] !== ''
                    ? (int)$dados['id_funcao']
                    : null,
                $dados['id_unidade'] !== ''
                    ? (int)$dados['id_unidade']
                    : null,
                $dados['id_regiao'] !== '' ? (int)$dados['id_regiao'] : null,
                $localServicoInicial,
                $dados['id_departamento'] !== ''
                    ? (int)$dados['id_departamento']
                    : null,
                $dados['id_situacao_servico'] !== ''
                    ? (int)$dados['id_situacao_servico']
                    : null,
                $dados['data_inicio_funcao'] ?: null,
                $dados['data_fim_funcao'] ?: null,
                $dados['observacoes']
            ]);

            // Vestuário inicial. Nunca sobrescrever silenciosamente um registo
            // preexistente: reportar o ID e a base de dados no log para diagnóstico.
            $etapaGravacao = 'gravação dos tamanhos de vestuário';
            $baseAtual = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
            $verificarVestuário = $pdo->prepare(
                'SELECT id_vestuario FROM vestuario WHERE id_especialista = ? LIMIT 1'
            );
            $verificarVestuário->execute([$idEspecialista]);
            $vestuarioExistente = $verificarVestuário->fetchColumn();
            if ($vestuarioExistente) {
                throw new RuntimeException(
                    'Já existe vestuário (ID ' . (int)$vestuarioExistente
                    . ') para o especialista ' . $idEspecialista
                    . ' na base ' . $baseAtual
                    . '. Verifique a ligação à base de dados e os registos anteriores.'
                );
            }
            $pdo->prepare("
                INSERT INTO vestuario (id_especialista,numero_calca,numero_camisa,numero_sapato,numero_bota,numero_boina,numero_quiko,numero_casaco,outros)
                VALUES (?,?,?,?,?,?,?,?,?)
            ")->execute([
                $idEspecialista, trim($_POST['numero_calca'] ?? '') ?: null, trim($_POST['numero_camisa'] ?? '') ?: null,
                trim($_POST['numero_sapato'] ?? '') ?: null, trim($_POST['numero_bota'] ?? '') ?: null,
                trim($_POST['numero_boina'] ?? '') ?: null, trim($_POST['numero_quiko'] ?? '') ?: null,
                trim($_POST['numero_casaco'] ?? '') ?: null, trim($_POST['outros_vestuario'] ?? '') ?: null
            ]);
            $etapaGravacao = 'gravação dos dados bancários';
            $pdo->prepare("INSERT INTO dados_bancarios (id_especialista,id_banco,numero_conta,iban,numero_agente) VALUES (?,?,?,?,?)")
                ->execute([$idEspecialista,$dados['id_banco']!==''?(int)$dados['id_banco']:null,$dados['numero_conta']!==''?$dados['numero_conta']:null,$dados['iban']!==''?$dados['iban']:null,$dados['numero_agente']!==''?$dados['numero_agente']:null]);

            // Fotografia principal opcional durante o pré-cadastro.
            if (isset($_FILES['fotografia_inicial']) && $_FILES['fotografia_inicial']['error'] !== UPLOAD_ERR_NO_FILE) {
                $arquivoFoto = $_FILES['fotografia_inicial'];
                if ($arquivoFoto['error'] !== UPLOAD_ERR_OK || $arquivoFoto['size'] > 8 * 1024 * 1024) {
                    throw new RuntimeException('A fotografia não foi aceite. Verifique o ficheiro e o limite de 8 MB.');
                }
                $mimeFoto = (new finfo(FILEINFO_MIME_TYPE))->file($arquivoFoto['tmp_name']);
                $extensoesFoto = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
                if (!isset($extensoesFoto[$mimeFoto])) {
                    throw new RuntimeException('Formato de fotografia não permitido. Use JPG, PNG ou WEBP.');
                }
                $dirFoto = app_public_path('uploads/especialistas/fotografias');
                if (!is_dir($dirFoto) && !mkdir($dirFoto, 0775, true) && !is_dir($dirFoto)) {
                    throw new RuntimeException('Não foi possível preparar a pasta das fotografias.');
                }
                $nomeFoto = bin2hex(random_bytes(12)) . '.' . $extensoesFoto[$mimeFoto];
                if (!move_uploaded_file($arquivoFoto['tmp_name'], $dirFoto . DIRECTORY_SEPARATOR . $nomeFoto)) {
                    throw new RuntimeException('Não foi possível guardar a fotografia.');
                }
                $pdo->prepare('INSERT INTO fotografias (id_especialista,nome_ficheiro,caminho_ficheiro,principal,descricao) VALUES (?,?,?,?,?)')
                    ->execute([$idEspecialista, $nomeFoto, 'uploads/especialistas/fotografias/' . $nomeFoto, 1, 'Fotografia inicial do pré-cadastro']);
            }

            // Histórico e auditoria fazem parte da mesma transação: se falharem,
            // a criação não fica parcialmente confirmada sem o respetivo registo.
            $etapaGravacao = 'registo do histórico/auditoria';
            registar_historico_especialista($pdo,$idEspecialista,'OUTRO','CRIACAO',null,$dados['nome_completo']);
            registar_auditoria($pdo,'ESPECIALISTAS','CRIACAO','ESPECIALISTAS','especialistas',$idEspecialista,'Novo especialista criado.');

            $etapaGravacao = 'confirmação da transação';
            $pdo->commit();

            header(
                'Location: especialista.php?id=' .
                $idEspecialista .
                '&criado=1'
            );

            exit;

        } catch (Throwable $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // O detalhe técnico fica no log do PHP; não expomos SQL/estrutura da BD ao utilizador.
            $baseErro = '';
            try { $baseErro = (string)$pdo->query('SELECT DATABASE()')->fetchColumn(); } catch (Throwable $ignorado) {}
            error_log('[Sistema Especialistas][CRIAR ESPECIALISTA] Etapa: ' . ($etapaGravacao ?? 'não identificada')
                . ' | Base de dados: ' . ($baseErro !== '' ? $baseErro : 'indisponível')
                . ' | ID especialista: ' . (isset($idEspecialista) ? (int)$idEspecialista : 'não gerado')
                . ' | Utilizador: ' . (int)($_SESSION['user']['id'] ?? 0)
                . ' | Erro: ' . $e->getMessage());

            $erro = 'Não foi possível cadastrar o especialista durante: ' . ($etapaGravacao ?? 'uma etapa não identificada') . '.';
            if ($e instanceof PDOException && (string)$e->getCode() === '23000') {
                $erro .= ' Existe um conflito de integridade na base de dados (por exemplo, um identificador duplicado ou um campo único). A transação em curso foi revertida, quando aplicável. Consulte o log antes de tentar novamente.';
            } else {
                $erro .= ' Verifique os dados obrigatórios e o log de erros do PHP para obter o detalhe técnico.';
            }
        }
    }
}
$page_title = "Especialista Novo";
require __DIR__ . '/../../layout/header.php';
?>

<div class="module-page module-especialista-novo">
<style>


        .module-page.module-especialista-novo .topo-pagina {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            gap: 20px;
        }

        .module-page.module-especialista-novo .topo-pagina h1 {
            margin-bottom: 5px;
        }

        .module-page.module-especialista-novo .topo-pagina p {
            margin: 0;
            color: #666;
        }

        .module-page.module-especialista-novo .acoes-topo {
            display: flex;
            gap: 10px;
        }

        .module-page.module-especialista-novo .btn {
            display: inline-block;
            padding: 10px 16px;
            border-radius: 6px;
            border: 0;
            text-decoration: none;
            cursor: pointer;
            font-weight: 600;
        }

        .module-page.module-especialista-novo .btn-primary {
            background: #1f6feb;
            color: #fff;
        }

        .module-page.module-especialista-novo .btn-secondary {
            background: #e9ecef;
            color: #222;
        }

        .module-page.module-especialista-novo .form-section {
            background: #fff;
            border-radius: 10px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,.06);
        }

        .module-page.module-especialista-novo .form-section h2 {
            margin-top: 0;
            padding-bottom: 12px;
            border-bottom: 1px solid #eee;
        }

        .module-page.module-especialista-novo .form-grid {
            display: grid;
            grid-template-columns:minmax(0,1.15fr) minmax(0,1fr) minmax(0,1fr);
            gap: 16px;
        }

        .module-page.module-especialista-novo .campo {
            display: flex;
            flex-direction: column;
            gap: 6px;
            min-width: 0;
        }

        .module-page.module-especialista-novo .form-grid > .campo {
            align-self: start;
        }

        .module-page.module-especialista-novo .campo input,
        .module-page.module-especialista-novo .campo select {
            min-height: 42px;
        }

        .module-page.module-especialista-novo .campo.col-2 {
            grid-column: span 2;
        }

        .module-page.module-especialista-novo .campo.col-3 {
            grid-column: span 3;
        }

        .module-page.module-especialista-novo .campo-opcional{font-weight:500;opacity:.65;font-size:12px}.module-page.module-especialista-novo .campo[hidden]{display:none!important}
        .module-page.module-especialista-novo .campo label {
            font-size: 13px;
            font-weight: 600;
        }

        .module-page.module-especialista-novo .campo input, .module-page.module-especialista-novo .campo select, .module-page.module-especialista-novo .campo textarea {
            width: 100%;
            box-sizing: border-box;
            padding: 10px;
            border: 1px solid #d5dbe1;
            border-radius: 6px;
            background: #fff;
            font: inherit;
        }

        .module-page.module-especialista-novo .campo textarea {
            min-height: 90px;
            resize: vertical;
        }

        .module-page.module-especialista-novo .obrigatorio {
            color: #c62828;
        }

        .module-page.module-especialista-novo .erro {
            background: #f8d7da;
            color: #842029;
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .module-page.module-especialista-novo .acoes-final {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-bottom: 30px;
        }

        @media(max-width: 900px) {

            .module-page.module-especialista-novo .form-grid {
                grid-template-columns: 1fr 1fr;
            }

            .module-page.module-especialista-novo .campo.col-3 {
                grid-column: span 2;
            }

        }

        @media(max-width: 600px) {

            .module-page.module-especialista-novo .topo-pagina {
                flex-direction: column;
                align-items: flex-start;
            }

            .module-page.module-especialista-novo .form-grid {
                grid-template-columns: 1fr;
            }

            .module-page.module-especialista-novo .campo.col-2, .module-page.module-especialista-novo .campo.col-3 {
                grid-column: span 1;
            }

        }

    
        .module-page.module-especialista-novo .form-grid{align-items:start;}
        .module-page.module-especialista-novo .campo input,
        .module-page.module-especialista-novo .campo select,
        .module-page.module-especialista-novo .campo textarea{height:42px;min-height:42px;}
        .module-page.module-especialista-novo .campo textarea{height:auto;min-height:96px;}
        .module-page.module-especialista-novo .form-section{border:1px solid #e1e7ec;}


        .tipo-especialista-switch{display:flex;gap:10px;margin:0 0 18px}
        .tipo-especialista-switch .tipo-btn{display:inline-flex;align-items:center;justify-content:center;min-width:140px;padding:11px 22px;border:1px solid #cbd5e1;border-radius:9px;text-decoration:none;font-weight:700;color:var(--text-color,#243447);background:var(--card-bg,#fff)}
        .tipo-especialista-switch .tipo-btn.ativo{background:#164e78;color:#fff;border-color:#164e78}
        /* Pré-cadastro: campos complementares ficam para a ficha detalhada. */
        #form-pre-cadastro .form-section:nth-of-type(1) .campo:has([name="data_nascimento"]),
        #form-pre-cadastro .form-section:nth-of-type(1) .campo:has([name="id_sexo"]),
        #form-pre-cadastro .form-section:nth-of-type(1) .campo:has([name="numero_bi"]),
        #form-pre-cadastro .form-section:nth-of-type(1) .campo:has([name="data_emissao_bi"]),
        #form-pre-cadastro .form-section:nth-of-type(1) .campo:has([name="data_validade_bi"]),
        #form-pre-cadastro .form-section:nth-of-type(1) .campo:has([name="local_emissao_bi"]),
        #form-pre-cadastro .form-section:nth-of-type(1) .campo:has([name="telefone"]),
        #form-pre-cadastro .form-section:nth-of-type(1) .campo:has([name="telefone_alternativo"]),
        #form-pre-cadastro .form-section:nth-of-type(1) .campo:has([name="email"]),
        #form-pre-cadastro .form-section:has([name="id_provincia_residencia"]) .campo,
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo {display:none!important}
        #form-pre-cadastro .form-section:has([name="id_ramo"]) .campo:has([name="id_ramo"]),
        #form-pre-cadastro .form-section:has([name="id_ramo"]) .campo:has([name="id_quadro"]),
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="data_incorporacao"]),
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="id_situacao_servico"]),
        #form-pre-cadastro .form-section:has([name="id_provincia_residencia"]) .campo:has([name="id_provincia_residencia"]),
        #form-pre-cadastro .form-section:has([name="id_provincia_residencia"]) .campo:has([name="id_municipio_residencia"]),
        #form-pre-cadastro .form-section:has([name="id_provincia_residencia"]) .campo:has([name="bairro"]),
        #form-pre-cadastro .form-section:has([name="id_provincia_residencia"]) .campo:has([name="rua"]),
        #form-pre-cadastro .form-section:has([name="id_provincia_residencia"]) .campo:has([name="casa"]),
        #form-pre-cadastro .form-section:has([name="id_provincia_residencia"]) .campo:has([name="ponto_referencia"]) {display:flex!important}
        #form-pre-cadastro .form-section:has([name="id_ramo"]) .campo:has([name="id_ramo"]),
        #form-pre-cadastro .form-section:has([name="id_ramo"]) .campo:has([name="id_quadro"]) {display:flex!important}
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="data_incorporacao"]),
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="id_situacao_servico"]) {display:flex!important}
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="nome_completo"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="data_nascimento"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="id_sexo"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="numero_bi"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="data_emissao_bi"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="data_validade_bi"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="local_emissao_bi"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="telefone"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="telefone_alternativo"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="email"]) {display:flex!important}
        #form-pre-cadastro .form-section:has([name="id_patente"]) .campo:has([name="id_patente"]){display:none!important}



        /* Lista positiva dos campos apresentados no pré-cadastro */
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo{display:none!important}
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="fotografia_inicial"]){display:flex!important}
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="nome_completo"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="id_sexo"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="data_nascimento"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="numero_bi"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="data_emissao_bi"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="data_validade_bi"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="local_emissao_bi"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="telefone"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="telefone_alternativo"]),
        #form-pre-cadastro .form-section:has([name="data_nascimento"]) .campo:has([name="email"]) {display:flex!important}


        /* V4.42: apresentação da fotografia integrada no pré-cadastro */
        #form-pre-cadastro .campo-fotografia-inicial{grid-column:1 / -1!important;display:flex!important}
        .foto-cadastro-layout{display:flex;align-items:center;gap:22px;flex-wrap:wrap;padding:18px;border:1px solid #d5e0ea;border-radius:14px;background:#f8fafc;width:100%;box-sizing:border-box}
        .foto-cadastro-retrato{width:138px;height:162px;flex:0 0 138px;border-radius:12px;overflow:hidden;border:2px dashed #b8cbd9;background:#fff;display:flex;align-items:center;justify-content:center}
        .foto-cadastro-retrato img{height:100%;width:100%;object-fit:cover;object-position:center top}
        #foto-cadastro-placeholder{display:flex;flex-direction:column;gap:8px;align-items:center;color:#7c8da1;font-size:13px}
        .foto-cadastro-icone{font-size:40px;line-height:1}
        .foto-cadastro-acoes{display:flex;flex:1;min-width:220px;flex-direction:column;align-items:flex-start;gap:14px}
        .foto-cadastro-titulo{font-weight:700;color:#203447}
        .foto-cadastro-botoes{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
        .foto-cadastro-btn{cursor:pointer}
        .foto-cadastro-input{display:none!important}
        .foto-cadastro-ficheiro{font-size:13px;color:#60758b;word-break:break-word}
        @media(max-width:530px){.foto-cadastro-layout{align-items:stretch;justify-content:center}.foto-cadastro-retrato{margin:auto}.foto-cadastro-acoes{align-items:center;text-align:center}.foto-cadastro-botoes{justify-content:center}}

        /* V4.41: só campos necessários no pré-cadastro da incorporação. */
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="id_ramo"]),
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="id_quadro"]),
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="nip"]),
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="local_servico"]),
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="data_incorporacao"]),
        #form-pre-cadastro .form-section:has([name="data_incorporacao"]) .campo:has([name="id_situacao_servico"]) {display:flex!important}
        #form-pre-cadastro .form-section:has([name="id_provincia_residencia"]) .campo:has([name="ponto_referencia"]){grid-column:auto!important}
/* Campos de incorporação militar ocultados integralmente para civis. */
        #form-pre-cadastro.tipo-civil [data-militar="1"],
        #form-pre-cadastro.tipo-civil .campo:has([name="nip"]),
        #form-pre-cadastro.tipo-civil .campo:has([name="numero_processo"]),
        #form-pre-cadastro.tipo-civil .campo:has([name="data_incorporacao"]),
        #form-pre-cadastro.tipo-civil .campo:has([name="local_incorporacao"]),
        #form-pre-cadastro.tipo-civil .campo:has([name="data_promocao"]) {display:none!important}
        #form-pre-cadastro.tipo-civil .form-section:has([name="data_incorporacao"]) .campo:not(:has([name="local_servico"])):not(:has([name="id_situacao_servico"])):not(:has([name="id_categoria_civil"])):not(:has([name="no_civil"])) {display:none!important}
        #form-pre-cadastro.tipo-civil .campo:has([name="id_categoria_civil"]), #form-pre-cadastro.tipo-civil .campo:has([name="no_civil"]) {display:flex!important}
        #form-pre-cadastro:not(.tipo-civil) .campo:has([name="id_categoria_civil"]), #form-pre-cadastro:not(.tipo-civil) .campo:has([name="no_civil"]) {display:none!important}
</style>
<main>

    <div class="topo-pagina">

        <div>

            <h1>Novo Especialista</h1>

            <p>Pré-cadastro resumido. Os restantes dados serão completados em “Ver especialista”.</p>

        </div>

        <div class="acoes-topo">

            <a
                href="especialistas.php"
                class="btn btn-secondary"
            >
                Voltar
            </a>

        </div>

    </div>


    <?php if ($erro): ?>

        <div class="erro">

            <?= htmlspecialchars($erro) ?>

        </div>

    <?php endif; ?>


    <div class="tipo-especialista-switch" role="group" aria-label="Tipo de especialista">
        <a class="tipo-btn <?= $tipoEspecialista === 'MILITAR' ? 'ativo' : '' ?>" href="?tipo=MILITAR" data-tipo="MILITAR">Militar</a>
        <a class="tipo-btn <?= $tipoEspecialista === 'CIVIL' ? 'ativo' : '' ?>" href="?tipo=CIVIL" data-tipo="CIVIL">Civil</a>
    </div>
    <form method="post" enctype="multipart/form-data" id="form-pre-cadastro">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
<input type="hidden" name="tipo_especialista" id="tipo_especialista" value="<?= htmlspecialchars($tipoEspecialista, ENT_QUOTES, 'UTF-8') ?>">


        <!-- DADOS PRINCIPAIS -->

        <section class="form-section">

            <h2>Dados do Especialista</h2>

            <div class="form-grid">

                <div class="campo col-2 campo-fotografia-inicial">
                    <label>Fotografia do especialista</label>
                    <div class="foto-cadastro-layout">
                        <div class="foto-cadastro-retrato" id="foto-cadastro-retrato">
                            <img id="foto-previa-inicial" alt="Pré-visualização da fotografia" style="display:none">
                            <div id="foto-cadastro-placeholder"><span class="foto-cadastro-icone">◉</span><span>Sem fotografia</span></div>
                        </div>
                        <div class="foto-cadastro-acoes">
                            <div class="foto-cadastro-titulo">Fotografia de identificação</div>
                            <div class="foto-cadastro-botoes">
                                <label for="fotografia_inicial" class="btn btn-secondary foto-cadastro-btn">Selecionar fotografia</label>
                                <button type="button" class="btn btn-secondary" id="btn-fazer-fotografia">📷 Fazer fotografia</button>
                                <button type="button" class="btn btn-secondary" id="btn-remover-fotografia" style="display:none">Remover</button>
                            </div>
                            <input type="file" name="fotografia_inicial" id="fotografia_inicial" accept="image/jpeg,image/png,image/webp" class="foto-cadastro-input">
                            <input type="file" id="fotografia_camera" accept="image/*" capture="user" class="foto-cadastro-input" aria-label="Utilizar câmara">
                            <span id="foto-nome-selecionado" class="foto-cadastro-ficheiro">JPG, PNG ou WEBP · Máximo 8 MB</span>
                        </div>
                    </div>
                </div>
                <div id="foto-camera-modal" hidden role="dialog" aria-modal="true" aria-label="Captar fotografia" style="position:fixed;inset:0;background:#0b1c2de6;z-index:9999;align-items:center;justify-content:center;padding:20px">
                    <div style="background:white;border-radius:14px;padding:18px;width:min(560px,100%);display:grid;gap:12px;color:#162b3e">
                        <h3 style="margin:0">Captar fotografia</h3>
                        <label for="foto-camera-dispositivo" style="display:block;margin:8px 0">Câmara disponível <select id="foto-camera-dispositivo" style="max-width:100%;margin-left:8px;padding:7px"><option value="">Câmara predefinida</option></select></label>
                        <video id="foto-camera-video" autoplay playsinline muted style="width:100%;border-radius:9px;background:#101820;max-height:60vh"></video>
                        <div style="display:flex;gap:10px;flex-wrap:wrap">
                            <button type="button" class="btn btn-primary" id="foto-camera-capturar">Capturar fotografia</button>
                            <button type="button" class="btn btn-secondary" id="foto-camera-fechar">Cancelar</button>
                        </div>
                    </div>
                </div>

                <div class="campo col-2">

                    <label>
                        Nome completo
                        <span class="obrigatorio">*</span>
                    </label>

                    <input
                        type="text"
                        name="nome_completo"
                        value="<?= htmlspecialchars($dados['nome_completo']) ?>"
                        required
                    >

                </div>


                <div class="campo">

                    <label>Sexo</label>

                    <select name="id_sexo">

                        <option value="">Selecionar</option>

                        <?php foreach ($sexos as $item): ?>

                            <option
                                value="<?= $item['id_sexo'] ?>"
                                <?= $dados['id_sexo'] == $item['id_sexo'] ? 'selected' : '' ?>
                            >

                                <?= htmlspecialchars($item['nome']) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="campo">

                    <label>Data de nascimento</label>

                    <input
                        type="date"
                        name="data_nascimento"
                        value="<?= htmlspecialchars($dados['data_nascimento']) ?>"
                    >

                </div>


                <div class="campo">

                    <label>Estado civil</label>

                    <select name="id_estado_civil">

                        <option value="">Selecionar</option>

                        <?php foreach ($estados_civis as $item): ?>

                            <option
                                value="<?= $item['id_estado_civil'] ?>"
                                <?= $dados['id_estado_civil'] == $item['id_estado_civil'] ? 'selected' : '' ?>
                            >

                                <?= htmlspecialchars($item['nome']) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="campo">
                    <label>Grupo sanguíneo</label>
                    <select name="id_grupo_sanguineo">
                        <option value="">Selecionar</option>
                        <?php foreach ($gruposSanguineos as $gs): ?>
                            <option value="<?= (int)$gs['id_grupo_sanguineo'] ?>" <?= (string)$dados['id_grupo_sanguineo']===(string)$gs['id_grupo_sanguineo']?'selected':'' ?>><?= htmlspecialchars($gs['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label>Peso (kg)</label>
                    <input type="number" name="peso_kg" min="1" max="500" step="0.01" value="<?= htmlspecialchars($dados['peso_kg']) ?>">
                </div>

                <div class="campo">

                    <label>Nacionalidade</label>

                    <?php $paisAngola = $pdo->query("SELECT id_pais FROM paises WHERE codigo='AO' LIMIT 1")->fetchColumn(); ?>
                    <select name="id_pais_nacionalidade">
                        <option value="<?= (int)$paisAngola ?>" selected>Angolana</option>
                    </select>

                </div>


                <div class="campo">

                    <label>País de nascimento</label>

                    <select name="id_pais_nascimento">

                        <option value="">Selecionar</option>

                        <?php foreach ($paises as $item): ?>

                            <option
                                value="<?= $item['id_pais'] ?>"
                                <?= $dados['id_pais_nascimento'] == $item['id_pais'] ? 'selected' : '' ?>
                            >

                                <?= htmlspecialchars($item['nome']) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="campo">
                    <label>Província de nascimento</label>
                    <select name="id_provincia_nascimento" id="id_provincia_nascimento">
                        <option value="">Selecionar</option>
                        <?php foreach ($provincias as $item): ?>
                        <option value="<?= $item['id_provincia'] ?>" data-pais="<?= $item['id_pais'] ?>" <?= $dados['id_provincia_nascimento']==$item['id_provincia']?'selected':'' ?>><?= htmlspecialchars($item['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="campo">
                    <label>Município de nascimento</label>
                    <select name="id_municipio_nascimento" id="id_municipio_nascimento">
                        <option value="">Selecionar</option>
                        <?php foreach ($municipios as $item): ?>
                        <option value="<?= $item['id_municipio'] ?>" data-provincia="<?= $item['id_provincia'] ?>" <?= $dados['id_municipio_nascimento']==$item['id_municipio']?'selected':'' ?>><?= htmlspecialchars($item['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </section>


        <!-- DOCUMENTO DE IDENTIFICAÇÃO -->

        <section class="form-section">

            <h2>Bilhete de Identidade</h2>

            <div class="form-grid">

                <div class="campo">

                    <label>Número do BI</label>

                    <input
                        type="text"
                        name="numero_bi"
                        value="<?= htmlspecialchars($dados['numero_bi']) ?>"
                    >

                </div>


                <div class="campo">

                    <label>Data de emissão</label>

                    <input
                        type="date"
                        name="data_emissao_bi"
                        value="<?= htmlspecialchars($dados['data_emissao_bi']) ?>"
                    >

                </div>


                <div class="campo">

                    <label>Data de validade</label>

                    <input
                        type="date"
                        name="data_validade_bi"
                        value="<?= htmlspecialchars($dados['data_validade_bi']) ?>"
                    >

                </div>


                <div class="campo">
                    <label>Local de emissão</label>
                    <select name="local_emissao_bi">
                        <option value="">Selecionar</option>
                        <?php foreach ($provincias as $item): ?>
                            <option value="<?= htmlspecialchars($item['nome']) ?>" <?= $dados['local_emissao_bi'] === $item['nome'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($item['nome']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </section>


        <!-- CONTACTOS -->

        <section class="form-section">

            <h2>Contactos</h2>

            <div class="form-grid">

                <div class="campo">
                    <label>Telefone</label>
                    <input type="text" name="telefone" value="<?= htmlspecialchars($dados['telefone']) ?>">
                </div>

                <div class="campo">
                    <label>Número alternativo</label>
                    <input type="text" name="telefone_alternativo" value="<?= htmlspecialchars($dados['telefone_alternativo']) ?>">
                </div>

                <div class="campo">
                    <label>Email</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($dados['email']) ?>">
                </div>


                

            </div>

        </section>


        <!-- RESIDÊNCIA -->
        <section class="form-section">
            <h2>Dados de Residência</h2>
            <p class="form-help">Todos estes campos são opcionais.</p>
            <div class="form-grid">
                <div class="campo"><label>Província</label><select name="id_provincia_residencia" id="id_provincia_residencia"><option value="">Selecionar</option><?php foreach($provincias as $item): ?><option value="<?= $item['id_provincia'] ?>"><?= htmlspecialchars($item['nome']) ?></option><?php endforeach; ?></select></div>
                <div class="campo"><label>Município</label><select name="id_municipio_residencia" id="id_municipio_residencia"><option value="">Selecionar</option><?php foreach($municipios as $item): ?><option value="<?= $item['id_municipio'] ?>" data-provincia="<?= $item['id_provincia'] ?>"><?= htmlspecialchars($item['nome']) ?></option><?php endforeach; ?></select></div>
                <div class="campo"><label>Bairro</label><input name="bairro" value="<?= htmlspecialchars($dados['bairro']) ?>"></div>
                <div class="campo"><label>Rua</label><input name="rua" value="<?= htmlspecialchars($dados['rua']) ?>"></div>
                <div class="campo"><label>Casa</label><input name="casa" value="<?= htmlspecialchars($dados['casa']) ?>"></div>
                <div class="campo"><label>Ponto de referência</label><input name="ponto_referencia" value="<?= htmlspecialchars($dados['ponto_referencia']) ?>"></div>
            </div>
        </section>

        <!-- DADOS DE SERVIÇO -->

        <section class="form-section">

            <h2 id="titulo-dados-servico"><?= $tipoEspecialista === 'CIVIL' ? 'Dados de Serviço' : 'Dados de Incorporação' ?></h2>

            <div class="form-grid">
                <div class="campo campo-no-civil" data-civil="1">
                    <label>NO</label><input type="text" name="no_civil" maxlength="50" value="<?= htmlspecialchars($dados['no_civil'], ENT_QUOTES, 'UTF-8') ?>">
                </div>
                <div class="campo campo-categoria-civil" data-civil="1">
                    <label>Categoria</label>
                    <select name="id_categoria_civil">
                        <option value="">Selecionar</option>
                        <?php foreach ($categoriasCivis as $cat): ?>
                        <option value="<?= (int)$cat['id_categoria_civil'] ?>" <?= (string)$dados['id_categoria_civil']===(string)$cat['id_categoria_civil']?'selected':'' ?>><?= htmlspecialchars($cat['nome'],ENT_QUOTES,'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo" data-militar="1">

                    <label>
                        Ramo
                        <span class="obrigatorio">*</span>
                    </label>

                    <select
                        name="id_ramo"
                        id="id_ramo"
                        required
                    >

                        <option value="">Selecionar</option>

                        <?php foreach ($ramos as $item): ?>

                            <option
                                value="<?= $item['id_ramo'] ?>"
                                <?= $dados['id_ramo'] == $item['id_ramo'] ? 'selected' : '' ?>
                            >

                                <?= htmlspecialchars($item['nome']) ?>

                                <?php if ($item['sigla']): ?>
                                    (<?= htmlspecialchars($item['sigla']) ?>)
                                <?php endif; ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="campo" data-militar="1">

                    <label>
                        Forma de Prestação de Serviço (FPS)
                        </label>

                    <select
                        name="id_quadro"
                    >

                        <option value="">Selecionar</option>

                        <?php foreach ($quadros as $item): ?>

                            <option
                                value="<?= $item['id_quadro'] ?>"
                                data-quadro-nome="<?= htmlspecialchars($item['nome'], ENT_QUOTES, 'UTF-8') ?>"
                                <?= $dados['id_quadro'] == $item['id_quadro'] ? 'selected' : '' ?>
                            >

                                <?= htmlspecialchars($item['nome']) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="campo" data-militar="1">

                    <label>Patente</label>

                    <select name="id_patente" id="id_patente">

                        <option value="">
                            Selecionar
                        </option>

                    </select>

                    <small>
                        A patente será carregada de acordo com o ramo.
                    </small>

                </div>




                <div class="campo"><label>Local de serviço *</label>
                    <select name="local_servico" id="local_servico" required>
                    <option value="">Selecionar</option>
                    <?php foreach (['EMG','EXE','FAN','MGA'] as $local): ?>
                    <option value="<?= $local ?>" <?= $dados['local_servico']===$local?'selected':'' ?>><?= $local ?></option>
                    <?php endforeach; ?>
                    </select>
                </div>
                <div class="campo" id="campo-nip">

                    <label>NIP <span class="obrigatorio nip-obrigatorio">*</span></label>

                    <input
                        type="text"
                        name="nip"
                        value="<?= htmlspecialchars($dados['nip']) ?>"
                    >

                </div><div class="campo">

                    <label>Número de processo</label>

                    <input
                        type="text"
                        name="numero_processo"
                        value="<?= htmlspecialchars($dados['numero_processo']) ?>"
                    >

                </div>
<div class="campo">

                    <label>Data de incorporação</label>

                    <input
                        type="date"
                        name="data_incorporacao"
                        value="<?= htmlspecialchars($dados['data_incorporacao']) ?>"
                    >

                </div>


                <div class="campo campo-local-incorporacao">
                    <label>Local de incorporação</label>
                    <input type="text" name="local_incorporacao" maxlength="200" value="<?= htmlspecialchars($dados['local_incorporacao'] ?? '') ?>" placeholder="Local onde foi incorporado">
                </div>

                <div class="campo">

                    <label>Data de promoção</label>

                    <input
                        type="date"
                        name="data_promocao"
                        value="<?= htmlspecialchars($dados['data_promocao']) ?>"
                    >

                </div>


                <div class="campo">

                    <label>Função</label>

                    <select name="id_funcao">

                        <option value="">Selecionar</option>

                        <?php foreach ($funcoes as $item): ?>

                            <option
                                value="<?= $item['id_funcao'] ?>"
                                <?= $dados['id_funcao'] == $item['id_funcao'] ? 'selected' : '' ?>
                            >

                                <?= htmlspecialchars($item['nome']) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="campo">

                    <label>Unidade</label>

                    <select name="id_unidade">

                        <option value="">Selecionar</option>

                        <?php foreach ($unidades as $item): ?>

                            <option
                                value="<?= $item['id_unidade'] ?>"
                                data-ramo="<?= $item['id_ramo'] ?>"
                                <?= $dados['id_unidade'] == $item['id_unidade'] ? 'selected' : '' ?>
                            >

                                <?= htmlspecialchars($item['nome']) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="campo">
                    <label>Região</label>
                    <select name="id_regiao">
                        <option value="">Selecionar</option>
                        <?php foreach($regioes as $rg): ?>
                        <option value="<?= $rg['id_regiao'] ?>" <?= $dados['id_regiao']==$rg['id_regiao']?'selected':'' ?>><?= htmlspecialchars($rg['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="campo">
                    <label>Departamento</label>
                    <select name="id_departamento" id="id_departamento">
                        <option value="">Selecionar</option>
                        <?php foreach($departamentos as $item): ?>
                        <option value="<?= $item['id_departamento'] ?>" data-unidade="<?= $item['id_unidade'] ?>" <?= $dados['id_departamento']==$item['id_departamento']?'selected':'' ?>><?= htmlspecialchars($item['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>


                <div class="campo">

                    <label>Estado</label>

                    <select name="id_situacao_servico">

                        <option value="">Selecionar</option>

                        <optgroup label="Ativo">
                        <?php foreach ($situacoes as $item): if($item['grupo']!=='ATIVO') continue; ?>
                            <option value="<?= $item['id_situacao_servico'] ?>" <?= $dados['id_situacao_servico'] == $item['id_situacao_servico'] ? 'selected' : '' ?>><?= htmlspecialchars($item['nome']) ?></option>
                        <?php endforeach; ?>
                        </optgroup>
                        <optgroup label="Inativo">
                        <?php foreach ($situacoes as $item): if($item['grupo']!=='INATIVO') continue; ?>
                            <option value="<?= $item['id_situacao_servico'] ?>" <?= $dados['id_situacao_servico'] == $item['id_situacao_servico'] ? 'selected' : '' ?>><?= htmlspecialchars($item['nome']) ?></option>
                        <?php endforeach; ?>
                        </optgroup>

                    </select>

                </div>


                <div class="campo">

                    <label>Início da função</label>

                    <input
                        type="date"
                        name="data_inicio_funcao"
                        value="<?= htmlspecialchars($dados['data_inicio_funcao']) ?>"
                    >

                </div>

            </div>

        </section>        <!-- OBSERVAÇÕES -->

        <section class="form-section">

            <h2>Observações</h2>

            <div class="campo">

                <textarea
                    name="observacoes"
                    placeholder="Observações gerais sobre o especialista..."
                ><?= htmlspecialchars($dados['observacoes']) ?></textarea>

            </div>

        </section>



        <div class="acoes-final">

            <a
                href="especialistas.php"
                class="btn btn-secondary"
            >
                Cancelar
            </a>

            <button
                type="submit"
                class="btn btn-primary"
            >
                Guardar pré-cadastro
            </button>

        </div>

    </form>

</main>


<script>

/*
|--------------------------------------------------------------------------
| Carregar patentes conforme o ramo
|--------------------------------------------------------------------------
*/

const ramo = document.getElementById('id_ramo');
const patente = document.getElementById('id_patente');

async function carregarPatentes() {

    const idRamo = ramo.value;

    patente.innerHTML =
        '<option value="">A carregar...</option>';

    if (!idRamo) {

        patente.innerHTML =
            '<option value="">Selecionar</option>';

        return;
    }

    try {

        const resposta = await fetch(
            '../configuracoes/api_patentes.php?id_ramo=' +
            encodeURIComponent(idRamo)
        );

        const dados = await resposta.json();

        patente.innerHTML =
            '<option value="">Selecionar</option>';

        dados.forEach(function(item) {

            const option =
                document.createElement('option');

            option.value = item.id_patente;

            option.textContent =
                item.nome +
                (item.sigla
                    ? ' (' + item.sigla + ')'
                    : '');

            patente.appendChild(option);

        });

    } catch (erro) {

        patente.innerHTML =
            '<option value="">Erro ao carregar</option>';

    }

}

ramo.addEventListener('change', function(){carregarPatentes();filtrarUnidades();});
const paisNascimento=document.querySelector('[name=\"id_pais_nascimento\"]'), provincia=document.getElementById('id_provincia_nascimento'), municipio=document.getElementById('id_municipio_nascimento');
function filtrarProvincias(){const p=paisNascimento?.value||'';Array.from(provincia.options).forEach(o=>{if(!o.value)return;o.hidden=o.dataset.pais!==p;o.disabled=o.hidden;});if(provincia.selectedOptions[0]?.hidden)provincia.value='';filtrarMunicipios();}
function filtrarMunicipios(){const p=provincia?.value||'';Array.from(municipio.options).forEach(o=>{if(!o.value)return;o.hidden=o.dataset.provincia!==p;o.disabled=o.hidden;});if(municipio.selectedOptions[0]?.hidden)municipio.value='';}
paisNascimento?.addEventListener('change',filtrarProvincias);provincia?.addEventListener('change',filtrarMunicipios);
const unidade=document.querySelector('[name=\"id_unidade\"]'), departamento=document.getElementById('id_departamento');
function filtrarUnidades(){const r=document.getElementById('tipo_especialista')?.value==='CIVIL'?'':ramo.value;Array.from(unidade.options).forEach(o=>{if(!o.value)return;o.hidden=!!r&&o.dataset.ramo!==r;o.disabled=o.hidden;});if(unidade.selectedOptions[0]?.hidden)unidade.value='';filtrarDepartamentos();}
function filtrarDepartamentos(){const u=unidade.value;Array.from(departamento.options).forEach(o=>{if(!o.value)return;o.hidden=o.dataset.unidade!==u;o.disabled=o.hidden;});if(departamento.selectedOptions[0]?.hidden)departamento.value='';}
unidade?.addEventListener('change',filtrarDepartamentos);filtrarProvincias();filtrarUnidades();

const quadroSelect=document.querySelector('[name="id_quadro"]'),campoNip=document.getElementById('campo-nip'),nipInput=document.querySelector('[name="nip"]');
function atualizarNipPorQuadro(){if(!quadroSelect||!campoNip||!nipInput)return;const o=quadroSelect.options[quadroSelect.selectedIndex],civil=!!o&&/civil/i.test(o.dataset.quadroNome||o.textContent||'');campoNip.hidden=civil;nipInput.required=!civil;if(civil)nipInput.value='';}
quadroSelect?.addEventListener('change',atualizarNipPorQuadro);atualizarNipPorQuadro();

</script>
</div>

<script>
(function(){
 const normal=document.getElementById('fotografia_inicial'),camera=document.getElementById('fotografia_camera');
 const previa=document.getElementById('foto-previa-inicial'),nome=document.getElementById('foto-nome-selecionado');
 const vazio=document.getElementById('foto-cadastro-placeholder'), remover=document.getElementById('btn-remover-fotografia');
 let urlAnterior=null;
 function atualizar(){
   const f=normal?.files?.[0];
   if(urlAnterior){URL.revokeObjectURL(urlAnterior);urlAnterior=null;}
   if(!f){previa.style.display='none';previa.removeAttribute('src');vazio.style.display='flex';remover.style.display='none';nome.textContent='JPG, PNG ou WEBP · Máximo 8 MB';return;}
   if(!['image/jpeg','image/png','image/webp'].includes(f.type)||f.size>8*1024*1024){
      alert('Selecione uma imagem JPG, PNG ou WEBP até 8 MB.');normal.value='';atualizar();return;
   }
   nome.textContent=f.name;urlAnterior=URL.createObjectURL(f);previa.src=urlAnterior;previa.style.display='block';vazio.style.display='none';remover.style.display='inline-flex';
 }
 const modal=document.getElementById('foto-camera-modal'),video=document.getElementById('foto-camera-video');
 let cameraStream=null;
 const dispositivo=document.getElementById('foto-camera-dispositivo');
 function fecharStream(){if(cameraStream){cameraStream.getTracks().forEach(t=>t.stop());cameraStream=null;}video.srcObject=null;}
 function fecharCamera(){fecharStream();modal.hidden=true;modal.style.display='none';}
 async function iniciarCamera(id=''){
   fecharStream();
   const constraints=id?{deviceId:{exact:id}}:{facingMode:'user'};
   cameraStream=await navigator.mediaDevices.getUserMedia({video:constraints,audio:false});
   video.srcObject=cameraStream;modal.hidden=false;modal.style.display='flex';await video.play();
   const devices=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='videoinput');
   const atual=cameraStream.getVideoTracks()[0]?.getSettings()?.deviceId||id;
   dispositivo.replaceChildren();
   devices.forEach((d,i)=>{const o=document.createElement('option');o.value=d.deviceId;o.textContent=d.label||'Câmara '+(i+1);dispositivo.appendChild(o);});
   if(atual)dispositivo.value=atual;
 }
 dispositivo?.addEventListener('change',async()=>{try{await iniciarCamera(dispositivo.value);}catch(e){alert('Não foi possível ativar este dispositivo de vídeo.');}});
 document.getElementById('btn-fazer-fotografia')?.addEventListener('click',async()=>{
   if(!navigator.mediaDevices?.getUserMedia){alert('Câmara indisponível. Utilize HTTPS ou localhost, ou selecione uma fotografia.');camera?.click();return;}
   try{await iniciarCamera();}catch(e){alert('Não foi possível abrir a câmara. Confirme a ligação e a permissão de acesso.');camera?.click();}
 });
 document.getElementById('foto-camera-fechar')?.addEventListener('click',fecharCamera);
 document.getElementById('foto-camera-capturar')?.addEventListener('click',()=>{
   if(!cameraStream||!video.videoWidth)return;
   const canvas=document.createElement('canvas');canvas.width=video.videoWidth;canvas.height=video.videoHeight;
   canvas.getContext('2d').drawImage(video,0,0);
   canvas.toBlob(blob=>{
     if(!blob)return;
     try{const file=new File([blob],'fotografia_'+Date.now()+'.jpg',{type:'image/jpeg'});const transfer=new DataTransfer();transfer.items.add(file);normal.files=transfer.files;atualizar();fecharCamera();}
     catch(e){alert('Não foi possível guardar a fotografia. Utilize Selecionar fotografia.');}
   },'image/jpeg',.88);
 });
 window.addEventListener('pagehide',fecharCamera);
 camera?.addEventListener('change',()=>{
  if(!camera.files?.length||!normal)return;
  try{const transfer=new DataTransfer();transfer.items.add(camera.files[0]);normal.files=transfer.files;atualizar();}
  catch(e){nome.textContent='Use o botão Selecionar fotografia para enviar a imagem.';}
 });
 remover?.addEventListener('click',()=>{normal.value='';camera.value='';atualizar();});
 normal?.addEventListener('change',atualizar);
})();
(function(){const p=document.getElementById('id_provincia_residencia'),m=document.getElementById('id_municipio_residencia');if(!p||!m)return;function f(){const v=p.value;[...m.options].forEach(o=>{if(!o.dataset.provincia)return;o.hidden=!!v&&o.dataset.provincia!==v;if(o.hidden)o.selected=false;});}p.addEventListener('change',f);f();})();

(function(){var iban=document.querySelector('input[name="iban"]');if(iban){function format(){var v=iban.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,34);iban.value=v.replace(/(.{4})/g,'$1 ').trim();}iban.addEventListener('input',format);iban.addEventListener('blur',format);}})();
</script>
<script>
(function(){
 const hiddenType=document.getElementById('tipo_especialista');
 document.querySelectorAll('.tipo-especialista-switch .tipo-btn').forEach(function(btn){
   btn.addEventListener('click',function(ev){
     ev.preventDefault(); const tipo=this.dataset.tipo;
     hiddenType.value=tipo;
     document.querySelectorAll('.tipo-especialista-switch .tipo-btn').forEach(b=>b.classList.toggle('ativo',b===btn));
     const title=document.querySelector('#form-pre-cadastro .form-section h2');
     if(title) title.textContent=tipo==='CIVIL'?'Dados do Especialista Civil':'Dados do Especialista Militar';
     document.getElementById('titulo-dados-servico').textContent=tipo==='CIVIL'?'Dados de Serviço':'Dados de Incorporação';
     form?.classList.toggle('tipo-civil',tipo==='CIVIL');
     if(typeof filtrarUnidades==='function')filtrarUnidades();
     for(const key of ['id_ramo','id_quadro']) {const el=document.querySelector('[name="'+key+'"]');if(el){el.required=tipo==='MILITAR';if(tipo==='CIVIL')el.value='';}}
     const nip=document.querySelector('[name="nip"]'),patente=document.querySelector('[name="id_patente"]');
     if(nip){nip.required=false;if(tipo==='CIVIL')nip.value='';}
     if(patente && tipo==='CIVIL')patente.value='';
     const nipWrap=document.getElementById('campo-nip');
     const patenteWrap=patente?.closest('.campo');
     if(nipWrap)nipWrap.style.display=tipo==='CIVIL'?'none':'';
     if(patenteWrap)patenteWrap.style.display=tipo==='CIVIL'?'none':'';
     const requiredMark=document.querySelector('.nip-obrigatorio');
     if(nip){nip.required=tipo==='MILITAR';if(tipo==='CIVIL')nip.value='';}
     if(requiredMark)requiredMark.style.display=tipo==='MILITAR'?'inline':'none';
   });
 });
 const nipInput=document.querySelector('[name="nip"]');
 const requiredMark=document.querySelector('.nip-obrigatorio');
 if(nipInput){nipInput.required=hiddenType.value==='MILITAR';}
 const nipWrap=document.getElementById('campo-nip'); const patenteWrap=document.getElementById('id_patente')?.closest('.campo');
 if(nipWrap)nipWrap.style.display=hiddenType.value==='CIVIL'?'none':''; if(patenteWrap)patenteWrap.style.display=hiddenType.value==='CIVIL'?'none':'';
 if(requiredMark)requiredMark.style.display=hiddenType.value==='MILITAR'?'inline':'none';
 const form=document.getElementById('form-pre-cadastro');
 if(form){
   form.classList.add('pre-cadastro-resumido');
   form.classList.toggle('tipo-civil',hiddenType.value==='CIVIL');
   for(const key of ['id_ramo','id_quadro']) {const el=form.querySelector('[name="'+key+'"]');if(el)el.required=hiddenType.value==='MILITAR';}

 }
})();
</script>
<?php require __DIR__ . '/../../layout/footer.php'; ?>
