<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/patentes_visual.php';
require_login(); require_permission('ESPECIALISTAS_VISUALIZAR');


$pdo = db();

// A BD pode conservar caminhos de fotografias cujos ficheiros foram movidos.
// Neste caso, apresentar ícone neutro em vez do texto ALT de uma imagem partida.
function foto_especialista_disponivel(?string $caminho): bool {
    if (!$caminho) return false;
    $caminho = str_replace('\\', '/', trim($caminho));
    if (preg_match('~^(?:https?://|//)~i', $caminho)) return false;
    return is_file(app_public_path($caminho));
}


$params = [];
$where = scope_sql($params, 'e', 'especialista');

$pesquisa = trim($_GET['pesquisa'] ?? '');
$ramoFiltro = (int)($_GET['ramo'] ?? 0);
$localServicoFiltro = strtoupper(trim($_GET['local_servico'] ?? ''));
if (!in_array($localServicoFiltro,['EMG','EXE','FAN','MGA'],true)) $localServicoFiltro='';
$unidadeFiltro = (int)($_GET['unidade'] ?? 0);
$quadro = (int)($_GET['fps'] ?? $_GET['quadro'] ?? 0);
$categoria = (int)($_GET['categoria'] ?? 0);
$situacao = (int)($_GET['situacao'] ?? 0);
$regiao = (int)($_GET['regiao'] ?? 0);
$grau = (int)($_GET['grau'] ?? 0);
$licencaAtual = ($_GET['licenca_atual'] ?? '') === '1';
$patenteFiltro=(int)($_GET['patente']??0);
$grupoFiltro=(string)($_GET['grupo_hierarquico']??'');
$gruposPatente=['OFICIAIS_GENERAIS'=>'Oficiais Generais','OFICIAIS_SUPERIORES'=>'Oficiais Superiores','OFICIAIS_CAPITAES'=>'Oficiais Capitães','OFICIAIS_SUBALTERNOS'=>'Oficiais Subalternos','SARGENTOS'=>'Sargentos','PRACAS'=>'Praças'];
if(!array_key_exists($grupoFiltro,$gruposPatente)) $grupoFiltro='';
$tipo = strtoupper(trim($_GET['tipo'] ?? ''));
if (!in_array($tipo, ['MILITAR','CIVIL'], true)) $tipo = '';

if ($tipo !== '') { $where .= ' AND e.tipo_especialista = ?'; $params[] = $tipo; }

if ($pesquisa !== '') {
    $where .= " AND (
        dp.nome_completo LIKE ?
        OR ds.nip LIKE ?
        OR ds.no_civil LIKE ?
        OR dp.numero_bi LIKE ?
    )";

    $termo = '%' . $pesquisa . '%';

    $params[] = $termo;
    $params[] = $termo;
    $params[] = $termo;
    $params[] = $termo;
}

if ($patenteFiltro > 0 && $tipo !== 'CIVIL') {
    // Patentes equivalentes entre ramos possuem a mesma ordem hierárquica.
    $where .= ' AND e.id_patente IN (SELECT pe.id_patente FROM patentes pe WHERE (pe.id_patente=? OR (pe.codigo_equivalencia IS NOT NULL AND pe.codigo_equivalencia=(SELECT pa.codigo_equivalencia FROM patentes pa WHERE pa.id_patente=?))))';
    $params[]=$patenteFiltro; $params[]=$patenteFiltro;
}

if ($grupoFiltro !== '' && $tipo !== 'CIVIL') {
    $where .= ' AND EXISTS (SELECT 1 FROM patentes pg WHERE pg.id_patente=e.id_patente AND pg.grupo_hierarquico=?)';
    $params[]=$grupoFiltro;
}

if ($ramoFiltro > 0) {
    $where .= ' AND e.id_ramo = ?';
    $params[] = $ramoFiltro;
}

if ($unidadeFiltro > 0) { $where .= ' AND ds.id_unidade = ?'; $params[] = $unidadeFiltro; }

if ($localServicoFiltro !== '') {
    $where .= " AND ds.local_servico = ?";
    $params[] = $localServicoFiltro;
}

if ($tipo === 'MILITAR' && $quadro > 0) {
    $where .= " AND e.id_quadro = ?";
    $params[] = $quadro;
}

if ($situacao > 0) {
    $where .= " AND ds.id_situacao_servico = ?";
    $params[] = $situacao;
}

if ($regiao > 0) {
    $where .= " AND ds.id_regiao = ?";
    $params[] = $regiao;
}

if ($tipo === 'CIVIL' && $categoria > 0) { $where .= ' AND e.id_categoria_civil = ?'; $params[] = $categoria; }
if ($licencaAtual) {
    $where .= " AND EXISTS (SELECT 1 FROM licencas li WHERE li.id_especialista=e.id_especialista AND CURRENT_DATE BETWEEN li.data_inicio AND li.data_fim AND li.estado NOT IN ('CANCELADA','CONCLUIDA'))";
}
if ($grau > 0) {
    $where .= " AND EXISTS (SELECT 1 FROM habilitacoes_literarias hl WHERE hl.id_especialista=e.id_especialista AND hl.id_nivel_habilitacao=?)";
    $params[] = $grau;
}


/*
|--------------------------------------------------------------------------
| Dados dos filtros
|--------------------------------------------------------------------------
*/

$ramos = $pdo->query("
    SELECT id_ramo, nome, sigla
    FROM ramo
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);

$patentesFiltro=$pdo->query("SELECT id_patente,nome,ordem,id_ramo FROM patentes WHERE estado='ATIVO' ORDER BY ordem,nome")->fetchAll(PDO::FETCH_ASSOC);
$modelosLista=$pdo->query("SELECT codigo,titulo,colunas FROM modelos_listas WHERE estado='ATIVO' ORDER BY id_modelo")->fetchAll(PDO::FETCH_ASSOC);
$unidadesFiltro = $pdo->query("SELECT id_unidade, nome, sigla FROM unidades WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$categoriasCivis = $pdo->query("SELECT id_categoria_civil,nome FROM categorias_civis WHERE estado='ATIVO' ORDER BY ordem,nome")->fetchAll(PDO::FETCH_ASSOC);
$quadros = $pdo->query("
    SELECT id_quadro, nome, sigla
    FROM quadros_servico
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);

$situacoes = $pdo->query("
    SELECT id_situacao_servico, nome, grupo
    FROM situacoes_servico
    WHERE estado = 'ATIVO'
    ORDER BY nome
")->fetchAll(PDO::FETCH_ASSOC);

$regioes = $pdo->query("SELECT id_regiao,nome FROM regioes WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$graus = $pdo->query("SELECT id_nivel_habilitacao,nome FROM niveis_habilitacao WHERE estado='ATIVO' ORDER BY ordem,nome")->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| Especialistas
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        e.id_especialista,
        e.id_ramo,
        e.id_quadro,
        e.id_patente,
        e.tipo_especialista,
        e.estado,

        (
            SELECT f.caminho_ficheiro
            FROM fotografias f
            WHERE f.id_especialista = e.id_especialista
            ORDER BY f.principal DESC, f.data_registo DESC, f.id_fotografia DESC
            LIMIT 1
        ) AS foto_caminho,

        dp.nome_completo,
        dp.numero_bi,
        dp.telefone,
        dp.telefone_alternativo,

        r.nome AS ramo_nome,
        r.sigla AS ramo_sigla,
        r.cor_principal AS ramo_cor,

        q.nome AS quadro_nome,
        q.sigla AS quadro_sigla,

        cat.nome AS categoria_nome,
        p.nome AS patente_nome,
        p.sigla AS patente_sigla,
        p.imagem_insignia AS patente_insignia,

        ds.nip,
        ds.no_civil,
        ds.local_servico,
        ds.id_unidade,
        ds.id_regiao,
        ds.id_situacao_servico,

        u.nome AS unidade_nome,
        u.sigla AS unidade_sigla,

        ss.nome AS situacao_nome,
        ss.grupo AS situacao_grupo

    FROM especialistas e

    INNER JOIN dados_pessoais dp
        ON dp.id_especialista = e.id_especialista

    LEFT JOIN ramo r
        ON r.id_ramo = e.id_ramo

    LEFT JOIN quadros_servico q
        ON q.id_quadro = e.id_quadro

    LEFT JOIN categorias_civis cat ON cat.id_categoria_civil=e.id_categoria_civil

    LEFT JOIN patentes p
        ON p.id_patente = e.id_patente

    LEFT JOIN dados_servico ds
        ON ds.id_especialista = e.id_especialista

    LEFT JOIN unidades u
        ON u.id_unidade = ds.id_unidade

    LEFT JOIN situacoes_servico ss
        ON ss.id_situacao_servico = ds.id_situacao_servico

    WHERE $where

    ORDER BY COALESCE(p.ordem, 999999) ASC, dp.nome_completo ASC
";

$pesquisaExecutada = (isset($_GET['pesquisa']) || isset($_GET['local_servico']) || isset($_GET['ramo']) || isset($_GET['quadro']) || isset($_GET['situacao']) || isset($_GET['regiao']) || isset($_GET['grau']) || isset($_GET['categoria']) || isset($_GET['fps']) || isset($_GET['unidade']) || isset($_GET['licenca_atual']) || isset($_GET['patente']) || isset($_GET['grupo_hierarquico']));
$especialistas = [];
if ($pesquisaExecutada) {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $especialistas = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
if (isset($_GET['imprimir_lista']) && $pesquisaExecutada) {
    $codigo=(string)($_GET['modelo_lista']??'efetividade');
    $modeloEscolhido=null;
    foreach($modelosLista as $m) if($m['codigo']===$codigo) {$modeloEscolhido=$m;break;}
    if (!$modeloEscolhido) $modeloEscolhido=$modelosLista[0]??null;
    if (!$modeloEscolhido) {http_response_code(400);exit('Configure primeiro um modelo de impressão.');}
    $mapa=[
       'nome'=>['Nome','nome_completo'], 'bi'=>['BI','numero_bi'],
       'identificador'=>[$tipo==='MILITAR'?'NIP':($tipo==='CIVIL'?'NO':'NIP / NO'),null], 'ramo'=>['Ramo','ramo_sigla'],
       'local'=>['Local de Serviço','local_servico'],'unidade'=>['Unidade','unidade_nome'],
       'estado'=>['Estado','situacao_nome'], 'patente'=>['Patente','patente_nome'], 'categoria'=>['Categoria','categoria_nome']
    ];
    $colunas=array_values(array_filter(explode(',',$modeloEscolhido['colunas']),fn($c)=>isset($mapa[$c])));
    $filtrosDescricao=[];
    $filtrosDescricao[]='Tipo: '.($tipo==='MILITAR'?'Militar':($tipo==='CIVIL'?'Civil':'Todos'));
    if($ramoFiltro)foreach($ramos as $r)if((int)$r['id_ramo']===$ramoFiltro){$filtrosDescricao[]='Ramo: '.$r['sigla'];break;}
    if($localServicoFiltro)$filtrosDescricao[]='Local: '.$localServicoFiltro;
    if($unidadeFiltro)foreach($unidadesFiltro as $u)if((int)$u['id_unidade']===$unidadeFiltro){$filtrosDescricao[]='Unidade: '.$u['nome'];break;}
    if($patenteFiltro)foreach($patentesFiltro as $p)if((int)$p['id_patente']===$patenteFiltro){$filtrosDescricao[]='Patente: '.$p['nome'];break;}
    if($quadro && $tipo==='MILITAR')foreach($quadros as $q)if((int)$q['id_quadro']===$quadro){$filtrosDescricao[]='FPS: '.$q['nome'];break;}
    if($situacao)foreach($situacoes as $si)if((int)$si['id_situacao_servico']===$situacao){$filtrosDescricao[]='Estado: '.$si['nome'];break;}
    if($licencaAtual)$filtrosDescricao[]='Licença em vigor';
    if($pesquisa!=='')$filtrosDescricao[]='Pesquisa: '.$pesquisa;
    $filtrosDescricao[]='Total: '.count($especialistas);
    $filtrosTexto=implode(' | ',$filtrosDescricao).' | Emitido: '.date('d/m/Y H:i');
    if (($_GET['formato']??'')==='pdf') {
       require_once __DIR__ . '/../../../app/exportar_pdf.php';
       $titulo=($tipo==='MILITAR'?'Militares':($tipo==='CIVIL'?'Civis':'Especialistas'));
       $filtros=$filtrosTexto;
       exportar_lista_pdf($especialistas,$colunas,$mapa,$titulo,$filtros);
    }
    if (($_GET['formato']??'')==='docx') {
        if(!class_exists('ZipArchive')){http_response_code(501);exit('Ative a extensão PHP zip no XAMPP para exportar DOCX.');}
        $zip=new ZipArchive();$tmp=tempnam(sys_get_temp_dir(),'sge_docx_');
        if(!$tmp || $zip->open($tmp,ZipArchive::OVERWRITE)!==true){http_response_code(500);exit('Não foi possível criar o documento.');}
        $esc=static fn($v)=>htmlspecialchars((string)$v,ENT_XML1|ENT_QUOTES,'UTF-8');
        $rows='';$headings=['N.º'];foreach($colunas as $c)$headings[]=$mapa[$c][0];
        $docrow=static function($vals)use($esc){$z='<w:tr>';foreach($vals as $v)$z.='<w:tc><w:p><w:r><w:t xml:space="preserve">'.$esc($v).'</w:t></w:r></w:p></w:tc>';return $z.'</w:tr>';};
        $rows.=$docrow($headings);
        foreach($especialistas as $i=>$esp){$values=[(string)($i+1)];foreach($colunas as $c){$values[]=(string)($c==='identificador' ? ($esp['tipo_especialista']==='CIVIL'?$esp['no_civil']:$esp['nip']) : ($esp[$mapa[$c][1]]??'—'));}$rows.=$docrow($values);}
        $heading='SGE TELECOM — '.($tipo==='MILITAR'?'Militares':($tipo==='CIVIL'?'Civis':'Todos os especialistas'));
        $body='<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>'.$esc($heading).'</w:t></w:r></w:p>';
        $body.='<w:p><w:r><w:t>'.$esc($filtrosTexto).'</w:t></w:r></w:p>';
        $body.='<w:tbl>'.$rows.'</w:tbl>';
        $zip->addFromString('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');
        $zip->addFromString('_rels/.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
        $zip->addFromString('word/document.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'.$body.'<w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/></w:sectPr></w:body></w:document>');
        $zip->close(); header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');header('Content-Disposition: attachment; filename="lista_especialistas.docx"'); header('Content-Length: '.filesize($tmp));readfile($tmp);unlink($tmp);exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    $h = static fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html lang="pt"><head><meta charset="utf-8"><title>'.$h($modeloEscolhido['titulo']).'</title><style>body{font:12px Arial,sans-serif;padding:25px;color:#172b3a}h1{font-size:20px}.meta{margin:12px 0 20px;color:#566}table{width:100%;border-collapse:collapse}th,td{border:1px solid #bbc8d0;padding:7px;text-align:left}th{background:#eef3f6}@page{size:A4 landscape;margin:14mm}@media print{button{display:none}}</style></head><body>';
    $titulosFiltros=[];
    $tipos=['MILITAR'=>'Militares','CIVIL'=>'Civis'];
    $titulosFiltros[]=$tipos[$tipo]??'Todos os Especialistas';
    if($ramoFiltro){foreach($ramos as $r)if((int)$r['id_ramo']===$ramoFiltro){$titulosFiltros[]='Ramo '.$r['sigla'];break;}}
    if($localServicoFiltro)$titulosFiltros[]='Local '.$localServicoFiltro;
    if($unidadeFiltro){foreach($unidadesFiltro as $un)if((int)$un['id_unidade']===$unidadeFiltro){$titulosFiltros[]='Unidade '.$un['nome'];break;}}
    if($situacao){foreach($situacoes as $si)if((int)$si['id_situacao_servico']===$situacao){$titulosFiltros[]=$si['nome'];break;}}
    if($licencaAtual)$titulosFiltros[]='Licença em vigor';
    if($grupoFiltro) $titulosFiltros[]='Nível Hierárquico: '.$gruposPatente[$grupoFiltro];
    if($patenteFiltro){foreach($patentesFiltro as $pt)if((int)$pt['id_patente']===$patenteFiltro){$titulosFiltros[]='Patente (equivalentes): '.$pt['nome'];break;}}
    if($pesquisa!=='')$titulosFiltros[]='Pesquisa: '.$pesquisa;
    echo '<h1>SGE TELECOM — '.$h(implode(' · ',$titulosFiltros)).'</h1>';
    echo '<div class="meta">Tipo: '.$h($tipo ?: 'Todos').' | Local de Serviço: '.$h($localServicoFiltro ?: 'Todos').' | Total: '.count($especialistas).' | Emitido em: '.date('d/m/Y H:i').'</div>';
    echo '<table><thead><tr><th>N.º</th>';
    foreach($colunas as $c) echo '<th>'.$h($mapa[$c][0]).'</th>';
    echo '</tr></thead><tbody>';
    foreach ($especialistas as $i => $esp) {
        echo '<tr><td>'.($i+1).'</td>';
        foreach($colunas as $c) {
            $v=$c==='identificador' ? ($esp['tipo_especialista']==='CIVIL' ? $esp['no_civil'] : $esp['nip']) : ($esp[$mapa[$c][1]]??'');
            echo '<td>'.$h($v?:'—').'</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></body></html>';
    exit;
}
$page_title = "Especialistas";
$returnTo=$_SERVER['REQUEST_URI']??'especialistas.php';
require __DIR__ . '/../../layout/header.php';
?>

<div class="module-page module-especialistas">
<style>
.module-especialistas .page-header{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;margin-bottom:24px}
.module-especialistas .page-header h1{margin:0;font-size:34px}
.module-especialistas .page-header p{margin:7px 0 0;color:var(--suave)}
.module-especialistas .filtros{background:var(--superficie);border:1px solid var(--borda);border-radius:14px;padding:18px 20px;margin-bottom:18px;box-shadow:var(--sombra)}
.module-especialistas .filtros-grid{display:grid;grid-template-columns:minmax(220px,2fr) repeat(5,minmax(130px,1fr)) minmax(170px,auto);gap:12px;align-items:end}
.module-especialistas .campo{min-width:0;display:flex;flex-direction:column;gap:6px}.module-especialistas .campo label{font-size:12px;font-weight:700;color:var(--texto)}
.module-especialistas .campo input,.module-especialistas .campo select{width:100%;height:42px;padding:0 11px;border:1px solid var(--borda);border-radius:9px;background:var(--superficie);color:var(--texto);outline:none}
.module-especialistas .campo input:focus,.module-especialistas .campo select:focus{border-color:#5b8fb5;box-shadow:0 0 0 3px rgba(31,95,139,.10)}
.module-especialistas .filtro-acoes{display:grid;grid-template-columns:1fr 1fr;gap:8px}.module-especialistas .filtro-acoes .btn{height:42px;padding:0 12px;white-space:nowrap}
.module-especialistas .contador{margin:0 0 9px;color:var(--suave);font-size:13px}
.module-especialistas .tabela-container{border:1px solid var(--borda);border-radius:14px;background:var(--superficie);box-shadow:var(--sombra);overflow:auto}
.module-especialistas table{width:100%;min-width:1100px;border-collapse:collapse;border-spacing:0;table-layout:fixed;font-size:13px}
.module-especialistas th,.module-especialistas td{padding:11px 10px;border-bottom:1px solid var(--borda);box-sizing:border-box;text-align:left;vertical-align:middle;overflow:hidden;text-overflow:ellipsis}
.module-especialistas th{height:48px;background:var(--azul-suave);color:var(--texto);font-size:12px;font-weight:750;white-space:nowrap;position:sticky;top:0;z-index:4}
.module-especialistas tbody tr:last-child td{border-bottom:0}.module-especialistas tbody tr:hover td{background:color-mix(in srgb,var(--azul-suave) 45%,var(--superficie))}
.module-especialistas th:nth-child(1),.module-especialistas td:nth-child(1){width:86px;background:var(--superficie)}
.module-especialistas th:nth-child(2),.module-especialistas td:nth-child(2){width:220px;background:var(--superficie)}
.module-especialistas th:nth-child(3),.module-especialistas td:nth-child(3){width:100px}.module-especialistas th:nth-child(4),.module-especialistas td:nth-child(4){width:105px}.module-especialistas th:nth-child(5),.module-especialistas td:nth-child(5){width:105px}.module-especialistas th:nth-child(6),.module-especialistas td:nth-child(6){width:110px}.module-especialistas th:nth-child(7),.module-especialistas td:nth-child(7){width:125px}.module-especialistas th:nth-child(8),.module-especialistas td:nth-child(8){width:105px}.module-especialistas th:nth-child(9),.module-especialistas td:nth-child(9){width:150px;background:var(--superficie)}
.module-especialistas thead th:nth-child(1),.module-especialistas thead th:nth-child(2),.module-especialistas thead th:nth-child(9){z-index:4;background:var(--azul-suave)}
.module-especialistas .celula-foto{text-align:center}.module-especialistas .foto-slot{width:62px;height:62px;display:inline-flex;align-items:center;justify-content:center;overflow:hidden;flex-wrap:nowrap;border-radius:12px;border:1px solid var(--borda);background:#edf2f5;vertical-align:middle}.module-especialistas .foto-lista{width:100%;height:100%;display:block;object-fit:cover;object-position:center top;background:#edf2f5;color:#7d8a95}.module-especialistas .foto-vazia{display:flex;align-items:center;justify-content:center;font-size:24px;line-height:1;color:#6f5aa8}.module-especialistas .nome{display:block;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.module-especialistas .subtexto{display:block;color:var(--suave);font-size:10px;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.module-especialistas .sigla-cell{display:inline-block;font-weight:700;letter-spacing:.02em}.module-especialistas .sigla-cell:hover{text-decoration:underline}.module-especialistas .celula-acoes{width:126px}.module-especialistas .acoes{display:flex;align-items:center;justify-content:center;gap:7px;white-space:nowrap;min-height:36px}.module-especialistas .acoes .btn{height:34px;padding:0 12px;font-size:11px;border-radius:8px;min-width:54px}
.module-especialistas .badge{display:inline-flex;align-items:center;padding:4px 7px;border-radius:999px;font-size:10px;font-weight:750;white-space:nowrap}.module-especialistas .badge-ativo{background:#dff5e5;color:#18723a}.module-especialistas .badge-inativo{background:#f3dddd;color:#9b2c2c}.module-especialistas .vazio{padding:38px;text-align:center;color:var(--suave)}
html.modo-escuro .module-especialistas th:nth-child(1),html.modo-escuro .module-especialistas td:nth-child(1),html.modo-escuro .module-especialistas th:nth-child(2),html.modo-escuro .module-especialistas td:nth-child(2),html.modo-escuro .module-especialistas th:nth-child(9),html.modo-escuro .module-especialistas td:nth-child(9){background:var(--superficie)}
@media(max-width:1100px){.module-especialistas th:nth-child(9),.module-especialistas td:nth-child(9){position:sticky;right:0;z-index:3}.module-especialistas thead th:nth-child(9){z-index:5}.module-especialistas .filtros-grid{grid-template-columns:2fr 1fr 1fr}.module-especialistas .filtro-acoes{grid-column:1/-1;max-width:300px}}
@media(max-width:700px){.module-especialistas .page-header{align-items:flex-start;flex-direction:column}.module-especialistas .filtros-grid{grid-template-columns:1fr}.module-especialistas .filtro-acoes{grid-column:auto;max-width:none}}
 .lista-tipos{margin:14px 0}.lista-tipos .tipo-btn{display:inline-flex;align-items:center;padding:9px 18px;border:1px solid #cbd5e1;border-radius:8px;text-decoration:none;font-weight:700;color:var(--texto,#243447);background:var(--superficie,#fff)}.lista-tipos .tipo-btn.ativo{background:#164e78;color:#fff;border-color:#164e78}
</style>
    <div class="page-header">

        <div>

            <h1>Especialistas</h1>

            <p>
                Gestão e consulta do cadastro de especialistas.
            </p>

        </div>

        <a
            href="especialista_novo.php"
            class="btn btn-primary"
        >
            + Novo Especialista
        </a>

    </div>


    <!-- FILTROS -->

    <div class="tipo-especialista-switch lista-tipos">
        <a class="tipo-btn <?= $tipo === '' ? 'ativo' : '' ?>" href="especialistas.php">Todos</a>
        <a class="tipo-btn <?= $tipo === 'MILITAR' ? 'ativo' : '' ?>" href="especialistas.php?tipo=MILITAR">Militar</a>
        <a class="tipo-btn <?= $tipo === 'CIVIL' ? 'ativo' : '' ?>" href="especialistas.php?tipo=CIVIL">Civil</a>
    </div>
    <form
        method="get"
        class="filtros"
    >
        <?php if ($tipo !== ''): ?><input type="hidden" name="tipo" value="<?= htmlspecialchars($tipo) ?>"><?php endif; ?>

        <div class="filtros-grid">

            <div class="campo">

                <label>Pesquisa</label>

                <input
                    type="text"
                    name="pesquisa"
                    value="<?= htmlspecialchars($pesquisa) ?>"
                    placeholder="<?= $tipo === 'CIVIL' ? 'Nome, BI ou NO' : ($tipo === 'MILITAR' ? 'Nome, BI ou NIP' : 'Nome, BI, NIP ou NO') ?>"
                >

            </div>


            <div class="campo filtro-militar">
                <label>Ramo</label>
                <select name="ramo">
                    <option value="">Todos</option>
                    <?php foreach ($ramos as $item): ?>
                    <option value="<?= (int)$item['id_ramo'] ?>" <?= $ramoFiltro === (int)$item['id_ramo'] ? 'selected' : '' ?>><?= htmlspecialchars($item['nome'], ENT_QUOTES, 'UTF-8') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">

                <label>Local de Serviço</label>
                <select name="local_servico"><option value="">Todos</option>
                <?php foreach (['EMG','EXE','FAN','MGA'] as $local): ?>
                <option value="<?= $local ?>" <?= $localServicoFiltro===$local?'selected':'' ?>><?= $local ?></option>
                <?php endforeach; ?>
                </select>

            </div>


            <div class="campo filtro-militar"><label>Nível Hierárquico</label>
               <select name="grupo_hierarquico"><option value="">Todos os Níveis</option>
               <?php foreach($gruposPatente as $codigo=>$nome): ?><option value="<?=htmlspecialchars($codigo)?>" <?=$grupoFiltro===$codigo?'selected':''?>><?=htmlspecialchars($nome)?></option><?php endforeach;?></select>
            </div>
            <div class="campo filtro-militar"><label>Patente (e equivalentes)</label>
               <select name="patente"><option value="">Todas</option>
               <?php foreach($patentesFiltro as $pt): ?><option value="<?=(int)$pt['id_patente']?>" <?=$patenteFiltro===(int)$pt['id_patente']?'selected':''?>><?=htmlspecialchars($pt['nome'],ENT_QUOTES,'UTF-8')?></option><?php endforeach;?></select>
            </div>
            <div class="campo filtro-militar">

                <label>Forma de Prestação de Serviço (FPS)</label>

                <select name="fps">

                    <option value="">Todos</option>

                    <?php foreach ($quadros as $item): ?>

                        <option
                            value="<?= $item['id_quadro'] ?>"
                            <?= $quadro == $item['id_quadro'] ? 'selected' : '' ?>
                        >

                            <?= htmlspecialchars($item['nome']) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="campo">

                <label>Estado</label>

                <select name="situacao">

                    <option value="">Todas</option>

                    <?php foreach ($situacoes as $item): ?>

                        <option
                            value="<?= $item['id_situacao_servico'] ?>"
                            <?= $situacao == $item['id_situacao_servico'] ? 'selected' : '' ?>
                        >

                            <?= htmlspecialchars($item['nome']) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="campo">
                <label>Unidade</label>
                <select name="unidade"><option value="">Todas</option>
                <?php foreach ($unidadesFiltro as $un): ?>
                <option value="<?= (int)$un['id_unidade'] ?>" <?= $unidadeFiltro === (int)$un['id_unidade'] ? 'selected' : '' ?>><?= htmlspecialchars($un['nome'], ENT_QUOTES, 'UTF-8') ?></option>
                <?php endforeach; ?>
                </select>
            </div>

            <div class="campo filtro-militar">
                <label>Região</label>
                <select name="regiao"><option value="">Todas</option><?php foreach($regioes as $rg): ?><option value="<?=$rg['id_regiao']?>" <?=$regiao===$rg['id_regiao']?'selected':''?>><?=htmlspecialchars($rg['nome'])?></option><?php endforeach; ?></select>
            </div>
            <div class="campo">
                <label>Grau Académico</label>
                <select name="grau"><option value="">Todos</option><?php foreach($graus as $g): ?><option value="<?=$g['id_nivel_habilitacao']?>" <?=$grau===$g['id_nivel_habilitacao']?'selected':''?>><?=htmlspecialchars($g['nome'])?></option><?php endforeach; ?></select>
            </div>

            <div class="campo"><label>Licença Atual</label><select name="licenca_atual"><option value="">Todas</option><option value="1" <?= $licencaAtual?'selected':'' ?>>Com licença em vigor</option></select></div>

            <div class="campo filtro-civil"><label>Categoria</label><select name="categoria"><option value="">Todas</option><?php foreach($categoriasCivis as $cat): ?><option value="<?= (int)$cat['id_categoria_civil'] ?>" <?= $categoria===(int)$cat['id_categoria_civil']?'selected':'' ?>><?= htmlspecialchars($cat['nome'],ENT_QUOTES,'UTF-8') ?></option><?php endforeach; ?></select></div>

            <div class="filtro-acoes">
                <button type="submit" class="btn btn-primary">Pesquisar</button>
                <a href="especialistas.php<?= $tipo ? '?tipo='.urlencode($tipo) : '' ?>" class="btn btn-secondary">Limpar</a>
            </div>

        </div>


    </form>
<style>.filtro-civil{display:none!important}.barra-resultados-imprimir{display:flex;justify-content:flex-end;align-items:center;gap:12px;margin:15px 0 6px;flex-wrap:wrap;font-size:13px;color:var(--suave,#64748b)}.barra-resultados-imprimir .btn{padding:9px 13px;font-size:13px}</style>
<?php if ($tipo !== 'MILITAR'): ?><style>.filtro-militar{display:none!important}</style><?php endif; ?>
<?php if ($tipo==='CIVIL'): ?><style>.filtro-civil{display:flex!important}</style><?php endif; ?>

    <?php if ($pesquisaExecutada && $especialistas): ?>
    <div class="barra-resultados-imprimir">
      <span><?= count($especialistas) ?> resultado(s) para os filtros aplicados</span>
      <button type="button" class="btn btn-secondary" onclick="abrirImpressaoResultados()">🖨 Imprimir</button>
    </div>
    <?php endif; ?>
    <?php if ($pesquisaExecutada && $especialistas): ?>
    <div id="modalImpressaoResultados" class="sge-print-overlay" hidden role="dialog" aria-modal="true" aria-label="Pré-visualização dos resultados">
      <div class="sge-print-dialog">
        <div class="sge-print-head"><strong>Pré-visualização dos Resultados</strong><button type="button" onclick="fecharImpressaoResultados()" aria-label="Fechar">✕</button></div>
        <div class="sge-print-tools"><label for="formatoResultado">Formato</label><select id="formatoResultado"><option value="pdf">PDF</option><option value="docx">Word (DOCX)</option></select><button type="button" class="btn btn-primary" onclick="exportarResultados()">Descarregar</button><button type="button" class="btn btn-secondary" onclick="imprimirResultadosNaPagina()">Imprimir</button></div>
        <iframe id="quadroImpressaoResultados" title="Pré-visualização da lista de especialistas"></iframe>
      </div>
    </div>
    <style>.sge-print-overlay[hidden]{display:none!important}.sge-print-overlay{position:fixed!important;inset:0!important;z-index:2147483000!important;background:#0b20378c;display:grid;place-items:center;padding:18px}.sge-print-dialog{display:flex;flex-direction:column;width:min(1120px,calc(100vw - 24px));height:min(850px,calc(100dvh - 24px));max-width:100%;background:#fff;color:#172b3a;border-radius:16px;overflow:hidden;box-shadow:0 25px 80px #09152d55}.sge-print-head,.sge-print-tools{display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid #dce5ed;flex-wrap:wrap}.sge-print-head{justify-content:space-between}.sge-print-head button{background:#edf1f5;border:0;border-radius:8px;cursor:pointer;padding:8px 13px}.sge-print-tools select{padding:10px;border:1px solid #cedae6;border-radius:8px;background:#fff}.sge-print-dialog iframe{width:100%;flex:1;border:0;background:white}</style>
    <script>
    const sgeUrlListaPreview=<?=json_encode('?'.http_build_query(array_merge(array_diff_key($_GET,['imprimir_lista'=>1,'formato'=>1,'modelo_lista'=>1]),['imprimir_lista'=>1,'formato'=>'preview'])),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;
    const sgeUrlListaExport=<?=json_encode('?'.http_build_query(array_merge(array_diff_key($_GET,['imprimir_lista'=>1,'formato'=>1,'modelo_lista'=>1]),['imprimir_lista'=>1])),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;
    function abrirImpressaoResultados(){document.body.appendChild(document.getElementById('modalImpressaoResultados'));document.getElementById('modalImpressaoResultados').hidden=false;document.getElementById('quadroImpressaoResultados').src=sgeUrlListaPreview;}
    function fecharImpressaoResultados(){document.getElementById('modalImpressaoResultados').hidden=true;document.getElementById('quadroImpressaoResultados').src='about:blank';}
    function exportarResultados(){let f=document.getElementById('formatoResultado').value;let a=document.createElement('a');a.href=sgeUrlListaExport+'&formato='+encodeURIComponent(f);a.download='';document.body.appendChild(a);a.click();a.remove();}
    function imprimirResultadosNaPagina(){let frame=document.getElementById('quadroImpressaoResultados');try{frame.contentWindow.focus();frame.contentWindow.print();}catch(e){alert('Não foi possível iniciar a impressão.');}}
    document.getElementById('modalImpressaoResultados').addEventListener('click',e=>{if(e.target.id==='modalImpressaoResultados')fecharImpressaoResultados()});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!document.getElementById('modalImpressaoResultados').hidden)fecharImpressaoResultados()});
    </script>
    <?php endif; ?>
    <div class="contador">

        <?= count($especialistas) ?>

        especialista(s) encontrado(s)

    </div>


    <!-- TABELA -->

    <div class="tabela-container">

        <?php if (!$especialistas): ?>

            <div class="vazio">

                <?= $pesquisaExecutada ? 'Nenhum especialista encontrado com os critérios indicados.' : 'Utilize os filtros acima e clique em Pesquisar para consultar os especialistas.' ?>

            </div>

        <?php else: ?>

            <table>

                <thead>

                    <tr>

                        <th class="col-foto">Foto</th>
                        <th>Especialista</th>
                        <th><?= $tipo==='MILITAR'?'NIP':($tipo==='CIVIL'?'NO':'NIP / NO') ?></th>
                        <th>Patente</th>

                        <th>Ramo</th>

                        <th>FPS</th>

                        <th>Unidade</th>

                        <th>Estado</th>

                        <th>Ações</th>

                    </tr>

                </thead>

                <tbody>

                <?php foreach ($especialistas as $item): ?>
                    <?php
                        $ramoCorLinha = trim((string)($item['ramo_cor'] ?? ''));
                        if (strtoupper((string)($item['ramo_sigla'] ?? '')) === 'MGA' && in_array(strtolower($ramoCorLinha), ['#ffffff','#fff','#fefefe'], true)) $ramoCorLinha = '#a9bdcc';
                        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $ramoCorLinha)) $ramoCorLinha = '#1f5f8b';
                    ?>
                    <tr class="especialista-row" style="--ramo-cor:<?= htmlspecialchars($ramoCorLinha, ENT_QUOTES, 'UTF-8') ?>;">

                        <td class="celula-foto">
                            <span class="foto-slot">
                            <?php if (foto_especialista_disponivel($item['foto_caminho'] ?? null)): ?>
                                <img class="foto-lista"
                                     src="<?= htmlspecialchars(app_file_url($item['foto_caminho'])) ?>"
                                     alt="Fotografia de <?= htmlspecialchars($item['nome_completo']) ?>"
                                     onerror="this.parentNode.innerHTML='&lt;span class=&quot;foto-lista foto-vazia&quot; aria-label=&quot;Fotografia indisponível&quot;&gt;👤&lt;/span&gt;';">
                            <?php else: ?>
                                <span class="foto-lista foto-vazia" aria-label="Fotografia indisponível">👤</span>
                            <?php endif; ?>
                            </span>
                        </td>

                        <td>
                            <span class="nome">
                                <?= htmlspecialchars($item['nome_completo']) ?>
                            </span>

                            <?php if (!empty($item['numero_bi'])): ?>

                                <span class="subtexto">

                                    BI:
                                    <?= htmlspecialchars(
                                        $item['numero_bi']
                                    ) ?>

                                </span>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?= htmlspecialchars($item['tipo_especialista'] === 'CIVIL' ? ($item['no_civil'] ?? '—') : ($item['nip'] ?? '—')) ?>

                        </td>


                        <td title="<?= htmlspecialchars($item['patente_nome'] ?? '—') ?>">
                            <?php $imgPatente=imagem_patente_resolvida($item['patente_insignia']??null,$item['ramo_sigla']??null,$item['patente_nome']??null);if($imgPatente): ?><img src="<?=htmlspecialchars(app_file_url($imgPatente))?>" alt="Insígnia da patente" style="height:1em;width:1.2em;object-fit:contain;vertical-align:-0.12em;margin-right:5px"><?php endif; ?><span class="sigla-cell"><?= htmlspecialchars($item['patente_sigla'] ?: ($item['patente_nome'] ?? '—')) ?></span>
                        </td>


                        <td title="<?= htmlspecialchars($item['ramo_nome']) ?>">
                            <span class="sigla-cell ramo-badge" style="--ramo-cor:<?= htmlspecialchars($ramoCorLinha, ENT_QUOTES, 'UTF-8') ?>;"><?= htmlspecialchars($item['ramo_sigla'] ?: $item['ramo_nome']) ?></span>
                        </td>


                        <td title="<?= htmlspecialchars($item['quadro_nome']) ?>">
                            <span class="sigla-cell"><?= htmlspecialchars($item['quadro_sigla'] ?: $item['quadro_nome']) ?></span>
                        </td>


                        <td title="<?= htmlspecialchars($item['unidade_nome'] ?? '—') ?>">
                            <span class="sigla-cell"><?= htmlspecialchars($item['unidade_sigla'] ?: ($item['unidade_nome'] ?? '—')) ?></span>
                        </td>


                        <td>

                            <?php if (
                                ($item['situacao_grupo'] ?? '') === 'ATIVO'
                            ): ?>

                                <span class="badge badge-ativo">

                                    <?= htmlspecialchars(
                                        $item['situacao_nome'] ?? 'ATIVO'
                                    ) ?>

                                </span>

                            <?php else: ?>

                                <span class="badge badge-inativo">

                                    <?= htmlspecialchars(
                                        $item['situacao_nome'] ?? 'INATIVO'
                                    ) ?>

                                </span>

                            <?php endif; ?>

                        </td>


                        <td class="celula-acoes">
                            <div class="acoes">
                                <a
                                    href="especialista.php?id=<?= (int)$item['id_especialista'] ?>"
                                    class="btn btn-secondary btn-small"
                                >
                                    Ver
                                </a>

                                <?php if (user_can_edit_specialist((int)$item['id_especialista'])): ?>
                                <a
                                    href="especialista_editar.php?id=<?= (int)$item['id_especialista'] ?>&return_to=<?=urlencode($returnTo)?>"
                                    class="btn btn-primary btn-small"
                                >
                                    Editar
                                </a>
                                <?php endif; ?>
                            </div>
                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        <?php endif; ?>

    </div>

</div>

<?php require __DIR__ . '/../../layout/footer.php'; ?>
