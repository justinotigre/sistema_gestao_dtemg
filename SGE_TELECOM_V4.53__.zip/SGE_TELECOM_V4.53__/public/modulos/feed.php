<?php
require_once __DIR__ . '/../../app/auth.php';
require_login();
$pdo = db();
$gruposPatente=['OFICIAIS_GENERAIS'=>'Oficiais Generais','OFICIAIS_SUPERIORES'=>'Oficiais Superiores','OFICIAIS_CAPITAES'=>'Oficiais Capitães','OFICIAIS_SUBALTERNOS'=>'Oficiais Subalternos','SARGENTOS'=>'Sargentos','PRACAS'=>'Praças'];
try { $pdo->exec("CREATE TABLE IF NOT EXISTS feed_permissoes_perfil (id_perfil INT NOT NULL PRIMARY KEY, pode_ler TINYINT(1) NOT NULL DEFAULT 1, pode_publicar TINYINT(1) NOT NULL DEFAULT 0, pode_submeter TINYINT(1) NOT NULL DEFAULT 1, pode_gerir TINYINT(1) NOT NULL DEFAULT 0, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch(Throwable $e) {}
$secao = (string)($_GET['secao'] ?? 'feed');
if (!in_array($secao, ['feed','oportunidades','comunicados'], true)) $secao = 'feed';
$tipoSecao = ['feed'=>'PUBLICACAO','oportunidades'=>null,'comunicados'=>'COMUNICADO'][$secao];
$u = $_SESSION['user'] ?? [];
$nivel = (string)($u['nivel'] ?? '');
$perfil = mb_strtolower((string)($u['perfil'] ?? ''), 'UTF-8');
$ehAdminGeral = $nivel === 'GLOBAL' && (str_contains($perfil,'admin') || str_contains($perfil,'administr'));
$ehAdminRamo = $nivel === 'RAMO' && (str_contains($perfil,'admin') || str_contains($perfil,'administr'));
$ehAdminRH = (str_contains($perfil,'rh') || str_contains($perfil,'recursos humanos') || str_contains($perfil,'humanos')) && (str_contains($perfil,'admin') || str_contains($perfil,'administr'));
$ehAdminRM = (str_contains($perfil,'rm') || str_contains($perfil,'recursos materiais') || str_contains($perfil,'materiais')) && (str_contains($perfil,'admin') || str_contains($perfil,'administr'));
$podePublicar = $ehAdminGeral || $ehAdminRamo || $ehAdminRH || $ehAdminRM;
$podeLer = true; $podeSubmeter = true; $podeGerir = $podePublicar;
try { $stPerm=$pdo->prepare('SELECT f.pode_ler,f.pode_publicar,f.pode_submeter,f.pode_gerir FROM utilizadores u LEFT JOIN feed_permissoes_perfil f ON f.id_perfil=u.id_perfil WHERE u.id_utilizador=?'); $stPerm->execute([current_user_id()]); $permFeed=$stPerm->fetch(PDO::FETCH_ASSOC); if($permFeed && $permFeed['pode_ler']!==null){$podeLer=(bool)$permFeed['pode_ler'];$podePublicar=(bool)$permFeed['pode_publicar'];$podeSubmeter=(bool)$permFeed['pode_submeter'];$podeGerir=(bool)$permFeed['pode_gerir'];} } catch(Throwable $e) {}
if(!$podeLer){http_response_code(403); exit('Não tem permissão para ler o Feed e as comunicações.');}
$areasPermitidas = $ehAdminGeral || $ehAdminRamo ? ['RH','RM','TODOS'] : ($ehAdminRH ? ['RH','TODOS'] : ($ehAdminRM ? ['RM','TODOS'] : []));
if ($podePublicar && !$areasPermitidas) { if (has_permission('ESPECIALISTAS_VISUALIZAR')) $areasPermitidas[]='RH'; if (has_permission('EQUIPAMENTOS_VISUALIZAR')) $areasPermitidas[]='RM'; $areasPermitidas[]='TODOS'; }
$erro = ''; $sucesso = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify_post();
    $acao = (string)($_POST['acao'] ?? '');
    if ($acao === 'eliminar_publicacao' && $podeGerir) {
        $idEliminar=(int)($_POST['id_publicacao']??0);
        try {
            $st=$pdo->prepare("SELECT id_publicacao FROM feed_publicacoes WHERE id_publicacao=? AND estado='ATIVO'");
            $st->execute([$idEliminar]);
            if (!$st->fetchColumn()) { $erro='A publicação já não existe ou foi removida.'; }
            else {
                // Eliminação lógica: preservar candidaturas, leituras, avaliações e anexos.
                // Não apagar ficheiros nem destruir registos relacionados.
                $del=$pdo->prepare("UPDATE feed_publicacoes SET estado='INATIVO' WHERE id_publicacao=? AND estado='ATIVO'");
                $del->execute([$idEliminar]);
                $sucesso=$del->rowCount()?'Publicação removida do Feed com sucesso.':'A publicação já se encontrava removida.';
            }
        } catch(Throwable $e) { error_log('SGE Feed eliminar: '.$e->getMessage()); $erro='Não foi possível remover a publicação. Verifique o registo de erros do PHP e a estrutura de feed_publicacoes.'; }
    } elseif ($acao === 'publicar' && $podePublicar) {
        $titulo = trim((string)($_POST['titulo'] ?? ''));
        $conteudo = trim((string)($_POST['conteudo'] ?? ''));
        $area = strtoupper(trim((string)($_POST['area'] ?? 'TODOS')));
        $tipo = $secao === 'oportunidades' ? 'OPORTUNIDADE' : ($secao === 'comunicados' ? 'COMUNICADO' : 'PUBLICACAO');
        $dataLimite = trim((string)($_POST['data_limite'] ?? ''));
        if ($titulo === '' || $conteudo === '') $erro = $secao === 'oportunidades' ? 'Preencha o título e a descrição/requisitos da oportunidade.' : 'Preencha o título e o conteúdo.';
        elseif ($nivel === 'RAMO' && count(current_user_branch_ids()) !== 1) $erro = 'O administrador de ramo deve ter exatamente um ramo associado para publicar comunicados com âmbito seguro.';
        elseif (!in_array($area, $areasPermitidas, true)) $erro = 'Não tem autorização para publicar nesta área.';
        else {
            try {
                $pdo->beginTransaction();
                $st = $pdo->prepare('INSERT INTO feed_publicacoes (titulo,conteudo,area,tipo,data_limite,id_autor,id_ramo,criado_em,estado) VALUES (?,?,?,?,?,?,?,?,?,?)');
                $ramos = current_user_branch_ids();
                $ramo = ($nivel === 'RAMO' && count($ramos) === 1) ? $ramos[0] : null;
                $st->execute([$titulo,$conteudo,$area,$tipo,$dataLimite !== '' ? $dataLimite : null,current_user_id(),$ramo,date('Y-m-d H:i:s'),'ATIVO']);
                $idPub = (int)$pdo->lastInsertId();
                if($secao==='oportunidades') {
                    $crit=(string)($_POST['tipo_especialista_criterio']??'');
                    $tipoCrit=in_array($crit,['MILITAR','CIVIL'],true)?$crit:null;
                    $locCrit=(string)($_POST['local_servico_criterio']??'');
                    $locCrit=in_array($locCrit,['EMG','EXE','FAN','MGA'],true)?$locCrit:null;
                    $ramoCrit=(int)($_POST['id_ramo_criterio']??0);
                    $patCrit=(int)($_POST['id_patente_criterio']??0);
                    $nivelCrit=(int)($_POST['id_nivel_habilitacao']??0);
                    $idadeMin=($_POST['idade_minima']??'')!==''?(int)$_POST['idade_minima']:null;
                    $idadeMax=($_POST['idade_maxima']??'')!==''?(int)$_POST['idade_maxima']:null;
                    if($idadeMin!==null && $idadeMax!==null && $idadeMin>$idadeMax) throw new RuntimeException('A idade mínima não pode exceder a máxima.');
                    $critSql=$pdo->prepare('INSERT INTO feed_oportunidade_config (id_publicacao,id_ramo_criterio,id_patente_criterio,grupo_hierarquico_criterio,id_nivel_habilitacao,idade_minima,idade_maxima,tipo_especialista_criterio,local_servico_criterio,atualizado_por) VALUES (?,?,?,?,?,?,?,?,?,?)');
                    $critSql->execute([$idPub,$ramoCrit?:null,$patCrit?:null,array_key_exists((string)($_POST['grupo_hierarquico_criterio']??''),$gruposPatente)?(string)$_POST['grupo_hierarquico_criterio']:null,$nivelCrit?:null,$idadeMin,$idadeMax,$tipoCrit,$locCrit,current_user_id()]);
                }

                $pdo->commit();
                $anexosFalhados = []; $anexosGuardados = 0;
                // Anexos: armazenar apenas tipos permitidos, com nome aleatório e limite de 15 MB por ficheiro.
                if (!empty($_FILES['anexos']['name']) && is_array($_FILES['anexos']['name'])) {
                    $dirUploads = __DIR__ . '/../uploads/feed';
                    if (!is_dir($dirUploads)) @mkdir($dirUploads, 0750, true);
                    $permitidos = [
                        'image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp',
                        'audio/mpeg'=>'mp3','audio/mp4'=>'m4a','audio/wav'=>'wav','audio/x-wav'=>'wav','audio/ogg'=>'ogg','audio/webm'=>'webm',
                        'application/pdf'=>'pdf','application/msword'=>'doc','application/vnd.openxmlformats-officedocument.wordprocessingml.document'=>'docx',
                        'application/vnd.ms-excel'=>'xls','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'=>'xlsx',
                        'application/vnd.ms-powerpoint'=>'ppt','application/vnd.openxmlformats-officedocument.presentationml.presentation'=>'pptx','text/plain'=>'txt'
                    ];
                    $finfo = new finfo(FILEINFO_MIME_TYPE);
                    $n = min(count($_FILES['anexos']['name']), 5);
                    for ($i=0; $i<$n; $i++) {
                        if (($_FILES['anexos']['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) { $anexosFalhados[] = 'Ficheiro '.($i+1).': erro de envio (verifique upload_max_filesize e post_max_size).'; continue; }
                        $tmp = $_FILES['anexos']['tmp_name'][$i] ?? '';
                        $size = (int)($_FILES['anexos']['size'][$i] ?? 0);
                        if (!$tmp || $size < 1 || $size > 15*1024*1024 || !is_uploaded_file($tmp)) { $anexosFalhados[]='Ficheiro '.($i+1).': vazio ou acima de 15 MB.'; continue; }
                        $mime = $finfo->file($tmp);
                        if (!isset($permitidos[$mime]) || !is_dir($dirUploads) || !is_writable($dirUploads)) { $anexosFalhados[]='Ficheiro '.($i+1).': formato não permitido ou pasta de anexos sem escrita.'; continue; }
                        $nomeGuardado = bin2hex(random_bytes(18)).'.'.$permitidos[$mime];
                        if (move_uploaded_file($tmp, $dirUploads.'/'.$nomeGuardado)) {
                            try {
                                $an = $pdo->prepare('INSERT INTO feed_anexos (id_publicacao,nome_original,nome_guardado,mime_type,tamanho_bytes) VALUES (?,?,?,?,?)');
                                $nomeOriginal = basename((string)($_FILES['anexos']['name'][$i] ?? 'anexo'));
                                $an->execute([$idPub,mb_substr($nomeOriginal,0,240,'UTF-8'),$nomeGuardado,$mime,$size]); $anexosGuardados++;
                            } catch (Throwable $e) { @unlink($dirUploads.'/'.$nomeGuardado); $anexosFalhados[]='Ficheiro '.($i+1).': não foi possível registar na base de dados.'; }
                        } else { $anexosFalhados[]='Ficheiro '.($i+1).': falha ao mover para a pasta de destino.'; }
                    }
                }
                $sucesso = 'Publicação criada. '.$anexosGuardados.' anexo(s) guardado(s).';
                if ($anexosFalhados) $erro=implode(' ', $anexosFalhados);
            } catch (Throwable $e) {if($pdo->inTransaction())$pdo->rollBack();error_log('SGE publicar: '.$e->getMessage()); $erro = 'Não foi possível publicar. Verifique os critérios e execute a migração V4.47 das Formações.'; }
        }
    } elseif ($acao === 'guardar_criterios' && $podeGerir) {
        $idPub=(int)($_POST['id_publicacao']??0);
        $chk=$pdo->prepare("SELECT tipo FROM feed_publicacoes WHERE id_publicacao=? AND estado='ATIVO'"); $chk->execute([$idPub]); $tipoPub=(string)$chk->fetchColumn();
        if($idPub<1 || !in_array($tipoPub,['CURSO','OPORTUNIDADE'],true)) $erro='Só é possível definir critérios numa oportunidade já publicada.';
        else {
            try { $st=$pdo->prepare('INSERT INTO feed_oportunidade_config (id_publicacao,id_ramo_criterio,id_quadro_criterio,id_patente_criterio,grupo_hierarquico_criterio,id_nivel_habilitacao,criterios_texto,atualizado_por,idade_minima,idade_maxima,tipo_especialista_criterio,local_servico_criterio) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE tipo_especialista_criterio=VALUES(tipo_especialista_criterio),local_servico_criterio=VALUES(local_servico_criterio), id_ramo_criterio=VALUES(id_ramo_criterio),id_quadro_criterio=VALUES(id_quadro_criterio),id_patente_criterio=VALUES(id_patente_criterio),grupo_hierarquico_criterio=VALUES(grupo_hierarquico_criterio),id_nivel_habilitacao=VALUES(id_nivel_habilitacao),criterios_texto=VALUES(criterios_texto),atualizado_por=VALUES(atualizado_por),idade_minima=VALUES(idade_minima),idade_maxima=VALUES(idade_maxima)'); $st->execute([$idPub,(($_POST['id_ramo_criterio']??'')!=='')?(int)$_POST['id_ramo_criterio']:null,(($_POST['id_quadro_criterio']??'')!=='')?(int)$_POST['id_quadro_criterio']:null,(($_POST['id_patente_criterio']??'')!=='')?(int)$_POST['id_patente_criterio']:null,array_key_exists((string)($_POST['grupo_hierarquico_criterio']??''),$gruposPatente)?(string)$_POST['grupo_hierarquico_criterio']:null,(($_POST['id_nivel_habilitacao']??'')!=='')?(int)$_POST['id_nivel_habilitacao']:null,trim((string)($_POST['criterios_texto']??'')),current_user_id(),($_POST['idade_minima']??'')!==''?(int)$_POST['idade_minima']:null,($_POST['idade_maxima']??'')!==''?(int)$_POST['idade_maxima']:null,in_array(($_POST['tipo_especialista_criterio']??''),['MILITAR','CIVIL'],true)?$_POST['tipo_especialista_criterio']:null,in_array(($_POST['local_servico_criterio']??''),['EMG','EXE','FAN','MGA'],true)?$_POST['local_servico_criterio']:null]); $sucesso='Critérios de elegibilidade guardados. A lista de especialistas foi atualizada.'; } catch(Throwable $e){$erro='Não foi possível guardar os critérios. Confirme se executou a migração v4.21.';}
        }
    } elseif ($acao === 'submeter_especialistas' && $podeSubmeter) {
        $idPub=(int)($_POST['id_publicacao']??0); $chk=$pdo->prepare("SELECT tipo FROM feed_publicacoes WHERE id_publicacao=? AND estado='ATIVO'");$chk->execute([$idPub]);$tipoPub=(string)$chk->fetchColumn();
        if($idPub<1 || !in_array($tipoPub,['CURSO','OPORTUNIDADE'],true)) $erro='A submissão só fica disponível depois de a oportunidade estar publicada.';
        else { $selecionados=array_values(array_unique(array_filter(array_map('intval',(array)($_POST['especialistas']??[]))))); if(!$selecionados)$erro='Selecione pelo menos um especialista. Pode retirar da lista os especialistas que não pretende incluir.'; else { try { $ins=$pdo->prepare('INSERT IGNORE INTO feed_candidaturas (id_publicacao,id_especialista,estado,submetido_por,submetido_em) VALUES (?,?,?,?,NOW())'); $cfgSt=$pdo->prepare('SELECT id_ramo_criterio,id_quadro_criterio,id_patente_criterio,grupo_hierarquico_criterio,id_nivel_habilitacao,idade_minima,idade_maxima,tipo_especialista_criterio,local_servico_criterio FROM feed_oportunidade_config WHERE id_publicacao=?');$cfgSt->execute([$idPub]);$cfgSubmit=$cfgSt->fetch(PDO::FETCH_ASSOC)?:[]; $modoSubmit=(string)($_POST['modo_selecao']??'automatico'); if(!in_array($modoSubmit,['automatico','manual'],true))$modoSubmit='automatico'; $condSubmit=["e.id_especialista=?","e.estado='ATIVO'"];  $total=0; foreach($selecionados as $idEsp){$args=[$idEsp];$conds=$condSubmit;if($nivel==='RAMO'){$rrSubmit=current_user_branch_ids();if(!$rrSubmit)continue;$conds[]='e.id_ramo IN ('.implode(',',array_fill(0,count($rrSubmit),'?')).')';$args=array_merge($args,$rrSubmit);}if($modoSubmit==='automatico'){if(!empty($cfgSubmit['idade_minima'])){$conds[]='dp.data_nascimento<=DATE_SUB(CURDATE(),INTERVAL '.(int)$cfgSubmit['idade_minima'].' YEAR)';}if(!empty($cfgSubmit['idade_maxima'])){$conds[]='dp.data_nascimento>DATE_SUB(CURDATE(),INTERVAL '.((int)$cfgSubmit['idade_maxima']+1).' YEAR)';}if(!empty($cfgSubmit['tipo_especialista_criterio'])){$conds[]='e.tipo_especialista=?';$args[]=$cfgSubmit['tipo_especialista_criterio'];}if(!empty($cfgSubmit['local_servico_criterio'])){$conds[]='EXISTS (SELECT 1 FROM dados_servico dx WHERE dx.id_especialista=e.id_especialista AND dx.local_servico=?)';$args[]=$cfgSubmit['local_servico_criterio'];}if(!empty($cfgSubmit['id_ramo_criterio'])){$conds[]='e.id_ramo=?';$args[]=(int)$cfgSubmit['id_ramo_criterio'];}if(!empty($cfgSubmit['id_quadro_criterio'])){$conds[]='e.id_quadro=?';$args[]=(int)$cfgSubmit['id_quadro_criterio'];}if(!empty($cfgSubmit['grupo_hierarquico_criterio'])){$conds[]='EXISTS (SELECT 1 FROM patentes pg WHERE pg.id_patente=e.id_patente AND pg.grupo_hierarquico=?)';$args[]=$cfgSubmit['grupo_hierarquico_criterio'];}if(!empty($cfgSubmit['id_patente_criterio'])){$conds[]='e.id_patente=?';$args[]=(int)$cfgSubmit['id_patente_criterio'];}if(!empty($cfgSubmit['id_nivel_habilitacao'])){$conds[]='EXISTS (SELECT 1 FROM habilitacoes_literarias hl JOIN niveis_habilitacao nh ON nh.id_nivel_habilitacao=hl.id_nivel_habilitacao JOIN niveis_habilitacao nr ON nr.id_nivel_habilitacao=? WHERE hl.id_especialista=e.id_especialista AND nh.ordem>=nr.ordem)';$args[]=(int)$cfgSubmit['id_nivel_habilitacao'];}}$valid=$pdo->prepare('SELECT e.id_especialista FROM especialistas e JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista WHERE '.implode(' AND ',$conds));$valid->execute($args);if($valid->fetchColumn()){$ins->execute([$idPub,$idEsp,'SUBMETIDA',current_user_id()]);$total+=$ins->rowCount();}} $sucesso=$total.' candidatura(s) submetida(s).'; } catch(Throwable $e){$erro='Não foi possível submeter as candidaturas. Confirme se a migração do Feed foi aplicada.';} } }
    } elseif ($acao === 'comentar' && $podeLer) {
        $idPub=(int)($_POST['id_publicacao']??0);
        $comentario=trim((string)($_POST['comentario']??''));
        if($idPub<1 || $comentario==='' || mb_strlen($comentario,'UTF-8')>3000) $erro='Escreva um comentário com até 3000 caracteres.';
        else {
            try {
                $c=$pdo->prepare("INSERT INTO feed_comentarios(id_publicacao,id_utilizador,comentario) SELECT id_publicacao,?,? FROM feed_publicacoes WHERE id_publicacao=? AND estado='ATIVO'");
                $c->execute([current_user_id(),$comentario,$idPub]);
                $sucesso=$c->rowCount()?'Comentário publicado.':'Publicação indisponível.';
            }catch(Throwable $e){$erro='Não foi possível guardar o comentário. Confirme a tabela feed_comentarios.';}
        }
    } elseif ($acao === 'avaliar') {
        $idPub=(int)($_POST['id_publicacao']??0); $estrelas=(int)($_POST['estrelas']??0);
        if($idPub<1 || $estrelas<1 || $estrelas>5) $erro='Selecione uma avaliação entre uma e cinco estrelas.';
        else { try{$ck=$pdo->prepare("SELECT 1 FROM feed_publicacoes WHERE id_publicacao=? AND estado='ATIVO'");$ck->execute([$idPub]);if(!$ck->fetchColumn())throw new Exception('Publicação indisponível.');$sv=$pdo->prepare('INSERT INTO feed_avaliacoes(id_publicacao,id_utilizador,estrelas) VALUES(?,?,?) ON DUPLICATE KEY UPDATE estrelas=VALUES(estrelas),atualizado_em=NOW()');$sv->execute([$idPub,current_user_id(),$estrelas]);$sucesso='A sua avaliação foi guardada.';}catch(Throwable $e){$erro='Não foi possível guardar a avaliação. Execute a migração v4.26.';} }
    } elseif ($acao === 'lido') {
        $idPub = (int)($_POST['id_publicacao'] ?? 0);
        if ($idPub > 0) {
            $st = $pdo->prepare('INSERT INTO feed_leituras (id_publicacao,id_utilizador,lido_em) SELECT id_publicacao,?,NOW() FROM feed_publicacoes WHERE id_publicacao=? AND estado="ATIVO" ON DUPLICATE KEY UPDATE lido_em=VALUES(lido_em)');
            $st->execute([current_user_id(),$idPub]);
            $sucesso = 'Comunicado marcado como lido.';
        }
    }
}
$areaConsulta = [];
if ($temRH = has_permission('ESPECIALISTAS_VISUALIZAR')) $areaConsulta[] = "'RH'";
if ($temRM = has_permission('EQUIPAMENTOS_VISUALIZAR')) $areaConsulta[] = "'RM'";
$areaConsulta[] = "'TODOS'";
$condArea = 'p.area IN ('.implode(',',array_unique($areaConsulta)).')';
$params = [];
if ($nivel === 'RAMO') {
    $ramos = current_user_branch_ids();
    if (!$ramos) $condRamo = 'p.id_ramo IS NULL';
    else { $condRamo = '(p.id_ramo IS NULL OR p.id_ramo IN ('.implode(',',array_fill(0,count($ramos),'?')).'))'; $params = $ramos; }
} else $condRamo = '1=1';
$filtroTipo = $secao === 'oportunidades' ? "p.tipo IN ('CURSO','OPORTUNIDADE')" : ($secao === 'comunicados' ? "p.tipo='COMUNICADO'" : "p.tipo IN ('COMUNICADO','CURSO','OPORTUNIDADE')");
$sql = "SELECT p.*,u.nome_utilizador AS autor,
        (SELECT COUNT(*) FROM feed_leituras l WHERE l.id_publicacao=p.id_publicacao) AS visualizacoes,
        (SELECT COUNT(*) FROM feed_leituras l WHERE l.id_publicacao=p.id_publicacao AND l.id_utilizador=?) AS ja_lido
        FROM feed_publicacoes p LEFT JOIN utilizadores u ON u.id_utilizador=p.id_autor
        WHERE p.estado='ATIVO' AND $filtroTipo AND $condArea AND $condRamo
        ORDER BY p.criado_em DESC";
array_unshift($params,current_user_id());
try { $st=$pdo->prepare($sql); $st->execute($params); $publicacoes=$st->fetchAll(PDO::FETCH_ASSOC); }
catch (Throwable $e) { $publicacoes=[]; $erro = $erro ?: 'O Feed ainda não está preparado na base de dados. Execute database/migracao_v4_17_feed.sql.'; }
$especialistas=[];
if ($podePublicar && ($ehAdminGeral || $ehAdminRamo || $ehAdminRH)) {
    try {
        $where='1=1'; $par=[];
        if ($nivel==='RAMO') { $r=current_user_branch_ids(); if (!$r) $where='0=1'; else {$where='e.id_ramo IN ('.implode(',',array_fill(0,count($r),'?')).')';$par=$r;} }
        $st=$pdo->prepare("SELECT e.id_especialista,dp.nome_completo,ds.nip FROM especialistas e JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista WHERE $where ORDER BY dp.nome_completo");
        $st->execute($par); $especialistas=$st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

$ramosCriterio=$quadrosCriterio=$patentesCriterio=$niveisCriterio=[];
try {$ramosCriterio=$pdo->query("SELECT id_ramo,nome FROM ramo WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);$quadrosCriterio=$pdo->query("SELECT id_quadro,nome FROM quadros_servico WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);$patentesCriterio=$pdo->query("SELECT id_patente,id_ramo,nome FROM patentes WHERE estado='ATIVO' ORDER BY ordem,id_ramo,nome")->fetchAll(PDO::FETCH_ASSOC);$niveisCriterio=$pdo->query("SELECT id_nivel_habilitacao,nome FROM niveis_habilitacao ORDER BY ordem,nome")->fetchAll(PDO::FETCH_ASSOC);} catch(Throwable $e) {}
?>
<?php $page_title = $secao === 'oportunidades' ? 'Oportunidades' : ($secao === 'comunicados' ? 'Comunicados' : 'Feed'); require __DIR__ . '/../layout/header.php'; ?>
<style>
.module-feed .feed-section-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 22px;border-bottom:1px solid var(--borda,#dbe3eb);padding-bottom:10px}.module-feed .feed-section-tabs a{padding:9px 14px;border-radius:9px;text-decoration:none;color:var(--texto,#334155);font-weight:650}.module-feed .feed-section-tabs a.ativo{background:var(--accent-profile,#1687c9);color:#fff}
/* SGE TELECOM — Feed e Comunicados: apresentação consistente e responsiva */
.module-feed.feed-page{font-family:Inter,system-ui,-apple-system,"Segoe UI",Arial,sans-serif;color:var(--texto,#1f2937);max-width:none;margin:0;padding:clamp(16px,2vw,28px);font-size:15px;line-height:1.55}
.module-feed.feed-page *{box-sizing:border-box}
.module-feed.feed-page .feed-toolbar{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap;margin-bottom:12px}
.module-feed.feed-page .feed-toolbar a,.module-feed.feed-page .feed-toolbar button{font:inherit}
.module-feed.feed-page .feed-toolbar .btn-secundario{display:inline-flex;align-items:center;gap:7px;text-decoration:none}
.module-feed.feed-page .composer-note{font-size:13px;color:var(--texto-secundario,#64748b);margin:10px 0 0}
.module-feed.feed-page .attachment-picker{border:1px dashed var(--borda,#cbd5e1);border-radius:10px;padding:14px;background:var(--fundo-input,#fff)}
.module-feed.feed-page .attachment-picker input{border:0;padding:8px 0;min-height:auto}
.module-feed.feed-page .attachment-preview{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
.module-feed.feed-page .attachment-chip{font-size:12px;padding:5px 9px;border-radius:7px;background:var(--superficie-secundaria,#f1f5f9);border:1px solid var(--borda,#dbe3eb)}
.module-feed.feed-page.feed-dark{--texto:#e5e7eb;--texto-secundario:#aab7c8;--superficie:#182230;--fundo-input:#101925;--superficie-secundaria:#263446;--borda:#35465b;background:#111a26;color:#e5e7eb;border-radius:12px}
.module-feed.feed-page.feed-dark .page-header h1,.module-feed.feed-page.feed-dark .form-section h2,.module-feed.feed-page.feed-dark article.card h2{color:#f1f5f9}
.module-feed.feed-page.feed-dark .badge{background:#163b58;color:#9ed8ff}
.module-feed.feed-page.feed-dark .btn-secundario{background:#263446;color:#e5e7eb;border-color:#40536a}
.module-feed.feed-page.feed-dark input,.module-feed.feed-page.feed-dark select,.module-feed.feed-page.feed-dark textarea{color:#e5e7eb}
.module-feed.feed-page .interaction-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:14px;padding-top:12px;border-top:1px solid var(--borda,#e2e8f0)}
.module-feed.feed-page .interaction-row .btn-secundario{min-height:36px;padding:6px 10px}

.module-feed.feed-page .page-header{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;flex-wrap:wrap;margin-bottom:24px;padding-bottom:20px;border-bottom:1px solid var(--borda,#dbe3eb)}
.module-feed.feed-page .page-header h1{font-size:clamp(25px,3vw,34px);line-height:1.2;letter-spacing:-.6px;margin:0 0 8px;font-weight:750;color:var(--texto,#172b4d)}
.module-feed.feed-page .page-header p{margin:0;color:var(--texto-secundario,#64748b);font-size:15px;max-width:720px}
.module-feed.feed-page .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:42px;padding:10px 16px;border:1px solid var(--accent-profile,#1687c9);border-radius:9px;background:var(--accent-profile,#1687c9);color:#fff;text-decoration:none;font-weight:650;cursor:pointer}
.module-feed.feed-page .btn-secundario{min-height:40px;padding:9px 14px;border:1px solid var(--borda,#cbd5e1);border-radius:8px;background:var(--superficie,#fff);color:var(--texto,#334155);font:inherit;font-weight:600;cursor:pointer}
.module-feed.feed-page .form-section,.module-feed.feed-page .feed-list>.card,.module-feed.feed-page article.card{background:var(--superficie,#fff);border:1px solid var(--borda,#dbe3eb);border-radius:14px;box-shadow:0 5px 18px rgba(15,23,42,.045)}
.module-feed.feed-page .form-section{padding:clamp(18px,2.5vw,28px);margin:22px 0}
.module-feed.feed-page .form-section h2{font-size:21px;line-height:1.3;margin:0 0 6px;color:var(--texto,#172b4d)}
.module-feed.feed-page .form-section>p{margin:0 0 22px;color:var(--texto-secundario,#64748b)}
.module-feed.feed-page .form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 20px;align-items:start}
.module-feed.feed-page .form-grid>div{min-width:0;display:flex;flex-direction:column;gap:7px}
.module-feed.feed-page label{font-size:14px;font-weight:650;color:var(--texto,#334155)}
.module-feed.feed-page input:not([type=hidden]),.module-feed.feed-page select,.module-feed.feed-page textarea{display:block;width:100%;max-width:100%;min-height:44px;padding:10px 12px;border:1px solid var(--borda,#cbd5e1);border-radius:8px;background:var(--fundo-input,#fff);color:var(--texto,#1f2937);font:inherit}
.module-feed.feed-page .feed-composer{margin:14px 0;padding:12px 16px;border:1px solid var(--borda,#dbe3eb);border-radius:12px;background:var(--surface,#fff)}.module-feed.feed-page .feed-composer>summary{cursor:pointer;font-weight:700;color:var(--accent-profile,#1687c9);padding:5px 0}.module-feed.feed-page .feed-composer-body{padding-top:10px}.module-feed.feed-page .feed-composer-body>p{margin:0 0 12px}.module-feed.feed-page textarea{min-height:95px;resize:vertical;line-height:1.55}
.module-feed.feed-page select[multiple]{min-height:180px;padding:8px}
.module-feed.feed-page .form-grid small{font-size:12px;color:var(--texto-secundario,#64748b)}
.module-feed.feed-page .form-actions{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-top:22px;padding-top:18px;border-top:1px solid var(--borda,#e2e8f0)}
.module-feed.feed-page .feed-list{display:grid;gap:16px;margin-top:24px}
.module-feed.feed-page .feed-list>.card,.module-feed.feed-page article.card{padding:clamp(18px,2.5vw,26px)!important}
.module-feed.feed-page article.card h2{font-size:20px;line-height:1.35;margin:14px 0 8px;color:var(--texto,#172b4d)}
.module-feed.feed-page article.card p{margin:0 0 18px;overflow-wrap:anywhere}
.module-feed.feed-page .badge{display:inline-flex;align-items:center;border-radius:999px;padding:5px 10px;background:color-mix(in srgb,var(--accent-profile,#1687c9) 12%,white);color:var(--accent-profile,#1687c9);font-size:12px;font-weight:700}
.module-feed.feed-page .erro,.module-feed.feed-page .sucesso{display:block;padding:12px 14px;border-radius:9px;margin:12px 0}
.module-feed.feed-page .erro{background:#fff1f2;color:#9f1239;border:1px solid #fecdd3}
.module-feed.feed-page .sucesso{background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0}
.module-feed.feed-page details{border-top:1px solid var(--borda,#e2e8f0);padding-top:12px}
.module-feed.feed-page summary{cursor:pointer;font-weight:650}
@media(max-width:700px){.module-feed.feed-page{padding:14px}.module-feed.feed-page .page-header{display:block}.module-feed.feed-page .page-header>.btn{margin-top:16px;width:100%}.module-feed.feed-page .form-grid{grid-template-columns:minmax(0,1fr);gap:14px}.module-feed.feed-page .form-actions{display:grid;grid-template-columns:1fr}.module-feed.feed-page .form-actions button{width:100%}.module-feed.feed-page .feed-list article>div{align-items:flex-start!important}}
@media(prefers-reduced-motion:no-preference){.module-feed.feed-page .btn,.module-feed.feed-page .btn-secundario{transition:filter .15s ease,transform .15s ease}.module-feed.feed-page .btn:hover,.module-feed.feed-page .btn-secundario:hover{filter:brightness(.96)}}
</style>
<div class="module-page module-feed feed-page">
 <nav class="feed-section-tabs" aria-label="Secções do Feed">
  <a class="<?= $secao==='feed'?'ativo':'' ?>" href="<?=htmlspecialchars(app_url('modulos/feed.php?secao=feed'))?>">Publicações</a>
  <a class="<?= $secao==='comunicados'?'ativo':'' ?>" href="<?=htmlspecialchars(app_url('modulos/feed.php?secao=comunicados'))?>">Comunicados</a>
  <a class="<?= $secao==='oportunidades'?'ativo':'' ?>" href="<?=htmlspecialchars(app_url('modulos/feed.php?secao=oportunidades'))?>">Oportunidades</a>
 </nav>
 <div class="page-header"><div><h1><?= $secao==='oportunidades'?'Formações':($secao==='comunicados'?'Comunicados':'Feed') ?></h1><p><?= $secao==='oportunidades'?'Oportunidades de aprendizagem.':($secao==='comunicados'?'Avisos e informações institucionais.':'Publicações e actualizações.') ?></p></div>
 <?php if($podePublicar && $secao!=='feed'): ?><a class="btn" href="#nova-publicacao">+ Criar</a><?php endif; ?></div>
 <?php if($erro): ?><div class="erro" role="alert"><?=htmlspecialchars($erro)?></div><?php endif; ?>
 <?php if($sucesso): ?><div class="sucesso" role="status"><?=htmlspecialchars($sucesso)?></div><?php endif; ?>
 <?php if($podePublicar && $secao!=='feed'): ?>
 <details class="form-section feed-composer" id="nova-publicacao"><summary>+ <?= $secao==='oportunidades'?'Publicar curso ou formação':($secao==='comunicados'?'Novo comunicado':'Nova publicação') ?></summary><div class="feed-composer-body"><p><?= $secao==='oportunidades'?'Descreva a formação e publique-a. Os critérios e a submissão ficam disponíveis depois da publicação.':($secao==='comunicados'?'Publique uma comunicação para a área autorizada.':'Partilhe uma informação com os utilizadores autorizados.') ?></p>
 <form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><input type="hidden" name="acao" value="publicar">
 <div class="form-grid">
 <div><label for="titulo">Título *</label><input id="titulo" name="titulo" maxlength="180" required placeholder="Ex.: Curso de formação aberto"></div>
 <input type="hidden" name="tipo" value="<?=htmlspecialchars($tipoSecao ?? 'OPORTUNIDADE')?>">
 <div><label for="area">Área destinatária *</label><select id="area" name="area" required><?php foreach($areasPermitidas as $a): ?><option value="<?=htmlspecialchars($a)?>"><?= $a==='TODOS'?'Todos os utilizadores':($a==='RH'?'Recursos Humanos':'Recursos Materiais') ?></option><?php endforeach; ?></select></div>
 <div><label for="data_limite">Prazo (opcional)</label><input id="data_limite" type="date" name="data_limite"></div>
 <?php if($secao==='oportunidades'): ?><div style="grid-column:1/-1;border:1px solid var(--borda,#e2e8f0);border-radius:12px;padding:16px"><h3 style="margin:0 0 8px">Destinatários e critérios da formação</h3><p class="composer-note">Escolha os requisitos para sugerir automaticamente os especialistas elegíveis. Após publicar, poderá editar os critérios, retirar ou acrescentar candidatos manualmente.</p><div class="form-grid">
<div><label>Tipo de Especialista</label><select name="tipo_especialista_criterio"><option value="">Militares e Civis</option><option value="MILITAR">Militares</option><option value="CIVIL">Civis</option></select></div>
<div><label>Ramo</label><select name="id_ramo_criterio"><option value="">Qualquer Ramo</option><?php foreach($ramosCriterio as $r): ?><option value="<?=(int)$r['id_ramo']?>"><?=htmlspecialchars($r['nome'])?></option><?php endforeach; ?></select></div>
<div><label>Local de Serviço</label><select name="local_servico_criterio"><option value="">Qualquer Local</option><?php foreach(['EMG','EXE','FAN','MGA'] as $ls): ?><option value="<?=$ls?>"><?=$ls?></option><?php endforeach; ?></select></div>
<div><label>Nível Hierárquico</label><select name="grupo_hierarquico_criterio"><option value="">Todos os Níveis</option><?php foreach($gruposPatente as $codigo=>$nome): ?><option value="<?=htmlspecialchars($codigo)?>"> <?=htmlspecialchars($nome)?> </option><?php endforeach; ?></select></div>
<div><label>Patente</label><select name="id_patente_criterio"><option value="">Qualquer Patente</option><?php foreach($patentesCriterio as $p): ?><option value="<?=(int)$p['id_patente']?>"><?=htmlspecialchars($p['nome'])?></option><?php endforeach; ?></select></div>
<div><label>Grau Académico Mínimo</label><select name="id_nivel_habilitacao"><option value="">Qualquer Grau</option><?php foreach($niveisCriterio as $nivel): ?><option value="<?=(int)$nivel['id_nivel_habilitacao']?>"><?=htmlspecialchars($nivel['nome'])?></option><?php endforeach; ?></select></div>
<div><label>Idade Mínima</label><input type="number" min="16" max="100" name="idade_minima"></div>
<div><label>Idade Máxima</label><input type="number" min="16" max="100" name="idade_maxima"></div>
</div></div><?php endif; ?>
<div style="grid-column:1/-1"><label for="conteudo"><?= $secao==='oportunidades'?'Descrição e requisitos da formação *':($secao==='comunicados'?'Conteúdo do comunicado *':'Texto da publicação *') ?></label><textarea id="conteudo" name="conteudo" rows="5" required placeholder="<?= $secao==='oportunidades'?'Descreva o curso/formação, os requisitos de elegibilidade e como candidatar-se.':'Escreva aqui...' ?>"></textarea></div>
 <div style="grid-column:1/-1"><label for="anexos">Fotografias, áudio e documentos (opcional)</label><div class="attachment-picker"><input id="anexos" name="anexos[]" type="file" multiple accept="image/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"><small>Até 5 ficheiros por publicação, 15 MB cada. Formatos permitidos: imagens, áudio e documentos comuns.</small><div class="attachment-preview" id="feed-attachment-preview"></div></div></div>
 </div><div class="form-actions"><button type="reset" class="btn-secundario">Limpar</button><button type="submit" class="btn"><?= $secao==='oportunidades'?'Publicar oportunidade':($secao==='comunicados'?'Publicar comunicado':'Publicar no Feed') ?></button></div>
 </form></div></details>
 <?php endif; ?>
 <section class="feed-list" style="display:grid;gap:16px;margin-top:22px">
 <?php if(!$publicacoes): ?><div class="card" style="padding:24px"><h2><?= $secao==='oportunidades'?'Sem oportunidades':($secao==='comunicados'?'Sem comunicados':'O Feed está vazio') ?></h2><p>As novas publicações desta secção serão apresentadas aqui.</p></div><?php endif; ?>
 <?php foreach($publicacoes as $pub): ?><article class="card feed-article" style="padding:22px;border-radius:16px;overflow:hidden">
 <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><span class="badge"><?=htmlspecialchars($pub['area']==='TODOS'?'Todos':($pub['area']==='RH'?'Recursos Humanos':'Recursos Materiais'))?></span><small><?=htmlspecialchars($pub['tipo'].' · '.date('d/m/Y H:i',strtotime($pub['criado_em'])))?></small></div>
 <?php $anexosPub=[]; try {$anx=$pdo->prepare('SELECT nome_original,nome_guardado,mime_type,tamanho_bytes FROM feed_anexos WHERE id_publicacao=? ORDER BY id_anexo');$anx->execute([(int)$pub['id_publicacao']]);$anexosPub=$anx->fetchAll(PDO::FETCH_ASSOC);} catch(Throwable $e) {} ?>
 <?php $fotosPub=array_values(array_filter($anexosPub,fn($a)=>str_starts_with((string)$a['mime_type'],'image/'))); if($fotosPub): ?><div class="feed-photo-gallery" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));gap:10px;margin:14px 0"><?php foreach($fotosPub as $fotoPub): $fotoUrl=app_url('uploads/feed/'.rawurlencode($fotoPub['nome_guardado'])); ?><a href="<?=htmlspecialchars($fotoUrl)?>" target="_blank" rel="noopener" style="display:block"><img src="<?=htmlspecialchars($fotoUrl)?>" alt="<?=htmlspecialchars($fotoPub['nome_original'])?>" loading="lazy" style="display:block;width:100%;max-height:440px;object-fit:contain;border-radius:12px;background:var(--superficie-secundaria,#f1f5f9)"></a><?php endforeach; ?></div><?php endif; ?>
 <h2 style="font-size:clamp(22px,2.2vw,30px);line-height:1.2;letter-spacing:-.025em;margin:18px 0 12px;font-weight:800"><?=htmlspecialchars($pub['titulo'])?></h2><p style="white-space:pre-line;line-height:1.7"><?=htmlspecialchars($pub['conteudo'])?></p>
 <?php if(in_array($pub['tipo'],['CURSO','OPORTUNIDADE'],true) && ($podeGerir || $podeSubmeter)): ?>
 <?php $cfg=['id_ramo_criterio'=>null,'id_quadro_criterio'=>null,'id_patente_criterio'=>null,'grupo_hierarquico_criterio'=>null,'id_nivel_habilitacao'=>null,'criterios_texto'=>'','idade_minima'=>null,'idade_maxima'=>null,'tipo_especialista_criterio'=>null,'local_servico_criterio'=>null]; try{$cc=$pdo->prepare('SELECT * FROM feed_oportunidade_config WHERE id_publicacao=?');$cc->execute([(int)$pub['id_publicacao']]);$cfg=array_merge($cfg,$cc->fetch(PDO::FETCH_ASSOC)?:[]);}catch(Throwable $e){} ?>
 <details class="opportunity-manage" style="margin:14px 0;padding:12px;border:1px solid var(--borda,#dbe3eb);border-radius:10px"><summary>Critérios e submissão de especialistas</summary>
 <?php if($podeGerir): ?><form method="post" style="margin-top:12px"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><input type="hidden" name="acao" value="guardar_criterios"><input type="hidden" name="id_publicacao" value="<?=(int)$pub['id_publicacao']?>"><div class="form-grid">
 <div><label>Tipo de Especialista</label><select name="tipo_especialista_criterio"><option value="">Militares e Civis</option><?php foreach(['MILITAR'=>'Militar','CIVIL'=>'Civil'] as $v=>$txt): ?><option value="<?=$v?>" <?=($cfg['tipo_especialista_criterio']??'')===$v?'selected':''?>><?=$txt?></option><?php endforeach;?></select></div>
 <div><label>Local de Serviço</label><select name="local_servico_criterio"><option value="">Qualquer Local</option><?php foreach(['EMG','EXE','FAN','MGA'] as $ls): ?><option value="<?=$ls?>" <?=($cfg['local_servico_criterio']??'')===$ls?'selected':''?>><?=$ls?></option><?php endforeach;?></select></div>
 <div><label>Ramo</label><select name="id_ramo_criterio"><option value="">Qualquer ramo</option><?php foreach($ramosCriterio as $op): ?><option value="<?=(int)$op['id_ramo']?>" <?=((string)$cfg['id_ramo_criterio']===(string)$op['id_ramo']?'selected':'')?>><?=htmlspecialchars($op['nome'])?></option><?php endforeach; ?></select></div>
 <div><label>Forma de Prestação de Serviço (FPS)</label><select name="id_quadro_criterio"><option value="">Qualquer quadro</option><?php foreach($quadrosCriterio as $op): ?><option value="<?=(int)$op['id_quadro']?>" <?=((string)$cfg['id_quadro_criterio']===(string)$op['id_quadro']?'selected':'')?>><?=htmlspecialchars($op['nome'])?></option><?php endforeach; ?></select></div>
 <div><label>Nível Hierárquico</label><select name="grupo_hierarquico_criterio"><option value="">Todos os Níveis</option><?php foreach($gruposPatente as $codigo=>$nome): ?><option value="<?=htmlspecialchars($codigo)?>" <?=($cfg['grupo_hierarquico_criterio']??'')===$codigo?'selected':''?>><?=htmlspecialchars($nome)?></option><?php endforeach; ?></select></div>
<div><label>Patente</label><select name="id_patente_criterio"><option value="">Qualquer patente</option><?php foreach($patentesCriterio as $op): ?><option value="<?=(int)$op['id_patente']?>" <?=((string)$cfg['id_patente_criterio']===(string)$op['id_patente']?'selected':'')?>><?=htmlspecialchars($op['nome'])?></option><?php endforeach; ?></select></div>
 <div><label>Habilitação mínima</label><select name="id_nivel_habilitacao"><option value="">Sem filtro de habilitação</option><?php foreach($niveisCriterio as $op): ?><option value="<?=(int)$op['id_nivel_habilitacao']?>" <?=((string)$cfg['id_nivel_habilitacao']===(string)$op['id_nivel_habilitacao']?'selected':'')?>><?=htmlspecialchars($op['nome'])?></option><?php endforeach; ?></select></div>
 <div><label>Idade mínima</label><input name="idade_minima" type="number" min="16" max="100" value="<?=htmlspecialchars((string)($cfg['idade_minima']??''))?>"></div><div><label>Idade máxima</label><input name="idade_maxima" type="number" min="16" max="100" value="<?=htmlspecialchars((string)($cfg['idade_maxima']??''))?>"></div><div style="grid-column:1/-1"><label>Outros critérios / notas</label><textarea name="criterios_texto" rows="2" placeholder="Notas adicionais sobre elegibilidade"><?=htmlspecialchars((string)$cfg['criterios_texto'])?></textarea></div></div><button class="btn-secundario" type="submit">Guardar critérios e atualizar sugestões</button></form><?php endif; ?>
 <?php if($podeSubmeter): ?>
 <?php $buscaEsp=trim((string)($_GET['busca_especialista']??''));$modoSelecao=(string)($_GET['modo_selecao']??'automatico');if(!in_array($modoSelecao,['automatico','manual'],true))$modoSelecao='automatico';$temCriteriosAutomaticos=!empty($cfg['id_ramo_criterio'])||!empty($cfg['id_quadro_criterio'])||!empty($cfg['id_patente_criterio'])||!empty($cfg['grupo_hierarquico_criterio'])||!empty($cfg['id_nivel_habilitacao'])||!empty($cfg['tipo_especialista_criterio'])||!empty($cfg['local_servico_criterio']);$whereEsp=["e.estado='ATIVO'"]; $parEsp=[]; if($nivel==='RAMO'){$rr=current_user_branch_ids();if(!$rr)$whereEsp[]='0=1';else{$whereEsp[]='e.id_ramo IN ('.implode(',',array_fill(0,count($rr),'?')).')';$parEsp=array_merge($parEsp,$rr);}} if($modoSelecao==='automatico'){if(!empty($cfg['idade_minima'])){$whereEsp[]='dp.data_nascimento<=DATE_SUB(CURDATE(),INTERVAL '.(int)$cfg['idade_minima'].' YEAR)';}if(!empty($cfg['idade_maxima'])){$whereEsp[]='dp.data_nascimento>DATE_SUB(CURDATE(),INTERVAL '.((int)$cfg['idade_maxima']+1).' YEAR)';}if(!empty($cfg['tipo_especialista_criterio'])){$whereEsp[]='e.tipo_especialista=?';$parEsp[]=$cfg['tipo_especialista_criterio'];}if(!empty($cfg['local_servico_criterio'])){$whereEsp[]='EXISTS (SELECT 1 FROM dados_servico dl WHERE dl.id_especialista=e.id_especialista AND dl.local_servico=?)';$parEsp[]=$cfg['local_servico_criterio'];}if(!empty($cfg['id_ramo_criterio'])){$whereEsp[]='e.id_ramo=?';$parEsp[]=(int)$cfg['id_ramo_criterio'];} if(!empty($cfg['id_quadro_criterio'])){$whereEsp[]='e.id_quadro=?';$parEsp[]=(int)$cfg['id_quadro_criterio'];} if(!empty($cfg['grupo_hierarquico_criterio'])){$whereEsp[]='EXISTS (SELECT 1 FROM patentes pg WHERE pg.id_patente=e.id_patente AND pg.grupo_hierarquico=?)';$parEsp[]=$cfg['grupo_hierarquico_criterio'];}if(!empty($cfg['id_patente_criterio'])){$whereEsp[]='e.id_patente=?';$parEsp[]=(int)$cfg['id_patente_criterio'];} if(!empty($cfg['id_nivel_habilitacao'])){$whereEsp[]='EXISTS (SELECT 1 FROM habilitacoes_literarias hl JOIN niveis_habilitacao nh ON nh.id_nivel_habilitacao=hl.id_nivel_habilitacao JOIN niveis_habilitacao nr ON nr.id_nivel_habilitacao=? WHERE hl.id_especialista=e.id_especialista AND nh.ordem>=nr.ordem)';$parEsp[]=(int)$cfg['id_nivel_habilitacao'];}} if($buscaEsp!==''){$whereEsp[]='(dp.nome_completo LIKE ? OR ds.nip LIKE ? OR ds.no_civil LIKE ? OR dp.numero_bi LIKE ?)';$q='%'.$buscaEsp.'%';array_push($parEsp,$q,$q,$q,$q);} $sqlEsp='SELECT DISTINCT e.id_especialista,dp.nome_completo,ds.nip,dp.numero_bi FROM especialistas e JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista WHERE '.implode(' AND ',$whereEsp).' ORDER BY dp.nome_completo LIMIT 250';$candidatos=[];try{$se=$pdo->prepare($sqlEsp);$se->execute($parEsp);$candidatos=$se->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){} $jaSubmetidos=[];try{$js=$pdo->prepare('SELECT id_especialista FROM feed_candidaturas WHERE id_publicacao=?');$js->execute([(int)$pub['id_publicacao']]);$jaSubmetidos=array_map('intval',$js->fetchAll(PDO::FETCH_COLUMN));}catch(Throwable $e){} ?>
 <form method="get" style="margin-top:14px;display:flex;gap:8px;align-items:end;flex-wrap:wrap"><input type="hidden" name="secao" value="<?=htmlspecialchars($secao)?>"><label>Modo<select name="modo_selecao"><option value="automatico" <?=$modoSelecao==='automatico'?'selected':''?>>Sugerir por critérios</option><option value="manual" <?=$modoSelecao==='manual'?'selected':''?>>Seleção manual</option></select></label><label style="flex:1;min-width:220px">Pesquisar especialista por Nome, NIP, NO ou BI<input name="busca_especialista" value="<?=htmlspecialchars($buscaEsp)?>" placeholder="Nome, NIP, NO ou BI"></label><button class="btn-secundario" type="submit">Pesquisar</button></form>
 <p class="composer-note">Em “Sugerir por critérios”, os especialistas correspondentes são pré-selecionados e pode excluir qualquer um. Em “Seleção manual”, pesquise por nome, NIP ou BI sem aplicar os critérios automáticos. Até 250 resultados por pesquisa.</p>
 <form method="post" style="margin-top:10px"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><input type="hidden" name="acao" value="submeter_especialistas"><input type="hidden" name="id_publicacao" value="<?=(int)$pub['id_publicacao']?>"><input type="hidden" name="modo_selecao" value="<?=htmlspecialchars($modoSelecao)?>"><div style="max-height:260px;overflow:auto;border:1px solid var(--borda,#e2e8f0);border-radius:8px;padding:8px"><?php if(!$candidatos): ?><p>Nenhum especialista corresponde aos critérios/pesquisa.</p><?php endif; ?><?php foreach($candidatos as $ce): ?><label style="display:flex;gap:9px;align-items:center;padding:7px 3px;border-bottom:1px solid var(--borda,#eef2f7)"><input type="checkbox" name="especialistas[]" value="<?=(int)$ce['id_especialista']?>" <?=in_array((int)$ce['id_especialista'],$jaSubmetidos,true)?'disabled':(!$buscaEsp && $modoSelecao==='automatico' && $temCriteriosAutomaticos && !in_array((int)$ce['id_especialista'],$jaSubmetidos,true)?'checked':'')?> <?=in_array((int)$ce['id_especialista'],$jaSubmetidos,true)?'checked':''?>><span><?=htmlspecialchars($ce['nome_completo'])?> <small>· NIP <?=htmlspecialchars($ce['nip']??'N/D')?> · BI <?=htmlspecialchars($ce['numero_bi']??'N/D')?><?=in_array((int)$ce['id_especialista'],$jaSubmetidos,true)?' · Já submetido':''?></small></span></label><?php endforeach; ?></div><button class="btn" type="submit" style="margin-top:10px" <?=!$candidatos?'disabled':''?>>Submeter especialistas selecionados</button></form>
 <?php endif; ?></details><?php endif; ?>
 <?php $anexosRestantes=array_values(array_filter($anexosPub,fn($a)=>!str_starts_with((string)$a['mime_type'],'image/'))); ?>
 <?php if($anexosRestantes): ?><div class="feed-attachments" style="display:grid;gap:12px;margin:16px 0"><?php foreach($anexosRestantes as $anx): $urlAnexo=app_url('uploads/feed/'.rawurlencode($anx['nome_guardado'])); $mime=(string)$anx['mime_type']; ?><?php if(str_starts_with($mime,'audio/')): ?><div class="feed-audio"><strong>♫ <?=htmlspecialchars($anx['nome_original'])?></strong><audio controls preload="none" style="display:block;width:min(100%,560px);margin-top:7px"><source src="<?=htmlspecialchars($urlAnexo)?>" type="<?=htmlspecialchars($mime)?>">O navegador não suporta áudio.</audio></div><?php else: ?><a class="btn-secundario" style="width:max-content;max-width:100%" href="<?=htmlspecialchars($urlAnexo)?>" target="_blank" rel="noopener" download="<?=htmlspecialchars($anx['nome_original'])?>">📎 <?=htmlspecialchars($anx['nome_original'])?> <small>(<?=number_format(((int)$anx['tamanho_bytes'])/1024,0,',','.')?> KB)</small></a><?php endif; ?><?php endforeach; ?></div><?php endif; ?>
 <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap"><small>Publicado por <?=htmlspecialchars($pub['autor']??'Administração')?><?php if($pub['data_limite']): ?> · Prazo: <?=date('d/m/Y',strtotime($pub['data_limite']))?><?php endif; ?></small>
 <?php if($podeGerir): ?><form method="post" onsubmit="return confirm('Tem a certeza de que pretende eliminar esta publicação? Esta ação não pode ser desfeita.');"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><input type="hidden" name="acao" value="eliminar_publicacao"><input type="hidden" name="id_publicacao" value="<?=(int)$pub['id_publicacao']?>"><button type="submit" class="btn-secundario" style="color:#b42318;border-color:#f3b4ae">Eliminar publicação</button></form><?php endif; ?>
 <?php if(!(int)$pub['ja_lido']): ?><form method="post"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><input type="hidden" name="acao" value="lido"><input type="hidden" name="id_publicacao" value="<?=(int)$pub['id_publicacao']?>"><button type="submit" class="btn-secundario">✓ Marcar como lido</button></form><?php else: ?><span class="sucesso">✓ Lido</span><?php endif; ?>
 </div>
 <?php $minhasEstrelas=0; $mediaEstrelas=0; $totalAvaliacoes=0; try{$rs=$pdo->prepare('SELECT estrelas FROM feed_avaliacoes WHERE id_publicacao=? AND id_utilizador=?');$rs->execute([(int)$pub['id_publicacao'],current_user_id()]);$minhasEstrelas=(int)$rs->fetchColumn();$ra=$pdo->prepare('SELECT AVG(estrelas),COUNT(*) FROM feed_avaliacoes WHERE id_publicacao=?');$ra->execute([(int)$pub['id_publicacao']]);[$mediaEstrelas,$totalAvaliacoes]=$ra->fetch(PDO::FETCH_NUM)?:[0,0];}catch(Throwable $e){} ?>
 <div class="interaction-row"><span class="composer-note">Avalie esta publicação:</span><form method="post" class="feed-stars-form" style="display:inline-flex;align-items:center;gap:4px"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><input type="hidden" name="acao" value="avaliar"><input type="hidden" name="id_publicacao" value="<?=(int)$pub['id_publicacao']?>"><div class="feed-stars" role="group" aria-label="Avaliar de uma a cinco estrelas"><?php for($star=1;$star<=5;$star++): ?><button type="submit" name="estrelas" value="<?=$star?>" class="feed-star <?= $star<=$minhasEstrelas?'selecionada':'' ?>" title="<?=$star?> estrela(s)" aria-label="<?=$star?> estrela(s)"><?= $star<=$minhasEstrelas?'★':'☆' ?></button><?php endfor; ?></div></form><span class="composer-note"><?=number_format((float)$mediaEstrelas,1,',','.')?>/5 · <?= (int)$totalAvaliacoes ?> avaliação(ões)</span><button type="button" class="btn-secundario feed-comment-toggle">💬 Comentar</button></div>
 <div class="feed-comment-area" hidden style="margin-top:10px">
 <form method="post" class="feed-comment-form"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><input type="hidden" name="acao" value="comentar"><input type="hidden" name="id_publicacao" value="<?=(int)$pub['id_publicacao']?>"><label>Participar na discussão</label><textarea name="comentario" rows="3" maxlength="3000" required placeholder="Escreva um comentário fundamentado..."></textarea><button class="btn" type="submit">Publicar comentário</button></form>
 <?php try{$com=$pdo->prepare('SELECT c.comentario,c.criado_em,u.nome_utilizador FROM feed_comentarios c JOIN utilizadores u ON u.id_utilizador=c.id_utilizador WHERE c.id_publicacao=? ORDER BY c.criado_em DESC,c.id_comentario DESC LIMIT 30');$com->execute([(int)$pub['id_publicacao']]);foreach($com->fetchAll(PDO::FETCH_ASSOC) as $ct): ?><div class="feed-comentario-real"><strong><?=htmlspecialchars($ct['nome_utilizador'])?></strong> <small><?=date('d/m/Y H:i',strtotime($ct['criado_em']))?></small><p><?=nl2br(htmlspecialchars($ct['comentario']))?></p></div><?php endforeach;}catch(Throwable $e){} ?>
 </div>
 <?php if($podePublicar): ?><details style="margin-top:14px"><summary>Ver leituras (<?= (int)$pub['visualizacoes'] ?>)</summary><div style="padding:10px"><?php
 try {$ls=$pdo->prepare('SELECT u.nome_utilizador,l.lido_em FROM feed_leituras l JOIN utilizadores u ON u.id_utilizador=l.id_utilizador WHERE l.id_publicacao=? ORDER BY l.lido_em DESC');$ls->execute([(int)$pub['id_publicacao']]);$leituras=$ls->fetchAll(PDO::FETCH_ASSOC); if(!$leituras) echo '<p>Ainda sem leituras registadas.</p>'; else {echo '<ul>';foreach($leituras as $leitura) echo '<li>'.htmlspecialchars($leitura['nome_utilizador']).' — '.date('d/m/Y H:i',strtotime($leitura['lido_em'])).'</li>';echo '</ul>';}} catch(Throwable $e) {echo '<p>Não foi possível carregar as leituras.</p>';}
 ?></div></details><?php endif; ?>
 </article><?php endforeach; ?>
 </section>
</div>
<script>
(function(){
 const root=document.querySelector('.module-feed.feed-page');
 if(!root) return;
 if(location.hash==='#nova-publicacao'){const composer=document.getElementById('nova-publicacao');if(composer)composer.open=true;}
 const theme=document.getElementById('feed-theme-toggle');
 const saved=(()=>{try{return sessionStorage.getItem('se-feed-theme')}catch(e){return null}})();
 if(theme && saved==='dark'){root.classList.add('feed-dark');theme.textContent='☀ Modo claro';theme.setAttribute('aria-pressed','true')}
 if(theme) theme.addEventListener('click',function(){
   const dark=root.classList.toggle('feed-dark');
   theme.textContent=dark?'☀ Modo claro':'◐ Modo escuro';
   theme.setAttribute('aria-pressed',dark?'true':'false');
   try{sessionStorage.setItem('se-feed-theme',dark?'dark':'light')}catch(e){}
 });
 const picker=document.getElementById('anexos'), preview=document.getElementById('feed-attachment-preview');
 if(picker&&preview) picker.addEventListener('change',function(){
   preview.replaceChildren();
   Array.from(picker.files||[]).forEach(function(file){
     const chip=document.createElement('span');chip.className='attachment-chip';
     chip.textContent=(file.type.startsWith('audio/')?'♫ ':file.type.startsWith('image/')?'▧ ':'📎 ')+file.name+' · '+Math.max(1,Math.round(file.size/1024))+' KB';
     preview.appendChild(chip);
   });
 });
 root.querySelectorAll('.feed-reaction').forEach(function(btn){btn.addEventListener('click',function(){
   const active=btn.getAttribute('aria-pressed')==='true';btn.setAttribute('aria-pressed',active?'false':'true');
   const count=btn.querySelector('.reaction-count');count.textContent=Math.max(0,parseInt(count.textContent||'0',10)+(active?-1:1));
   btn.firstChild.textContent=active?'♡ Gostar ':'♥ Gostar ';
 });});
 root.querySelectorAll('.feed-comment-toggle').forEach(function(btn){btn.addEventListener('click',function(){
   const area=btn.closest('article').querySelector('.feed-comment-area');area.hidden=!area.hidden;
 });});
})();
</script>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
