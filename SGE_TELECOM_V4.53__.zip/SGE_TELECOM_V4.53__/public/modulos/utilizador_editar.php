<?php
require_once __DIR__ . '/../../app/auth.php';
require_login();
require_permission('UTILIZADORES_EDITAR');

$pdo = db();
$page_title = 'Editar Utilizador';
$id = (int)($_GET['id'] ?? $_POST['id_utilizador'] ?? 0);
$returnTo = safe_return_url($_POST['return_to'] ?? $_GET['return_to'] ?? null, 'utilizadores.php');

if ($id <= 0) { header('Location: '.$returnTo); exit; }

function nivel_pode_editar(string $nivelAtual, string $nivelAlvo): bool {
    if ($nivelAtual === 'GLOBAL') return true;
    if ($nivelAtual === 'RAMO') return in_array($nivelAlvo,['RAMO','UNIDADE'],true);
    if ($nivelAtual === 'REGIAO') return in_array($nivelAlvo,['REGIAO','UNIDADE'],true);
    if ($nivelAtual === 'UNIDADE') return $nivelAlvo === 'UNIDADE';
    return false;
}

$st = $pdo->prepare("
    SELECT u.*,p.nome perfil_nome,p.nivel_acesso perfil_nivel
    FROM utilizadores u
    INNER JOIN perfis p ON p.id_perfil=u.id_perfil
    WHERE u.id_utilizador=?
");
$st->execute([$id]);
$utilizador = $st->fetch(PDO::FETCH_ASSOC);
if (!$utilizador) { header('Location: '.$returnTo); exit; }

$modalidadeSelecionada=strtoupper((string)($utilizador['modalidade_gestao']??'RAMO'));
$locaisSelecionados=[];
$stLocais=$pdo->prepare('SELECT local_servico FROM utilizador_local_servico WHERE id_utilizador=?');
$stLocais->execute([$id]);$locaisSelecionados=$stLocais->fetchAll(PDO::FETCH_COLUMN);
$nivelAtual = current_user_level();
$uidAtual = current_user_id();

if ($nivelAtual !== 'GLOBAL' && $uidAtual === $id) {
    // Pode editar a própria conta, mas não pode elevar o próprio perfil.
} elseif (!nivel_pode_editar($nivelAtual,(string)$utilizador['perfil_nivel'])) {
    http_response_code(403); exit('Não pode editar este utilizador.');
}

if ($nivelAtual === 'RAMO' && user_is_rh_admin() && !user_can_manage_delegated_account($id)) {http_response_code(403);exit('Este utilizador possui direitos fora do âmbito delegado.');}
if ($nivelAtual === 'RAMO') {
    $st = $pdo->prepare("
        SELECT 1
        FROM utilizador_ramo a
        INNER JOIN utilizador_ramo b ON b.id_ramo=a.id_ramo
        WHERE a.id_utilizador=? AND b.id_utilizador=?
        LIMIT 1
    ");
    $st->execute([$uidAtual,$id]);
    if (!$st->fetchColumn()) { http_response_code(403); exit('Utilizador fora do seu ramo.'); }
} elseif ($nivelAtual === 'REGIAO' && $uidAtual !== $id) {
    $st=$pdo->prepare('SELECT 1 FROM utilizador_regiao a INNER JOIN utilizador_regiao b ON b.id_regiao=a.id_regiao WHERE a.id_utilizador=? AND b.id_utilizador=? LIMIT 1');$st->execute([$uidAtual,$id]);
    if(!$st->fetchColumn()){http_response_code(403);exit('Utilizador fora da sua região.');}
} elseif ($nivelAtual === 'UNIDADE' && $uidAtual !== $id) {
    $st = $pdo->prepare("
        SELECT 1
        FROM utilizador_unidade a
        INNER JOIN utilizador_unidade b ON b.id_unidade=a.id_unidade
        WHERE a.id_utilizador=? AND b.id_utilizador=?
        LIMIT 1
    ");
    $st->execute([$uidAtual,$id]);
    if (!$st->fetchColumn()) { http_response_code(403); exit('Utilizador fora da sua unidade.'); }
}

$perfis = $pdo->query("SELECT id_perfil,nome,nivel_acesso FROM perfis WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$perfisPermitidos = array_values(array_filter($perfis, fn($p) => (nivel_pode_editar($nivelAtual,(string)$p['nivel_acesso']) && user_may_delegate_profile($p)) || (current_user_level()==='GLOBAL' && (int)$p['id_perfil']===(int)$utilizador['id_perfil'])));
$regioes = $pdo->query("SELECT id_regiao,nome,sigla FROM regioes WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$ramos = $pdo->query("SELECT id_ramo,nome,sigla FROM ramo WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$unidades = $pdo->query("SELECT id_unidade,id_ramo,nome,sigla FROM unidades WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$especialistas = $pdo->query("
    SELECT e.id_especialista,e.id_ramo,ds.nip,dp.nome_completo,dp.numero_bi,r.nome ramo_nome,r.sigla ramo_sigla,u.id_unidade,u.nome unidade_nome
    FROM especialistas e
    INNER JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista
    LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista
    INNER JOIN ramo r ON r.id_ramo=e.id_ramo
    LEFT JOIN unidades u ON u.id_unidade=ds.id_unidade
    WHERE e.estado='ATIVO'
    ORDER BY dp.nome_completo
")->fetchAll(PDO::FETCH_ASSOC);

$meusRamos=current_user_branch_ids();
if ($nivelAtual==='RAMO') {
    $ramos=array_values(array_filter($ramos,fn($r)=>in_array((int)$r['id_ramo'],$meusRamos,true)));
    $unidades=array_values(array_filter($unidades,fn($u)=>in_array((int)$u['id_ramo'],$meusRamos,true)));
    $especialistas=array_values(array_filter($especialistas,fn($e)=>in_array((int)$e['id_ramo'],$meusRamos,true) && (!user_is_rh_admin() || user_can_edit_specialist((int)$e['id_especialista']))));
}

if ($nivelAtual==='REGIAO') {
    $meusRegioes=current_user_region_ids();
    $regioes=array_values(array_filter($regioes,fn($r)=>in_array((int)$r['id_regiao'],$meusRegioes,true)));
}
if ($nivelAtual==='REGIAO') {
    $unidades=array_values(array_filter($unidades,fn($u)=>in_array((int)($u['id_regiao']??0),$meusRegioes,true)));
    $ramos=array_values(array_filter($ramos,fn($r)=>in_array((int)$r['id_ramo'],array_map('intval',array_column($unidades,'id_ramo')),true)));
}

$qrg=$pdo->prepare("SELECT id_regiao FROM utilizador_regiao WHERE id_utilizador=?");$qrg->execute([$id]);$regioesSelecionadas=array_map('intval',$qrg->fetchAll(PDO::FETCH_COLUMN));
$qr=$pdo->prepare("SELECT id_ramo FROM utilizador_ramo WHERE id_utilizador=?");
$qr->execute([$id]); $ramosSelecionados=array_map('intval',$qr->fetchAll(PDO::FETCH_COLUMN));
$qu=$pdo->prepare("SELECT id_unidade FROM utilizador_unidade WHERE id_utilizador=?");
$qu->execute([$id]); $unidadesSelecionadas=array_map('intval',$qu->fetchAll(PDO::FETCH_COLUMN));

$erro=''; $sucesso='';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $nome=trim($_POST['nome_utilizador']??'');
    $email=trim($_POST['email']??'');
    $novaSenha=(string)($_POST['senha']??'');
    $confirmacao=(string)($_POST['senha_confirmacao']??'');
    $idPerfil=(int)($_POST['id_perfil']??0);
    $estado=in_array($_POST['estado']??'', ['ATIVO','INATIVO'],true)?$_POST['estado']:'ATIVO';
    $idEspecialista=(int)($_POST['id_especialista']??0);
    $idsRegioes=array_values(array_unique(array_filter(array_map('intval',$_POST['regioes']??[]))));$idsRamos=array_values(array_unique(array_filter(array_map('intval',$_POST['ramos']??[]))));
    $locaisServico = array_values(array_intersect(['EMG','EXE','FAN','MGA'], array_map('strtoupper', (array)($_POST['locais_servico'] ?? []))));
    $modalidadeGestao = strtoupper((string)($_POST['modalidade_gestao'] ?? 'RAMO'));
    if (!in_array($modalidadeGestao,['RAMO','LOCAL','COMBINADO'],true)) $modalidadeGestao='RAMO';
    $idsUnidades=array_values(array_unique(array_filter(array_map('intval',$_POST['unidades']??[]))));

    $perfilEscolhido=null;
    foreach($perfisPermitidos as $p){if((int)$p['id_perfil']===$idPerfil){$perfilEscolhido=$p;break;}}

    if($nome==='') $erro='O nome de utilizador é obrigatório.';
    elseif(!$perfilEscolhido || !user_may_delegate_profile($perfilEscolhido)) $erro='Perfil não permitido.';
    elseif(!nivel_pode_editar($nivelAtual,(string)$perfilEscolhido['nivel_acesso']) && (int)$perfilEscolhido['id_perfil']!==(int)$utilizador['id_perfil']) $erro='Não pode atribuir este perfil.';
    elseif($novaSenha!=='' && $novaSenha!==$confirmacao) $erro='A confirmação da senha não coincide.';
    elseif($idEspecialista>0 && !in_array($idEspecialista,array_map('intval',array_column($especialistas,'id_especialista')),true)) $erro='Especialista fora do âmbito.';
    elseif($idEspecialista>0 && (int)$idEspecialista!==(int)$utilizador['id_especialista'] && (int)$pdo->query("SELECT COALESCE(id_utilizador,0) FROM utilizadores WHERE id_especialista=".(int)$idEspecialista." LIMIT 1")->fetchColumn()>0) $erro='Este especialista já possui outra conta.';
    elseif($perfilEscolhido['nivel_acesso']==='REGIAO' && !$idsRegioes) $erro='Selecione a região do utilizador.';
    elseif($perfilEscolhido['nivel_acesso']==='RAMO' && !$idsRamos) $erro='Selecione o ramo do utilizador.';
    elseif($perfilEscolhido['nivel_acesso']==='UNIDADE' && !$idsUnidades) $erro='Selecione a unidade do utilizador.';

    // Nunca permitir que um administrador delegado atribua locais de edição
    // acima dos próprios direitos. Isto também protege chamadas POST diretas.
    if ($erro === '' && $nivelAtual !== 'GLOBAL' && $modalidadeGestao !== current_user_edit_mode()) $erro='Só um administrador global pode atribuir uma modalidade de gestão diferente.';
    if ($erro === '' && !user_can_delegate_scope($idsRamos,$locaisServico,$idsUnidades,$modalidadeGestao)) {
        $erro='Âmbito delegado superior ao seu âmbito autorizado.';
    }
    if ($erro === '' && $nivelAtual !== 'GLOBAL' && array_diff($locaisServico, user_service_locations())) {
        $erro='Não pode atribuir um Local de Serviço fora do seu próprio âmbito.';
    }

    if($erro==='' && $nivelAtual==='RAMO') {
        if($perfilEscolhido['nivel_acesso']==='RAMO' && array_diff($idsRamos,$meusRamos)) $erro='Só pode atribuir o seu ramo.';
        if($perfilEscolhido['nivel_acesso']==='UNIDADE' && array_diff($idsUnidades,array_map('intval',array_column($unidades,'id_unidade')))) $erro='Só pode atribuir unidades do seu ramo.';
    }

    if($erro==='') try {
        $pdo->beginTransaction();

        $sql="UPDATE utilizadores SET nome_utilizador=?,email=?,id_perfil=?,id_especialista=?,estado=?,modalidade_gestao=?";
        $params=[$nome,$email!==''?$email:null,$idPerfil,$idEspecialista?:null,$estado,$modalidadeGestao];
        if($novaSenha!==''){ $sql.=",senha=?"; $params[]=password_hash($novaSenha,PASSWORD_DEFAULT); }
        $sql.=" WHERE id_utilizador=?"; $params[]=$id;
        $pdo->prepare($sql)->execute($params);

        $pdo->prepare("DELETE FROM utilizador_regiao WHERE id_utilizador=?")->execute([$id]);
        $pdo->prepare("DELETE FROM utilizador_ramo WHERE id_utilizador=?")->execute([$id]);
        $pdo->prepare("DELETE FROM utilizador_unidade WHERE id_utilizador=?")->execute([$id]);
        $pdo->prepare('DELETE FROM utilizador_local_servico WHERE id_utilizador=?')->execute([$id]);
        $insLocal=$pdo->prepare('INSERT INTO utilizador_local_servico(id_utilizador,local_servico) VALUES(?,?)');
        foreach ($locaisServico as $loc) $insLocal->execute([$id,$loc]);

        if($perfilEscolhido['nivel_acesso']==='REGIAO'){ $q=$pdo->prepare("INSERT INTO utilizador_regiao(id_utilizador,id_regiao) VALUES(?,?)");foreach($idsRegioes as $rid)$q->execute([$id,$rid]); } elseif($perfilEscolhido['nivel_acesso']==='RAMO'){
            $q=$pdo->prepare("INSERT INTO utilizador_ramo(id_utilizador,id_ramo) VALUES(?,?)");
            foreach($idsRamos as $rid)$q->execute([$id,$rid]);
        }elseif($perfilEscolhido['nivel_acesso']==='UNIDADE'){
            $q=$pdo->prepare("INSERT INTO utilizador_unidade(id_utilizador,id_unidade) VALUES(?,?)");
            $qr2=$pdo->prepare("INSERT IGNORE INTO utilizador_ramo(id_utilizador,id_ramo) SELECT ?,id_ramo FROM unidades WHERE id_unidade=?");
            foreach($idsUnidades as $uid){$q->execute([$id,$uid]);$qr2->execute([$id,$uid]);}
        }

        if(!empty($_FILES['foto']['name'])&&is_uploaded_file($_FILES['foto']['tmp_name'])){
            $ext=strtolower(pathinfo($_FILES['foto']['name'],PATHINFO_EXTENSION));
            if(!in_array($ext,['jpg','jpeg','png','webp'],true)) throw new RuntimeException('Formato de fotografia não permitido.');
            $dir=app_public_path('uploads/utilizadores');if(!is_dir($dir))mkdir($dir,0775,true);
            $file='utilizador_'.$id.'_'.bin2hex(random_bytes(5)).'.'.$ext;
            if(!move_uploaded_file($_FILES['foto']['tmp_name'],$dir.DIRECTORY_SEPARATOR.$file))throw new RuntimeException('Não foi possível guardar a fotografia.');
            $pdo->prepare("UPDATE utilizadores SET foto=? WHERE id_utilizador=?")->execute(['uploads/utilizadores/'.$file,$id]);
        }

        $pdo->commit();
        registar_auditoria($pdo,'UTILIZADORES','ALTERACAO','UTILIZADORES','utilizadores',$id,'Utilizador atualizado.');

        if($uidAtual===$id){
            $st=$pdo->prepare("SELECT u.nome_utilizador,u.foto,u.tema,p.nome perfil_nome,p.nivel_acesso FROM utilizadores u INNER JOIN perfis p ON p.id_perfil=u.id_perfil WHERE u.id_utilizador=?");
            $st->execute([$id]);$me=$st->fetch(PDO::FETCH_ASSOC);
            $_SESSION['user']['nome']=$me['nome_utilizador'];
            $_SESSION['user']['foto']=$me['foto'];
            $_SESSION['user']['tema']=$me['tema'];
            $_SESSION['user']['perfil']=$me['perfil_nome'];
            $_SESSION['user']['nivel']=$me['nivel_acesso'];
        }
        $sucesso='Utilizador atualizado com sucesso.';
        $st=$pdo->prepare("SELECT u.*,p.nome perfil_nome,p.nivel_acesso perfil_nivel FROM utilizadores u INNER JOIN perfis p ON p.id_perfil=u.id_perfil WHERE u.id_utilizador=?");
        $st->execute([$id]);$utilizador=$st->fetch(PDO::FETCH_ASSOC);
        $qr->execute([$id]);$ramosSelecionados=array_map('intval',$qr->fetchAll(PDO::FETCH_COLUMN));
        $qu->execute([$id]);$unidadesSelecionadas=array_map('intval',$qu->fetchAll(PDO::FETCH_COLUMN));
    } catch(Throwable $e) {
        if($pdo->inTransaction())$pdo->rollBack();
        $erro='Não foi possível atualizar: '.$e->getMessage();
    }
}
?>
<?php require __DIR__.'/../layout/header.php'; ?>
<div class="module-page module-utilizador-form">
<section class="form-hero">
<div><span class="eyebrow">CONTROLO DE ACESSO</span><h1>Editar utilizador</h1><p>Identidade, especialista associado e âmbito de acesso.</p></div>
<a class="btn btn-secondary" href="<?=htmlspecialchars($returnTo)?>">← Voltar</a>
</section>
<?php if($erro):?><div class="erro form-alert"><?=htmlspecialchars($erro)?></div><?php endif;?>
<?php if($sucesso):?><div class="alert-success form-alert"><?=htmlspecialchars($sucesso)?></div><?php endif;?>
<form method="post" enctype="multipart/form-data" class="user-form">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
<input type="hidden" name="id_utilizador" value="<?=$id?>"><input type="hidden" name="return_to" value="<?=htmlspecialchars($returnTo,ENT_QUOTES)?>">
<section class="panel form-card">
<h2>Identidade de acesso</h2>
<div class="form-grid">
<label>Nome de utilizador *<input required name="nome_utilizador" value="<?=htmlspecialchars($utilizador['nome_utilizador'])?>"></label>
<label>E-mail<input type="email" name="email" value="<?=htmlspecialchars($utilizador['email']??'')?>"></label>
<label>Nova senha<input type="password" name="senha" autocomplete="new-password"></label>
<label>Confirmar senha<input type="password" name="senha_confirmacao" autocomplete="new-password"></label>
<label>Perfil *<select required name="id_perfil"><option value="">Selecione</option><?php foreach($perfisPermitidos as $p):?><option value="<?=$p['id_perfil']?>" <?=((int)$utilizador['id_perfil']===(int)$p['id_perfil'])?'selected':''?>><?=htmlspecialchars($p['nome'])?></option><?php endforeach;?></select></label>
<label>Estado<select name="estado"><option value="ATIVO" <?=$utilizador['estado']==='ATIVO'?'selected':''?>>ATIVO</option><option value="INATIVO" <?=$utilizador['estado']==='INATIVO'?'selected':''?>>INATIVO</option></select></label>
</div>
</section>
<section class="panel form-card">
<h2>Especialista associado</h2>
<label class="full"><select name="id_especialista"><option value="0">Não associar</option><?php foreach($especialistas as $e):?><option value="<?=$e['id_especialista']?>" <?=((int)$utilizador['id_especialista']===(int)$e['id_especialista'])?'selected':''?>><?=htmlspecialchars($e['nome_completo'].' — NIP '.($e['nip']??'—').' — BI '.($e['numero_bi']??'—'))?></option><?php endforeach;?></select></label>
<p class="help">A conta permanece ligada ao cadastro do especialista; não é criado um segundo especialista.</p>
</section>
<section class="panel form-card">
<h2>Âmbito de acesso</h2>
<label class="full">Modalidade de Gestão
<select name="modalidade_gestao" <?= $nivelAtual==='GLOBAL'?'':'disabled' ?>>
<option value="RAMO" <?= ($modalidadeSelecionada??'RAMO')==='RAMO'?'selected':'' ?>>Ramo — editar apenas no Local do próprio Ramo</option>
<option value="LOCAL" <?= ($modalidadeSelecionada??'RAMO')==='LOCAL'?'selected':'' ?>>Local de Serviço — gerir os especialistas colocados no Local autorizado, independentemente do Ramo</option>
<option value="COMBINADO" <?= ($modalidadeSelecionada??'RAMO')==='COMBINADO'?'selected':'' ?>>Combinado — Ramo e Locais de Serviço autorizados</option>
</select><?php if($nivelAtual!=='GLOBAL'): ?><input type="hidden" name="modalidade_gestao" value="<?=htmlspecialchars($modalidadeSelecionada??'RAMO')?>"><?php endif; ?>
<small>O acesso à consulta e as permissões de edição são validados no servidor. Locais de Serviço devem estar autorizados abaixo.</small></label>

<label id="campoRegioes" class="full">Regiões<select name="regioes[]" multiple size="4"><?php foreach($regioes as $r):?><option value="<?=$r['id_regiao']?>" <?=in_array((int)$r['id_regiao'],$regioesSelecionadas,true)?'selected':''?>><?=htmlspecialchars(($r['sigla']?:$r['nome']).' — '.$r['nome'])?></option><?php endforeach;?></select></label>
<div id="campoRamos" class="full"><div class="access-choice-title">Ramos autorizados para consulta</div><div class="access-choice-grid"><?php foreach($ramos as $r): ?><label class="access-choice"><input type="checkbox" name="ramos[]" value="<?=$r['id_ramo']?>" <?=in_array((int)$r['id_ramo'],$ramosSelecionados,true)?'checked':''?> ><span><?=htmlspecialchars(($r['sigla']?:$r['nome']).' — '.$r['nome'])?></span></label><?php endforeach; ?></div><small>Selecione um ou vários Ramos, independentemente dos Locais de Serviço.</small></div>
<div class="full"><div class="access-choice-title">Locais de Serviço autorizados para edição</div><div class="access-choice-grid"><?php foreach(($nivelAtual==='GLOBAL'?['EMG','EXE','FAN','MGA']:user_service_locations()) as $ls): ?><label class="access-choice"><input type="checkbox" name="locais_servico[]" value="<?=$ls?>" <?=in_array($ls,$locaisSelecionados,true)?'checked':''?> ><span><?=$ls?></span></label><?php endforeach; ?></div><small>No modo Combinado pode assinalar simultaneamente Ramos e Locais de Serviço. Os direitos de edição são validados no servidor.</small></div>
<label id="campoUnidades" class="full">Unidades<select name="unidades[]" multiple size="6"><?php foreach($unidades as $u):?><option value="<?=$u['id_unidade']?>" <?=in_array((int)$u['id_unidade'],$unidadesSelecionadas,true)?'selected':''?>><?=htmlspecialchars(($u['sigla']?:$u['nome']).' — '.$u['nome'])?></option><?php endforeach;?></select></label>
</section>
<section class="panel form-card">
<h2>Fotografia</h2>
<div class="photo-upload"><div class="photo-preview"><?php if(!empty($utilizador['foto'])):?><img src="<?=htmlspecialchars(app_file_url($utilizador['foto']))?>" alt="Foto"><?php else:?><span><?=htmlspecialchars(strtoupper(substr($utilizador['nome_utilizador'],0,1)))?></span><?php endif;?></div><input type="file" name="foto" accept="image/jpeg,image/png,image/webp"></div>
</section>
<div class="form-actions"><a class="btn btn-secondary" href="<?=htmlspecialchars($returnTo)?>">Cancelar</a><button class="btn btn-primary">Guardar alterações</button></div>
</form>

</div>
<?php require __DIR__.'/../layout/footer.php'; ?>
