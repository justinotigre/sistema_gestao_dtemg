<?php
require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/historico.php';
require_login();
$acaoInicial = (string)($_POST['acao'] ?? '');
if ($acaoInicial === 'adicionar' || (isset($_GET['novo']) && $_SERVER['REQUEST_METHOD'] !== 'POST')) {
    require_permission('EQUIPAMENTOS_CRIAR');
} else {
    require_permission('EQUIPAMENTOS_VISUALIZAR');
}


$pdo = db();
$uSess = $_SESSION['user'] ?? [];

// O formulário de novo equipamento é renderizado nesta página para preservar a rota,
// os filtros e os endereços relativos em instalações na raiz ou numa subpasta.

$mensagem = '';
$tipo_mensagem = '';


// ============================================================
// FUNÇÕES AUXILIARES
// ============================================================

function e($valor)
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

function redirect_equipment($params = [])
{
    $url = 'equipamentos.php';

    if (!empty($params)) {
        $url .= '?' . http_build_query($params);
    }

    header('Location: ' . $url);
    exit;
}

function garantir_pasta($pasta)
{
    if (!is_dir($pasta)) {
        mkdir($pasta, 0775, true);
    }
}

function nome_seguro_ficheiro($nome)
{
    $nome = basename($nome);

    $nome = preg_replace(
        '/[^A-Za-z0-9_\-.]/',
        '_',
        $nome
    );

    return $nome;
}

function caminho_publico_upload($relative)
{
    $relative = ltrim(str_replace(['\\', '/'], DIRECTORY_SEPARATOR, (string)$relative), DIRECTORY_SEPARATOR);
    return app_public_path($relative);
}

function equipamento_no_escopo(PDO $pdo, int $id): bool
{
    if (($GLOBALS['_equip_user_nivel'] ?? '') === 'GLOBAL') return true;
    $u = $_SESSION['user'] ?? [];
    if (($u['nivel'] ?? '') === 'GLOBAL') return true;
    if ($id <= 0) return false;

    $st = $pdo->prepare("SELECT id_ramo, id_regiao, id_unidade FROM equipamentos WHERE id_equipamento = ? LIMIT 1");
    $st->execute([$id]);
    $eq = $st->fetch(PDO::FETCH_ASSOC);
    if (!$eq) return false;

    if (($u['nivel'] ?? '') === 'RAMO') {
        $st = $pdo->prepare("SELECT 1 FROM utilizador_ramo WHERE id_utilizador = ? AND id_ramo = ? LIMIT 1");
        $st->execute([(int)$u['id'], (int)$eq['id_ramo']]);
        return (bool)$st->fetchColumn();
    }
    if (($u['nivel'] ?? '') === 'REGIAO') {
        $st = $pdo->prepare("SELECT 1 FROM utilizador_regiao WHERE id_utilizador=? AND id_regiao=? LIMIT 1");
        $st->execute([(int)$u['id'], (int)$eq['id_regiao']]);
        return (bool)$st->fetchColumn();
    }

    $st = $pdo->prepare("SELECT 1 FROM utilizador_unidade WHERE id_utilizador = ? AND id_unidade = ? LIMIT 1");
    $st->execute([(int)$u['id'], (int)$eq['id_unidade']]);
    return (bool)$st->fetchColumn();
}


// ============================================================
// PASTAS DE UPLOAD
// ============================================================

$diretorio_fotos = __DIR__ . '/../uploads/equipamentos/fotografias';
$diretorio_documentos = __DIR__ . '/../uploads/equipamentos/documentos';

garantir_pasta($diretorio_fotos);
garantir_pasta($diretorio_documentos);


// ============================================================
// DOWNLOAD DE FOTOGRAFIA
// ============================================================

if (isset($_GET['download_foto'])) {

    require_permission('FOTOGRAFIAS_VISUALIZAR');

    $id_fotografia = (int)$_GET['download_foto'];

    if ($id_fotografia <= 0) {
        http_response_code(400);
        exit('Fotografia inválida.');
    }

    $stmt = $pdo->prepare("
        SELECT
            id_fotografia,
            id_equipamento,
            nome_ficheiro,
            caminho_ficheiro
        FROM fotografias
        WHERE id_fotografia = :id
          AND id_equipamento IS NOT NULL
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id_fotografia
    ]);

    $foto = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$foto || !equipamento_no_escopo($pdo, (int)$foto['id_equipamento'])) {
        http_response_code(404);
        exit('Fotografia não encontrada.');
    }

    $base = realpath($diretorio_fotos);

    if ($base === false) {
        http_response_code(404);
        exit('Diretório das fotografias não encontrado.');
    }

    $caminho = str_replace(
        '\\',
        '/',
        $foto['caminho_ficheiro']
    );

    $caminho = ltrim($caminho, '/');

    $arquivo = realpath(caminho_publico_upload($caminho));

    if (
        $arquivo === false ||
        strpos(
            $arquivo,
            $base . DIRECTORY_SEPARATOR
        ) !== 0
    ) {
        http_response_code(403);
        exit('Acesso ao ficheiro não permitido.');
    }

    if (!is_file($arquivo)) {
        http_response_code(404);
        exit('Ficheiro não encontrado.');
    }

    $nome = basename($foto['nome_ficheiro']);

    $extensao = strtolower(
        pathinfo($arquivo, PATHINFO_EXTENSION)
    );

    $mimes = [
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'webp' => 'image/webp'
    ];

    $mime = $mimes[$extensao]
        ?? 'application/octet-stream';

    header('Content-Type: ' . $mime);
    header(
        'Content-Disposition: attachment; filename="' .
        str_replace('"', '', $nome) .
        '"'
    );
    header(
        'Content-Length: ' .
        filesize($arquivo)
    );
    header('Cache-Control: private, no-store');
    header('Pragma: no-cache');

    readfile($arquivo);
    exit;
}


// ============================================================
// DOWNLOAD DE DOCUMENTO
// ============================================================

if (isset($_GET['download_documento'])) {

    require_permission('DOCUMENTOS_VISUALIZAR');

    $id_documento = (int)$_GET['download_documento'];

    if ($id_documento <= 0) {
        http_response_code(400);
        exit('Documento inválido.');
    }

    $stmt = $pdo->prepare("
        SELECT
            id_documento,
            id_equipamento,
            nome_ficheiro,
            caminho_ficheiro
        FROM documentos
        WHERE id_documento = :id
          AND id_equipamento IS NOT NULL
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id_documento
    ]);

    $documento = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$documento || !equipamento_no_escopo($pdo, (int)$documento['id_equipamento'])) {
        http_response_code(404);
        exit('Documento não encontrado.');
    }

    $base = realpath($diretorio_documentos);

    if ($base === false) {
        http_response_code(404);
        exit('Diretório dos documentos não encontrado.');
    }

    $caminho = str_replace(
        '\\',
        '/',
        $documento['caminho_ficheiro']
    );

    $caminho = ltrim($caminho, '/');

    $arquivo = realpath(caminho_publico_upload($caminho));

    if (
        $arquivo === false ||
        strpos(
            $arquivo,
            $base . DIRECTORY_SEPARATOR
        ) !== 0
    ) {
        http_response_code(403);
        exit('Acesso ao ficheiro não permitido.');
    }

    if (!is_file($arquivo)) {
        http_response_code(404);
        exit('Ficheiro não encontrado.');
    }

    $nome = basename($documento['nome_ficheiro']);

    $extensao = strtolower(
        pathinfo($arquivo, PATHINFO_EXTENSION)
    );

    $mimes = [
        'pdf'  => 'application/pdf',
        'doc'  => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls'  => 'application/vnd.ms-excel',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png'
    ];

    $mime = $mimes[$extensao]
        ?? 'application/octet-stream';

    header('Content-Type: ' . $mime);
    header(
        'Content-Disposition: attachment; filename="' .
        str_replace('"', '', $nome) .
        '"'
    );
    header(
        'Content-Length: ' .
        filesize($arquivo)
    );
    header('Cache-Control: private, no-store');
    header('Pragma: no-cache');

    readfile($arquivo);
    exit;
}


// ============================================================
// LISTAS DE APOIO
// ============================================================

$ramos = $pdo->query("
    SELECT id_ramo, nome, sigla
    FROM ramo
    WHERE estado = 'ATIVO'
    ORDER BY nome ASC
")->fetchAll(PDO::FETCH_ASSOC);


$unidades = $pdo->query("
    SELECT id_unidade, id_ramo, nome, sigla
    FROM unidades
    WHERE estado = 'ATIVO'
    ORDER BY nome ASC
")->fetchAll(PDO::FETCH_ASSOC);

$especialistas_responsaveis = $pdo->query("
    SELECT e.id_especialista,e.id_ramo,dp.nome_completo,ds.nip,dp.numero_bi
    FROM especialistas e
    JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista
    LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista
    WHERE e.estado='ATIVO'
    ORDER BY dp.nome_completo
")->fetchAll(PDO::FETCH_ASSOC);


$regioes = $pdo->query("SELECT id_regiao,nome FROM regioes WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);

$tipos_equipamento = $pdo->query("
    SELECT id_tipo_equipamento, nome
    FROM tipos_equipamento
    WHERE estado = 'ATIVO'
    ORDER BY nome ASC
")->fetchAll(PDO::FETCH_ASSOC);


$estados_equipamento = $pdo->query("
    SELECT id_estado_equipamento, nome
    FROM estados_equipamento
    WHERE estado = 'ATIVO'
    ORDER BY nome ASC
")->fetchAll(PDO::FETCH_ASSOC);


$tipos_documento = $pdo->query("
    SELECT
        id_tipo_documento,
        nome
    FROM tipos_documento
    WHERE estado = 'ATIVO'
    ORDER BY nome ASC
")->fetchAll(PDO::FETCH_ASSOC);


// ============================================================
// AÇÕES POST
// ============================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $acao = $_POST['acao'] ?? '';


    // ========================================================
    // ADICIONAR EQUIPAMENTO
    // ========================================================

    if ($acao === 'adicionar') {

        require_permission('EQUIPAMENTOS_CRIAR');
        $return_post = safe_return_url($_POST['return_url'] ?? 'equipamentos.php', 'equipamentos.php');

        $id_ramo = !empty($_POST['id_ramo'])
            ? (int)$_POST['id_ramo']
            : null;

        $id_unidade = !empty($_POST['id_unidade']) ? (int)$_POST['id_unidade'] : null;
        $id_regiao = !empty($_POST['id_regiao']) ? (int)$_POST['id_regiao'] : null;
        $id_especialista_responsavel = !empty($_POST['id_especialista_responsavel']) ? (int)$_POST['id_especialista_responsavel'] : null;
        if ($id_unidade && !$id_regiao) { $qrg=$pdo->prepare('SELECT id_regiao FROM unidades WHERE id_unidade=?');$qrg->execute([$id_unidade]);$id_regiao=(int)($qrg->fetchColumn()?:0); }
        if ($id_unidade && $id_regiao && !(int)$pdo->query('SELECT COUNT(*) FROM unidades WHERE id_unidade='.(int)$id_unidade.' AND (id_regiao='.(int)$id_regiao.' OR id_regiao IS NULL)')->fetchColumn()) { $mensagem='A unidade selecionada não pertence à região indicada.'; $tipo_mensagem='erro'; }
        if ($id_unidade && !$id_regiao) { $qrg=$pdo->prepare('SELECT id_regiao FROM unidades WHERE id_unidade=?');$qrg->execute([$id_unidade]);$id_regiao=(int)($qrg->fetchColumn()?:0); }
        if ($id_unidade && $id_regiao && !(int)$pdo->query('SELECT COUNT(*) FROM unidades WHERE id_unidade='.(int)$id_unidade.' AND (id_regiao='.(int)$id_regiao.' OR id_regiao IS NULL)')->fetchColumn()) { $mensagem='A unidade selecionada não pertence à região indicada.'; $tipo_mensagem='erro'; }

        $id_tipo_equipamento =
            !empty($_POST['id_tipo_equipamento'])
            ? (int)$_POST['id_tipo_equipamento']
            : null;

        $designacao = trim(
            $_POST['designacao'] ?? ''
        );

        $marca = trim(
            $_POST['marca'] ?? ''
        );

        $modelo = trim(
            $_POST['modelo'] ?? ''
        );

        $numero_serie = trim(
            $_POST['numero_serie'] ?? ''
        );

        $numero_patrimonio = trim(
            $_POST['numero_patrimonio'] ?? ''
        );

        $quantidade_total = max(1, (int)($_POST['quantidade_total'] ?? 1));
        $quantidade_distribuida = max(0, (int)($_POST['quantidade_distribuida'] ?? 0));
        if ($quantidade_distribuida > $quantidade_total) { $mensagem='A quantidade distribuída não pode ultrapassar a quantidade total.'; $tipo_mensagem='erro'; }

        $data_aquisicao =
            !empty($_POST['data_aquisicao'])
            ? $_POST['data_aquisicao']
            : null;

        $id_estado_equipamento =
            !empty($_POST['id_estado_equipamento'])
            ? (int)$_POST['id_estado_equipamento']
            : null;

        $localizacao = trim(
            $_POST['localizacao'] ?? ''
        );

        $descricao = trim(
            $_POST['descricao'] ?? ''
        );

        $observacoes = trim(
            $_POST['observacoes'] ?? ''
        );


        if ($id_ramo <= 0) {

            $mensagem = 'Selecione o ramo da responsabilidade.';
            $tipo_mensagem = 'erro';

        } elseif ($id_unidade && !(int)$pdo->query('SELECT COUNT(*) FROM unidades WHERE id_unidade='.(int)$id_unidade.' AND id_ramo='.(int)$id_ramo.' AND estado=\'ATIVO\'')->fetchColumn()) {
            $mensagem = 'A unidade responsável não pertence ao ramo selecionado.';
            $tipo_mensagem = 'erro';
        }
        elseif (($uSess['nivel'] ?? '') === 'REGIAO' && (!$id_regiao || !(int)$pdo->query('SELECT COUNT(*) FROM utilizador_regiao WHERE id_utilizador='.(int)$uSess['id'].' AND id_regiao='.(int)$id_regiao)->fetchColumn())) { $mensagem='A região selecionada está fora do seu âmbito.'; $tipo_mensagem='erro'; }
        elseif (($uSess['nivel'] ?? '') === 'RAMO' && !(int)$pdo->query('SELECT COUNT(*) FROM utilizador_ramo WHERE id_utilizador='.(int)$uSess['id'].' AND id_ramo='.(int)$id_ramo)->fetchColumn()) { $mensagem='O ramo selecionado está fora do seu âmbito.'; $tipo_mensagem='erro'; }
        elseif ($id_especialista_responsavel && !(int)$pdo->query('SELECT COUNT(*) FROM especialistas WHERE id_especialista='.(int)$id_especialista_responsavel.' AND id_ramo='.(int)$id_ramo.' AND estado=\'ATIVO\'')->fetchColumn()) { $mensagem='O responsável selecionado não pertence ao ramo.'; $tipo_mensagem='erro'; }
        elseif (($uSess['nivel'] ?? '') === 'REGIAO' && (!$id_regiao || !(int)$pdo->query('SELECT COUNT(*) FROM utilizador_regiao WHERE id_utilizador='.(int)$uSess['id'].' AND id_regiao='.(int)$id_regiao)->fetchColumn())) { $mensagem='A região selecionada está fora do seu âmbito.'; $tipo_mensagem='erro'; }
        elseif (($uSess['nivel'] ?? '') === 'RAMO' && !(int)$pdo->query('SELECT COUNT(*) FROM utilizador_ramo WHERE id_utilizador='.(int)$uSess['id'].' AND id_ramo='.(int)$id_ramo)->fetchColumn()) { $mensagem='O ramo selecionado está fora do seu âmbito.'; $tipo_mensagem='erro'; }
        elseif ($id_especialista_responsavel && !(int)$pdo->query('SELECT COUNT(*) FROM especialistas WHERE id_especialista='.(int)$id_especialista_responsavel.' AND id_ramo='.(int)$id_ramo.' AND estado=\'ATIVO\'')->fetchColumn()) { $mensagem='O responsável selecionado não pertence ao ramo.'; $tipo_mensagem='erro'; }
        if (!$mensagem && $designacao === '') {
            $mensagem = 'A designação do equipamento é obrigatória.';
            $tipo_mensagem = 'erro';
        }

        if (!$mensagem) {
            try {

                $stmt = $pdo->prepare("
                    INSERT INTO equipamentos (
                        id_ramo,
                        id_regiao,
                        id_unidade,
                        id_especialista_responsavel,
                        id_tipo_equipamento,
                        designacao,
                        marca,
                        modelo,
                        numero_serie,
                        numero_patrimonio,
                        data_aquisicao,
                        quantidade_total,
                        quantidade_distribuida,
                        id_estado_equipamento,
                        localizacao,
                        descricao,
                        observacoes
                    )
                    VALUES (
                        :id_ramo,
                        :id_regiao,
                        :id_unidade,
                        :id_especialista_responsavel,
                        :id_tipo_equipamento,
                        :designacao,
                        :marca,
                        :modelo,
                        :numero_serie,
                        :numero_patrimonio,
                        :data_aquisicao,
                        :quantidade_total,
                        :quantidade_distribuida,
                        :id_estado_equipamento,
                        :localizacao,
                        :descricao,
                        :observacoes
                    )
                ");

                $stmt->execute([

                    ':id_ramo' =>
                        $id_ramo,

                    ':id_regiao' => $id_regiao,
                    ':id_unidade' => $id_unidade,
                    ':id_especialista_responsavel' => $id_especialista_responsavel,

                    ':id_tipo_equipamento' =>
                        $id_tipo_equipamento,

                    ':designacao' =>
                        $designacao,

                    ':marca' =>
                        $marca !== ''
                            ? $marca
                            : null,

                    ':modelo' =>
                        $modelo !== ''
                            ? $modelo
                            : null,

                    ':numero_serie' =>
                        $numero_serie !== ''
                            ? $numero_serie
                            : null,

                    ':numero_patrimonio' =>
                        $numero_patrimonio !== ''
                            ? $numero_patrimonio
                            : null,

                    ':data_aquisicao' =>
                        $data_aquisicao,

                    ':quantidade_total' => $quantidade_total,
                    ':quantidade_distribuida' => $quantidade_distribuida,

                    ':id_estado_equipamento' =>
                        $id_estado_equipamento,

                    ':localizacao' =>
                        $localizacao !== ''
                            ? $localizacao
                            : null,

                    ':descricao' =>
                        $descricao !== ''
                            ? $descricao
                            : null,

                    ':observacoes' =>
                        $observacoes !== ''
                            ? $observacoes
                            : null
                ]);

                $novoEquipamentoId=(int)$pdo->lastInsertId();
                registar_historico_equipamento($pdo,$novoEquipamentoId,'CRIACAO','designacao',null,$designacao);
                registar_auditoria($pdo,'EQUIPAMENTOS','CRIACAO','EQUIPAMENTOS','equipamentos',$novoEquipamentoId,'Equipamento criado.');
                // Após criar, abrir imediatamente a ficha do equipamento.
                // A pesquisa continua acessível pela ação Voltar na própria ficha.
                header('Location: ' . app_url('modulos/equipamento_resumo.php?id=' . $novoEquipamentoId));
                exit;
            }

            catch (PDOException $e) {
                error_log('[Sistema Especialistas][EQUIPAMENTOS][CRIAR] ' . $e->getMessage());
                if ($e->getCode() == '23000') {

                    $mensagem =
                        'Não foi possível cadastrar. ' .
                        'O número de série já pode estar registado.';

                } else {

                    $mensagem =
                        'Erro ao cadastrar o equipamento.';
                }

                $tipo_mensagem = 'erro';
            }
        }
    }


    // ========================================================
    // ATUALIZAR EQUIPAMENTO
    // ========================================================

    elseif ($acao === 'atualizar') {

        require_permission('EQUIPAMENTOS_EDITAR');
        $return_post = safe_return_url($_POST['return_url'] ?? 'equipamentos.php', 'equipamentos.php');

        $id_equipamento =
            (int)($_POST['id_equipamento'] ?? 0);

        if (!equipamento_no_escopo($pdo, $id_equipamento)) {
            $mensagem = 'Equipamento fora do seu âmbito de acesso.';
            $tipo_mensagem = 'erro';
        }

        $id_ramo =
            !empty($_POST['id_ramo'])
                ? (int)$_POST['id_ramo']
                : null;

        $id_unidade = !empty($_POST['id_unidade']) ? (int)$_POST['id_unidade'] : null;
        $id_regiao = !empty($_POST['id_regiao']) ? (int)$_POST['id_regiao'] : null;
        $id_especialista_responsavel = !empty($_POST['id_especialista_responsavel']) ? (int)$_POST['id_especialista_responsavel'] : null;

        $id_tipo_equipamento =
            !empty($_POST['id_tipo_equipamento'])
                ? (int)$_POST['id_tipo_equipamento']
                : null;

        $designacao =
            trim($_POST['designacao'] ?? '');

        $marca =
            trim($_POST['marca'] ?? '');

        $modelo =
            trim($_POST['modelo'] ?? '');

        $numero_serie =
            trim($_POST['numero_serie'] ?? '');

        $numero_patrimonio =
            trim($_POST['numero_patrimonio'] ?? '');

        $quantidade_total = max(1, (int)($_POST['quantidade_total'] ?? 1));
        $quantidade_distribuida = max(0, (int)($_POST['quantidade_distribuida'] ?? 0));
        if ($quantidade_distribuida > $quantidade_total) { $mensagem='A quantidade distribuída não pode ultrapassar a quantidade total.'; $tipo_mensagem='erro'; }

        $data_aquisicao =
            !empty($_POST['data_aquisicao'])
                ? $_POST['data_aquisicao']
                : null;

        $id_estado_equipamento =
            !empty($_POST['id_estado_equipamento'])
                ? (int)$_POST['id_estado_equipamento']
                : null;

        $localizacao =
            trim($_POST['localizacao'] ?? '');

        $descricao =
            trim($_POST['descricao'] ?? '');

        $observacoes =
            trim($_POST['observacoes'] ?? '');


        if ($id_equipamento <= 0 || !equipamento_no_escopo($pdo, $id_equipamento)) {

            $mensagem =
                'Equipamento inválido ou fora do seu âmbito de acesso.';

            $tipo_mensagem = 'erro';

        } elseif ($id_ramo <= 0) {

            $mensagem = 'Selecione o ramo da responsabilidade.';
            $tipo_mensagem = 'erro';

        } elseif ($id_unidade && !(int)$pdo->query('SELECT COUNT(*) FROM unidades WHERE id_unidade='.(int)$id_unidade.' AND id_ramo='.(int)$id_ramo.' AND estado=\'ATIVO\'')->fetchColumn()) {

            $mensagem = 'A unidade responsável não pertence ao ramo selecionado.';
            $tipo_mensagem = 'erro';

        } elseif ($designacao === '') {

            $mensagem =
                'A designação do equipamento é obrigatória.';

            $tipo_mensagem = 'erro';

        } else {

            try {

                $stmt = $pdo->prepare("
                    UPDATE equipamentos
                    SET
                        id_ramo = :id_ramo,
                        id_regiao = :id_regiao,
                        id_unidade = :id_unidade,
                        id_especialista_responsavel = :id_especialista_responsavel,
                        id_tipo_equipamento = :id_tipo_equipamento,
                        designacao = :designacao,
                        marca = :marca,
                        modelo = :modelo,
                        numero_serie = :numero_serie,
                        numero_patrimonio = :numero_patrimonio,
                        data_aquisicao = :data_aquisicao,
                        quantidade_total = :quantidade_total,
                        quantidade_distribuida = :quantidade_distribuida,
                        id_estado_equipamento = :id_estado_equipamento,
                        localizacao = :localizacao,
                        descricao = :descricao,
                        observacoes = :observacoes
                    WHERE id_equipamento = :id_equipamento
                ");

                $stmt->execute([

                    ':id_ramo' =>
                        $id_ramo,

                    ':id_regiao' => $id_regiao,
                    ':id_unidade' => $id_unidade,
                    ':id_especialista_responsavel' => $id_especialista_responsavel,

                    ':id_tipo_equipamento' =>
                        $id_tipo_equipamento,

                    ':designacao' =>
                        $designacao,

                    ':marca' =>
                        $marca !== ''
                            ? $marca
                            : null,

                    ':modelo' =>
                        $modelo !== ''
                            ? $modelo
                            : null,

                    ':numero_serie' =>
                        $numero_serie !== ''
                            ? $numero_serie
                            : null,

                    ':numero_patrimonio' =>
                        $numero_patrimonio !== ''
                            ? $numero_patrimonio
                            : null,

                    ':data_aquisicao' =>
                        $data_aquisicao,

                    ':quantidade_total' => $quantidade_total,
                    ':quantidade_distribuida' => $quantidade_distribuida,

                    ':id_estado_equipamento' =>
                        $id_estado_equipamento,

                    ':localizacao' =>
                        $localizacao !== ''
                            ? $localizacao
                            : null,

                    ':descricao' =>
                        $descricao !== ''
                            ? $descricao
                            : null,

                    ':observacoes' =>
                        $observacoes !== ''
                            ? $observacoes
                            : null,

                    ':id_equipamento' =>
                        $id_equipamento
                ]);

                registar_historico_equipamento($pdo,$id_equipamento,'ALTERACAO_DADOS','designacao',null,$designacao);
                registar_auditoria($pdo,'EQUIPAMENTOS','ALTERACAO','EQUIPAMENTOS','equipamentos',$id_equipamento,'Equipamento atualizado.');
                header('Location: ' . $return_post . (str_contains($return_post, '?') ? '&' : '?') . 'sucesso=atualizado');
                exit;
            }

            catch (PDOException $e) {
                error_log('[Sistema Especialistas][EQUIPAMENTOS][CRIAR] ' . $e->getMessage());
                if ($e->getCode() == '23000') {

                    $mensagem =
                        'Não foi possível atualizar. ' .
                        'O número de série já pode estar registado ' .
                        'noutro equipamento.';

                } else {

                    $mensagem =
                        'Erro ao atualizar o equipamento.';
                }

                $tipo_mensagem = 'erro';
            }
        }
    }


    // ========================================================
    // ELIMINAR EQUIPAMENTO
    // ========================================================

    elseif ($acao === 'eliminar') {

        require_permission('EQUIPAMENTOS_ELIMINAR');

        $id_equipamento =
            (int)($_POST['id_equipamento'] ?? 0);

        if ($id_equipamento <= 0 || !equipamento_no_escopo($pdo, $id_equipamento)) {

            $mensagem =
                'Equipamento inválido ou fora do seu âmbito de acesso.';

            $tipo_mensagem = 'erro';

        } else {

            try {

                $stmt = $pdo->prepare("
                    DELETE FROM equipamentos
                    WHERE id_equipamento = :id
                ");

                registar_historico_equipamento($pdo,$id_equipamento,'ELIMINACAO','designacao',null,null);
                $stmt->execute([
                    ':id' => $id_equipamento
                ]);

                registar_auditoria($pdo,'EQUIPAMENTOS','ELIMINACAO','EQUIPAMENTOS','equipamentos',$id_equipamento,'Equipamento eliminado.');
                redirect_equipment([
                    'sucesso' => 'eliminado'
                ]);
            }

            catch (PDOException $e) {

                $mensagem =
                    'Não foi possível eliminar este equipamento. ' .
                    'Existem registos associados a ele.';

                $tipo_mensagem = 'erro';
            }
        }
    }


    // ========================================================
    // UPLOAD DE FOTOGRAFIA
    // ========================================================

    elseif ($acao === 'upload_foto') {

        require_permission('FOTOGRAFIAS_CRIAR');

        $id_equipamento =
            (int)($_POST['id_equipamento'] ?? 0);

        if (
            $id_equipamento <= 0 ||
            !equipamento_no_escopo($pdo, $id_equipamento) ||
            empty($_FILES['fotografia']['name'])
        ) {

            $mensagem =
                'Selecione uma fotografia válida.';

            $tipo_mensagem = 'erro';

        } else {

            $arquivo = $_FILES['fotografia'];

            if ($arquivo['error'] !== UPLOAD_ERR_OK) {

                $mensagem =
                    'Erro durante o envio da fotografia.';

                $tipo_mensagem = 'erro';

            } elseif ($arquivo['size'] > 8 * 1024 * 1024) {

                $mensagem =
                    'A fotografia não pode ultrapassar 8 MB.';

                $tipo_mensagem = 'erro';

            } else {

                $extensao = strtolower(
                    pathinfo(
                        $arquivo['name'],
                        PATHINFO_EXTENSION
                    )
                );

                $permitidas = [
                    'jpg',
                    'jpeg',
                    'png',
                    'webp'
                ];

                if (!in_array($extensao, $permitidas, true)) {

                    $mensagem =
                        'Formato de fotografia não permitido.';

                    $tipo_mensagem = 'erro';

                } else {

                    $nome_original =
                        nome_seguro_ficheiro(
                            $arquivo['name']
                        );

                    $nome_unico =
                        date('YmdHis') .
                        '_' .
                        bin2hex(random_bytes(6)) .
                        '.' .
                        $extensao;

                    $destino =
                        $diretorio_fotos .
                        DIRECTORY_SEPARATOR .
                        $nome_unico;

                    if (
                        move_uploaded_file(
                            $arquivo['tmp_name'],
                            $destino
                        )
                    ) {

                        $caminho_bd =
                            'uploads/equipamentos/fotografias/' .
                            $nome_unico;

                        $principal =
                            !empty($_POST['principal'])
                                ? 1
                                : 0;

                        if ($principal) {

                            $stmt = $pdo->prepare("
                                UPDATE fotografias
                                SET principal = 0
                                WHERE id_equipamento = :id
                            ");

                            $stmt->execute([
                                ':id' =>
                                    $id_equipamento
                            ]);
                        }

                        $stmt = $pdo->prepare("
                            INSERT INTO fotografias (
                                id_especialista,
                                id_equipamento,
                                nome_ficheiro,
                                caminho_ficheiro,
                                principal,
                                descricao
                            )
                            VALUES (
                                NULL,
                                :id_equipamento,
                                :nome_ficheiro,
                                :caminho_ficheiro,
                                :principal,
                                :descricao
                            )
                        ");

                        $stmt->execute([

                            ':id_equipamento' =>
                                $id_equipamento,

                            ':nome_ficheiro' =>
                                $nome_original,

                            ':caminho_ficheiro' =>
                                $caminho_bd,

                            ':principal' =>
                                $principal,

                            ':descricao' =>
                                trim(
                                    $_POST['descricao_foto'] ?? ''
                                ) ?: null
                        ]);

                        redirect_equipment([
                            'sucesso' => 'foto_adicionada'
                        ]);

                    } else {

                        $mensagem =
                            'Não foi possível guardar a fotografia.';

                        $tipo_mensagem = 'erro';
                    }
                }
            }
        }
    }


    // ========================================================
    // DEFINIR FOTO PRINCIPAL
    // ========================================================

    elseif ($acao === 'foto_principal') {

        require_permission('FOTOGRAFIAS_EDITAR');

        $id_fotografia =
            (int)($_POST['id_fotografia'] ?? 0);

        $id_equipamento =
            (int)($_POST['id_equipamento'] ?? 0);

        if (
            $id_fotografia <= 0 ||
            $id_equipamento <= 0 ||
            !equipamento_no_escopo($pdo, $id_equipamento)
        ) {

            $mensagem =
                'Fotografia inválida.';

            $tipo_mensagem = 'erro';

        } else {

            try {

                $pdo->beginTransaction();

                $stmt = $pdo->prepare("
                    UPDATE fotografias
                    SET principal = 0
                    WHERE id_equipamento = :id
                ");

                $stmt->execute([
                    ':id' => $id_equipamento
                ]);

                $stmt = $pdo->prepare("
                    UPDATE fotografias
                    SET principal = 1
                    WHERE id_fotografia = :foto
                      AND id_equipamento = :id
                ");

                $stmt->execute([
                    ':foto' =>
                        $id_fotografia,

                    ':id' =>
                        $id_equipamento
                ]);

                $pdo->commit();

                redirect_equipment([
                    'sucesso' => 'foto_principal'
                ]);

            } catch (PDOException $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $mensagem =
                    'Não foi possível definir a fotografia principal.';

                $tipo_mensagem = 'erro';
            }
        }
    }


    // ========================================================
    // ELIMINAR FOTOGRAFIA
    // ========================================================

    elseif ($acao === 'eliminar_foto') {

        require_permission('FOTOGRAFIAS_ELIMINAR');

        $id_fotografia =
            (int)($_POST['id_fotografia'] ?? 0);

        if ($id_fotografia <= 0) {

            $mensagem =
                'Fotografia inválida.';

            $tipo_mensagem = 'erro';

        } else {

            try {

                $stmt = $pdo->prepare("
                    SELECT caminho_ficheiro, id_equipamento
                    FROM fotografias
                    WHERE id_fotografia = :id
                ");

                $stmt->execute([
                    ':id' => $id_fotografia
                ]);

                $foto =
                    $stmt->fetch(PDO::FETCH_ASSOC);

                if ($foto && equipamento_no_escopo($pdo, (int)$foto['id_equipamento'])) {

                    $arquivo = caminho_publico_upload($foto['caminho_ficheiro']);

                    if (is_file($arquivo)) {
                        @unlink($arquivo);
                    }

                    $stmt = $pdo->prepare("
                        DELETE FROM fotografias
                        WHERE id_fotografia = :id
                    ");

                    $stmt->execute([
                        ':id' =>
                            $id_fotografia
                    ]);
                }

                redirect_equipment([
                    'sucesso' => 'foto_eliminada'
                ]);

            } catch (PDOException $e) {

                $mensagem =
                    'Não foi possível eliminar a fotografia.';

                $tipo_mensagem = 'erro';
            }
        }
    }


    // ========================================================
    // UPLOAD DE DOCUMENTO
    // ========================================================

    elseif ($acao === 'upload_documento') {

        require_permission('DOCUMENTOS_CRIAR');

        $id_equipamento =
            (int)($_POST['id_equipamento'] ?? 0);

        $id_tipo_documento =
            (int)($_POST['id_tipo_documento'] ?? 0);

        $titulo =
            trim($_POST['titulo'] ?? '');

        if (
            $id_equipamento <= 0 ||
            !equipamento_no_escopo($pdo, $id_equipamento) ||
            $id_tipo_documento <= 0 ||
            $titulo === '' ||
            empty($_FILES['documento']['name'])
        ) {

            $mensagem =
                'Preencha o título, tipo de documento e selecione o ficheiro.';

            $tipo_mensagem = 'erro';

        } else {

            $arquivo = $_FILES['documento'];

            if ($arquivo['error'] !== UPLOAD_ERR_OK) {

                $mensagem =
                    'Erro durante o envio do documento.';

                $tipo_mensagem = 'erro';

            } elseif ($arquivo['size'] > 15 * 1024 * 1024) {

                $mensagem =
                    'O documento não pode ultrapassar 15 MB.';

                $tipo_mensagem = 'erro';

            } else {

                $extensao = strtolower(
                    pathinfo(
                        $arquivo['name'],
                        PATHINFO_EXTENSION
                    )
                );

                $permitidas = [
                    'pdf',
                    'doc',
                    'docx',
                    'xls',
                    'xlsx',
                    'jpg',
                    'jpeg',
                    'png'
                ];

                if (!in_array($extensao, $permitidas, true)) {

                    $mensagem =
                        'Formato de documento não permitido.';

                    $tipo_mensagem = 'erro';

                } else {

                    $nome_original =
                        nome_seguro_ficheiro(
                            $arquivo['name']
                        );

                    $nome_unico =
                        date('YmdHis') .
                        '_' .
                        bin2hex(random_bytes(6)) .
                        '.' .
                        $extensao;

                    $destino =
                        $diretorio_documentos .
                        DIRECTORY_SEPARATOR .
                        $nome_unico;

                    if (
                        move_uploaded_file(
                            $arquivo['tmp_name'],
                            $destino
                        )
                    ) {

                        $caminho_bd =
                            'uploads/equipamentos/documentos/' .
                            $nome_unico;

                        $stmt = $pdo->prepare("
                            INSERT INTO documentos (
                                id_especialista,
                                id_equipamento,
                                id_tipo_documento,
                                titulo,
                                nome_ficheiro,
                                caminho_ficheiro,
                                data_documento,
                                data_validade,
                                descricao
                            )
                            VALUES (
                                NULL,
                                :id_equipamento,
                                :id_tipo_documento,
                                :titulo,
                                :nome_ficheiro,
                                :caminho_ficheiro,
                                :data_documento,
                                :data_validade,
                                :descricao
                            )
                        ");

                        $stmt->execute([

                            ':id_equipamento' =>
                                $id_equipamento,

                            ':id_tipo_documento' =>
                                $id_tipo_documento,

                            ':titulo' =>
                                $titulo,

                            ':nome_ficheiro' =>
                                $nome_original,

                            ':caminho_ficheiro' =>
                                $caminho_bd,

                            ':data_documento' =>
                                !empty($_POST['data_documento'])
                                    ? $_POST['data_documento']
                                    : null,

                            ':data_validade' =>
                                !empty($_POST['data_validade'])
                                    ? $_POST['data_validade']
                                    : null,

                            ':descricao' =>
                                trim(
                                    $_POST['descricao_documento'] ?? ''
                                ) ?: null
                        ]);

                        redirect_equipment([
                            'sucesso' => 'documento_adicionado'
                        ]);

                    } else {

                        $mensagem =
                            'Não foi possível guardar o documento.';

                        $tipo_mensagem = 'erro';
                    }
                }
            }
        }
    }


    // ========================================================
    // ELIMINAR DOCUMENTO
    // ========================================================

    elseif ($acao === 'eliminar_documento') {

        require_permission('DOCUMENTOS_ELIMINAR');

        $id_documento =
            (int)($_POST['id_documento'] ?? 0);

        if ($id_documento <= 0) {

            $mensagem =
                'Documento inválido.';

            $tipo_mensagem = 'erro';

        } else {

            try {

                $stmt = $pdo->prepare("
                    SELECT caminho_ficheiro, id_equipamento
                    FROM documentos
                    WHERE id_documento = :id
                ");

                $stmt->execute([
                    ':id' =>
                        $id_documento
                ]);

                $documento =
                    $stmt->fetch(PDO::FETCH_ASSOC);

                if ($documento && equipamento_no_escopo($pdo, (int)$documento['id_equipamento'])) {

                    $arquivo = caminho_publico_upload($documento['caminho_ficheiro']);

                    if (is_file($arquivo)) {
                        @unlink($arquivo);
                    }

                    $stmt = $pdo->prepare("
                        DELETE FROM documentos
                        WHERE id_documento = :id
                    ");

                    $stmt->execute([
                        ':id' =>
                            $id_documento
                    ]);
                }

                redirect_equipment([
                    'sucesso' => 'documento_eliminado'
                ]);

            } catch (PDOException $e) {

                $mensagem =
                    'Não foi possível eliminar o documento.';

                $tipo_mensagem = 'erro';
            }
        }
    }
}


// ============================================================
// MENSAGENS
// ============================================================

if (isset($_GET['sucesso'])) {

    switch ($_GET['sucesso']) {

        case 'adicionado':
            $mensagem =
                'Equipamento cadastrado com sucesso.';
            $tipo_mensagem = 'sucesso';
            break;

        case 'atualizado':
            $mensagem =
                'Equipamento atualizado com sucesso.';
            $tipo_mensagem = 'sucesso';
            break;

        case 'eliminado':
            $mensagem =
                'Equipamento eliminado com sucesso.';
            $tipo_mensagem = 'sucesso';
            break;

        case 'foto_adicionada':
            $mensagem =
                'Fotografia importada com sucesso.';
            $tipo_mensagem = 'sucesso';
            break;

        case 'foto_principal':
            $mensagem =
                'Fotografia principal atualizada.';
            $tipo_mensagem = 'sucesso';
            break;

        case 'foto_eliminada':
            $mensagem =
                'Fotografia eliminada com sucesso.';
            $tipo_mensagem = 'sucesso';
            break;

        case 'documento_adicionado':
            $mensagem =
                'Documento importado com sucesso.';
            $tipo_mensagem = 'sucesso';
            break;

        case 'documento_eliminado':
            $mensagem =
                'Documento eliminado com sucesso.';
            $tipo_mensagem = 'sucesso';
            break;
    }
}


// ============================================================
// EDIÇÃO
// ============================================================

$equipamento_editar = null;

if (isset($_GET['editar'])) {

    require_permission('EQUIPAMENTOS_EDITAR');

    $id_editar =
        (int)$_GET['editar'];

    if ($id_editar > 0 && equipamento_no_escopo($pdo, $id_editar)) {

        $stmt = $pdo->prepare("
            SELECT
                id_equipamento,
                id_ramo,
                id_regiao,
                id_unidade,
                id_especialista_responsavel,
                id_tipo_equipamento,
                designacao,
                marca,
                modelo,
                numero_serie,
                numero_patrimonio,
                data_aquisicao,
                quantidade_total,
                quantidade_distribuida,
                id_estado_equipamento,
                localizacao,
                descricao,
                observacoes
            FROM equipamentos
            WHERE id_equipamento = :id
        ");

        $stmt->execute([
            ':id' =>
                $id_editar
        ]);

        $equipamento_editar =
            $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$equipamento_editar) {

            $mensagem =
                'Equipamento não encontrado.';

            $tipo_mensagem = 'erro';
        }
    }
}


// ============================================================
// PESQUISA
// ============================================================

$pesquisa = trim($_GET['pesquisa'] ?? '');
$filtro_ramo = (int)($_GET['filtro_ramo'] ?? 0);
$filtro_unidade = (int)($_GET['filtro_unidade'] ?? 0);
$filtro_regiao = (int)($_GET['filtro_regiao'] ?? 0);
$filtro_tipo = (int)($_GET['filtro_tipo'] ?? 0);
$filtro_estado = (int)($_GET['filtro_estado'] ?? 0);

$returnParams = array_filter([
    'pesquisa' => $pesquisa, 'filtro_ramo' => $filtro_ramo, 'filtro_regiao' => $filtro_regiao, 'filtro_unidade' => $filtro_unidade,
    'filtro_tipo' => $filtro_tipo, 'filtro_estado' => $filtro_estado
], fn($v)=>$v!=='' && $v!==0);
$return_url = 'equipamentos.php' . ($returnParams ? '?' . http_build_query($returnParams) : '');
$return_url_safe = safe_return_url($_GET['return'] ?? $return_url, $return_url);

$sql = "
    SELECT
        e.*,

        r.nome AS ramo_nome,
        r.sigla AS ramo_sigla,
        r.cor_principal AS ramo_cor,

        u.nome AS unidade_nome,
        u.sigla AS unidade_sigla,
        rg.nome AS regiao_nome,
        te.nome AS tipo_nome,
        dp.nome_completo AS responsavel_nome,

        ee.nome AS estado_nome

    FROM equipamentos e

    INNER JOIN ramo r
        ON r.id_ramo = e.id_ramo

    LEFT JOIN unidades u
        ON u.id_unidade = e.id_unidade
    LEFT JOIN regioes rg ON rg.id_regiao=e.id_regiao
    LEFT JOIN especialistas es ON es.id_especialista=e.id_especialista_responsavel
    LEFT JOIN dados_pessoais dp ON dp.id_especialista=es.id_especialista


    LEFT JOIN tipos_equipamento te
        ON te.id_tipo_equipamento =
           e.id_tipo_equipamento

    LEFT JOIN estados_equipamento ee
        ON ee.id_estado_equipamento =
           e.id_estado_equipamento
";

$params = [];
$scopeWhere = '1=1';
$uSess = $_SESSION['user'] ?? [];
if (($uSess['nivel'] ?? '') === 'RAMO') {
    $stScope = $pdo->prepare('SELECT id_ramo FROM utilizador_ramo WHERE id_utilizador = ?');
    $stScope->execute([(int)$uSess['id']]);
    $idsScope = array_map('intval', $stScope->fetchAll(PDO::FETCH_COLUMN));
    if (!$idsScope) { $scopeWhere = '0=1'; }
    else { $scopeWhere = 'e.id_ramo IN (' . implode(',', $idsScope) . ')'; }
} elseif (($uSess['nivel'] ?? '') === 'REGIAO') {
    $stScope = $pdo->prepare('SELECT id_regiao FROM utilizador_regiao WHERE id_utilizador = ?');
    $stScope->execute([(int)$uSess['id']]);
    $idsScope = array_map('intval', $stScope->fetchAll(PDO::FETCH_COLUMN));
    if (!$idsScope) { $scopeWhere = '0=1'; } else { $scopeWhere = 'e.id_regiao IN (' . implode(',', $idsScope) . ')'; }
} elseif (($uSess['nivel'] ?? '') === 'UNIDADE') {
    $stScope = $pdo->prepare('SELECT id_unidade FROM utilizador_unidade WHERE id_utilizador = ?');
    $stScope->execute([(int)$uSess['id']]);
    $idsScope = array_map('intval', $stScope->fetchAll(PDO::FETCH_COLUMN));
    if (!$idsScope) { $scopeWhere = '0=1'; }
    else { $scopeWhere = 'e.id_unidade IN (' . implode(',', $idsScope) . ')'; }
}

$conditions = [$scopeWhere];
if ($pesquisa !== '') {
    $conditions[] = '(e.designacao LIKE :pesquisa OR e.marca LIKE :pesquisa OR e.modelo LIKE :pesquisa OR e.numero_serie LIKE :pesquisa OR e.numero_patrimonio LIKE :pesquisa OR e.localizacao LIKE :pesquisa OR r.nome LIKE :pesquisa OR u.nome LIKE :pesquisa OR te.nome LIKE :pesquisa OR ee.nome LIKE :pesquisa)';
    $params[':pesquisa'] = '%' . $pesquisa . '%';
}
if ($filtro_ramo > 0) { $conditions[]='e.id_ramo=:filtro_ramo'; $params[':filtro_ramo']=$filtro_ramo; }
if ($filtro_regiao > 0) { $conditions[]='e.id_regiao=:filtro_regiao'; $params[':filtro_regiao']=$filtro_regiao; }
if ($filtro_unidade > 0) { $conditions[]='e.id_unidade=:filtro_unidade'; $params[':filtro_unidade']=$filtro_unidade; }
if ($filtro_tipo > 0) { $conditions[]='e.id_tipo_equipamento=:filtro_tipo'; $params[':filtro_tipo']=$filtro_tipo; }
if ($filtro_estado > 0) { $conditions[]='e.id_estado_equipamento=:filtro_estado'; $params[':filtro_estado']=$filtro_estado; }
$sql .= "\n    WHERE " . implode(' AND ', $conditions) . "\n    ORDER BY e.data_aquisicao DESC, e.id_equipamento DESC, e.designacao ASC";

$stmt =
    $pdo->prepare($sql);

$stmt->execute($params);

$equipamentos =
    $stmt->fetchAll(PDO::FETCH_ASSOC);


// ============================================================
// FOTOGRAFIAS E DOCUMENTOS
// ============================================================

$fotografias_equipamentos = [];
$documentos_equipamentos = [];

foreach ($equipamentos as $equipamento) {

    $id_eq =
        (int)$equipamento['id_equipamento'];


    // --------------------------------------------------------
    // FOTOGRAFIAS
    // --------------------------------------------------------

    $stmt = $pdo->prepare("
        SELECT
            id_fotografia,
            nome_ficheiro,
            caminho_ficheiro,
            principal,
            descricao,
            data_registo
        FROM fotografias
        WHERE id_equipamento = :id
        ORDER BY principal DESC, id_fotografia DESC
    ");

    $stmt->execute([
        ':id' =>
            $id_eq
    ]);

    $fotografias_equipamentos[$id_eq] =
        $stmt->fetchAll(PDO::FETCH_ASSOC);


    // --------------------------------------------------------
    // DOCUMENTOS
    // --------------------------------------------------------

    $stmt = $pdo->prepare("
        SELECT
            d.id_documento,
            d.id_tipo_documento,
            d.titulo,
            d.nome_ficheiro,
            d.caminho_ficheiro,
            d.data_documento,
            d.data_validade,
            d.descricao,
            td.nome AS tipo_documento
        FROM documentos d

        LEFT JOIN tipos_documento td
            ON td.id_tipo_documento =
               d.id_tipo_documento

        WHERE d.id_equipamento = :id

        ORDER BY d.id_documento DESC
    ");

    $stmt->execute([
        ':id' =>
            $id_eq
    ]);

    $documentos_equipamentos[$id_eq] =
        $stmt->fetchAll(PDO::FETCH_ASSOC);
}


$total_equipamentos =
    count($equipamentos);
$page_title = "Equipamentos";
require __DIR__ . '/../layout/header.php';
?>

<div class="module-page module-equipamentos">
<style>
.module-equipamentos{--eq-card:var(--superficie);--eq-border:var(--borda);--eq-muted:var(--suave);--eq-soft:var(--azul-suave);}
.module-equipamentos .container{width:100%;max-width:1600px;margin:0 auto;padding:0;}
.module-equipamentos .cabecalho{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;margin:0 0 22px;flex-wrap:wrap;}
.module-equipamentos .titulo{margin:0;color:var(--texto);font-size:30px;letter-spacing:-.03em;}
.module-equipamentos .subtitulo{margin-top:6px;color:var(--suave);font-size:13px;}
.module-equipamentos .card{background:var(--eq-card);border:1px solid var(--eq-border);border-radius:16px;padding:20px;box-shadow:var(--sombra);margin-bottom:18px;}
.module-equipamentos .grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;}
.module-equipamentos .campo{display:flex;flex-direction:column;gap:7px;}
.module-equipamentos .campo-largo{grid-column:span 2;}
.module-equipamentos .campo-completo{grid-column:1/-1;}
.module-equipamentos label{font-weight:650;font-size:12px;color:var(--texto);}
.module-equipamentos input,.module-equipamentos select,.module-equipamentos textarea{width:100%;border:1px solid var(--eq-border);border-radius:9px;padding:11px 12px;font-size:13px;background:var(--eq-card);color:var(--texto);outline:none;}
.module-equipamentos input:focus,.module-equipamentos select:focus,.module-equipamentos textarea:focus{border-color:var(--azul);box-shadow:0 0 0 3px rgba(31,95,139,.12);}
.module-equipamentos textarea{min-height:100px;resize:vertical;}
.module-equipamentos .acoes{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.module-equipamentos .btn{border:0;border-radius:9px;padding:10px 14px;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;transition:.16s ease;}
.module-equipamentos .btn-primary{background:var(--azul);color:#fff;}
.module-equipamentos .btn-primary:hover{background:var(--azul-escuro);}
.module-equipamentos .btn-secondary{background:var(--eq-soft);color:var(--texto);}
.module-equipamentos .btn-warning{background:#c77800;color:#fff;}
.module-equipamentos .btn-danger{background:#c62828;color:#fff;}
.module-equipamentos .btn-success{background:#237a45;color:#fff;}
.module-equipamentos .btn-small{padding:7px 9px;font-size:11px;}
.module-equipamentos .mensagem{padding:12px 15px;border-radius:10px;margin-bottom:18px;font-size:13px;}
.module-equipamentos .mensagem-sucesso{background:#e8f7ee;color:#176238;border:1px solid #b8e4c9;}
.module-equipamentos .mensagem-erro{background:#fff0f0;color:#9d2222;border:1px solid #f0b9b9;}
.module-equipamentos .barra-pesquisa{display:flex;gap:10px;align-items:center;}
.module-equipamentos .barra-pesquisa input{flex:1;}
.module-equipamentos .resumo-equipamentos{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:18px;}
.module-equipamentos .resumo-item{padding:15px 16px;border:1px solid var(--eq-border);border-radius:13px;background:var(--eq-card);box-shadow:var(--sombra);}
.module-equipamentos .resumo-item small{display:block;color:var(--suave);font-size:11px;margin-bottom:5px;}
.module-equipamentos .resumo-item strong{font-size:23px;color:var(--texto);}
.module-equipamentos .total{display:flex;justify-content:space-between;align-items:center;gap:12px;color:var(--suave);font-size:12px;margin-bottom:14px;}
.module-equipamentos .total strong{color:var(--texto);font-size:20px;}
.module-equipamentos .equipamentos-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;}
.module-equipamentos .equip-card{border:1px solid var(--eq-border);border-radius:15px;background:var(--eq-card);overflow:hidden;box-shadow:0 3px 14px rgba(24,45,65,.045);}
.module-equipamentos .equip-card-top{display:flex;justify-content:space-between;gap:15px;padding:17px 18px 13px;border-bottom:1px solid var(--eq-border);}.module-equipamentos .filtro-equipamentos-card{padding:22px}.module-equipamentos .filtro-titulo{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}.module-equipamentos .filtro-titulo h2{margin:0;font-size:19px;color:var(--texto)}.module-equipamentos .filtro-titulo p{margin:5px 0 0;color:var(--suave);font-size:12px}.module-equipamentos .filtros-equipamentos{display:grid;grid-template-columns:2fr repeat(5,minmax(140px,1fr)) auto;gap:12px;align-items:end}.module-equipamentos .campo-filtro{display:flex;flex-direction:column;gap:6px}.module-equipamentos .campo-filtro label{font-size:11px;font-weight:700;color:var(--texto)}.module-equipamentos .campo-filtro input,.module-equipamentos .campo-filtro select{width:100%;box-sizing:border-box;border:1px solid var(--eq-border);border-radius:9px;padding:10px 11px;background:var(--eq-card);color:var(--texto);font-size:12px}.module-equipamentos .acoes-filtro{display:flex;gap:7px}.module-equipamentos .equip-photo-center{display:flex;justify-content:center;align-items:center;padding:20px 18px 8px;background:linear-gradient(180deg,rgba(31,95,139,.045),transparent)}.module-equipamentos .equip-photo-center img,.module-equipamentos .equip-photo-placeholder{width:170px;height:130px;object-fit:cover;border-radius:13px;border:1px solid var(--eq-border);display:flex;align-items:center;justify-content:center;background:var(--eq-soft);color:var(--suave);font-size:28px}.module-equipamentos .equip-actions{display:flex;justify-content:flex-end;gap:8px;padding:13px 18px;border-top:1px solid var(--eq-border)}
.module-equipamentos .equip-id{font-size:10px;color:var(--suave);font-weight:700;text-transform:uppercase;letter-spacing:.08em;}
.module-equipamentos .equip-name{margin:4px 0 0;font-size:18px;color:var(--texto);letter-spacing:-.02em;}
.module-equipamentos .equip-type{margin-top:4px;font-size:11px;color:var(--suave);}
.module-equipamentos .equip-badges{display:flex;gap:5px;flex-wrap:wrap;justify-content:flex-end;}
.module-equipamentos .badge{display:inline-flex;align-items:center;padding:5px 8px;border-radius:999px;background:var(--eq-soft);color:var(--texto);font-size:10px;font-weight:700;}
.module-equipamentos .badge-principal{background:#e7f0ff;color:#1d55a6;}
.module-equipamentos .equip-details{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;padding:15px 18px;}
.module-equipamentos .detail{min-width:0;}
.module-equipamentos .detail-label{display:block;font-size:10px;color:var(--suave);text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px;}
.module-equipamentos .detail-value{font-size:12px;color:var(--texto);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.module-equipamentos .equip-files{border-top:1px solid var(--eq-border);padding:12px 18px;}
.module-equipamentos details{border:1px solid var(--eq-border);border-radius:10px;margin-top:8px;background:color-mix(in srgb,var(--eq-soft) 42%,var(--eq-card));}
.module-equipamentos summary{cursor:pointer;padding:10px 12px;font-size:11px;font-weight:700;color:var(--texto);list-style:none;}
.module-equipamentos summary::-webkit-details-marker{display:none;}
.module-equipamentos .details-body{padding:0 12px 12px;}
.module-equipamentos .ficheiro-item{padding:9px 0;border-bottom:1px solid var(--eq-border);}
.module-equipamentos .ficheiro-item:last-child{border-bottom:0;}
.module-equipamentos .ficheiro-nome{display:block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;color:var(--texto);}
.module-equipamentos .ficheiro-acoes{display:flex;gap:5px;flex-wrap:wrap;margin-top:6px;}
.module-equipamentos .form-ficheiro{margin-top:10px;padding:11px;background:color-mix(in srgb,var(--eq-soft) 45%,var(--eq-card));border:1px solid var(--eq-border);border-radius:10px;}
.module-equipamentos .form-ficheiro input,.module-equipamentos .form-ficheiro select,.module-equipamentos .form-ficheiro textarea{margin-top:6px;}
.module-equipamentos .form-ficheiro label{display:block;margin-top:8px;}
.module-equipamentos .foto-thumb{width:54px;height:42px;object-fit:cover;border-radius:7px;border:1px solid var(--eq-border);vertical-align:middle;margin-right:7px;}
.module-equipamentos .equip-actions{display:flex;justify-content:flex-end;gap:7px;padding:13px 18px;border-top:1px solid var(--eq-border);background:color-mix(in srgb,var(--eq-soft) 30%,var(--eq-card));}
.module-equipamentos .empty{padding:45px 20px;text-align:center;color:var(--suave);}
@media(max-width:1200px){.module-equipamentos .equipamentos-grid{grid-template-columns:1fr;}.module-equipamentos .resumo-equipamentos{grid-template-columns:repeat(2,minmax(0,1fr));}}
@media(max-width:900px){.module-equipamentos .grid{grid-template-columns:repeat(2,minmax(0,1fr));}.module-equipamentos .campo-largo{grid-column:span 2;}}
@media(max-width:1100px){.module-equipamentos .filtros-equipamentos{grid-template-columns:repeat(3,minmax(0,1fr))}.module-equipamentos .campo-pesquisa{grid-column:1/-1}}@media(max-width:620px){.module-equipamentos .grid{grid-template-columns:1fr;}.module-equipamentos .filtros-equipamentos{grid-template-columns:1fr}.module-equipamentos .campo-pesquisa{grid-column:auto}.module-equipamentos .acoes-filtro{flex-wrap:wrap}.module-equipamentos .campo-largo,.module-equipamentos .campo-completo{grid-column:1/-1;}.module-equipamentos .barra-pesquisa{flex-direction:column;align-items:stretch;}.module-equipamentos .resumo-equipamentos{grid-template-columns:1fr 1fr;}.module-equipamentos .equip-details{grid-template-columns:1fr;}.module-equipamentos .equip-card-top{flex-direction:column;}.module-equipamentos .equip-badges{justify-content:flex-start;}}
html.modo-escuro .module-equipamentos .mensagem-sucesso{background:#143523;color:#9ee0b5;border-color:#286544;}
html.modo-escuro .module-equipamentos .mensagem-erro{background:#3a1c20;color:#ffb5bd;border-color:#693039;}
html.modo-escuro .module-equipamentos .btn-warning{background:#a86400;}
html.modo-escuro .module-equipamentos .btn-danger{background:#a92020;}
html.modo-escuro .module-equipamentos .badge-principal{background:#1d3556;color:#b9d5ff;}
.campo-opcional{font-size:11px;color:var(--suave);font-weight:500}.form-help{font-size:12px;color:var(--suave);margin-top:4px}
.module-equipamentos .equip-photo-center{display:flex;justify-content:center;align-items:center;padding:14px 18px 6px;}
.module-equipamentos .equip-photo-center img,.module-equipamentos .equip-photo-placeholder{width:128px;height:96px;border-radius:12px;border:1px solid var(--eq-border);object-fit:cover;background:var(--eq-soft);display:flex;align-items:center;justify-content:center;color:var(--eq-muted);font-size:28px;}
.module-equipamentos .equip-photo-center a{display:block;line-height:0;}
.module-equipamentos .equip-card-top{align-items:flex-start;}
</style>
<div class="container">


<!-- ======================================================
     CABEÇALHO
     ====================================================== -->

<div class="cabecalho">

    <div>

        <h1 class="titulo">
            Gestão de Equipamentos
        </h1>

        <div class="subtitulo">
            Cadastro, fotografias e documentos dos equipamentos
        </div>

    </div>

    <div class="acoes">

        <?php if ($equipamento_editar): ?>

            <a
                href="<?= e($return_url_safe) ?>"
                class="btn btn-secondary"
            >
                Cancelar edição
            </a>

        <?php elseif (has_permission('EQUIPAMENTOS_CRIAR')): ?>

            <a
                href="equipamentos.php?novo=1&return=<?= rawurlencode($return_url ?? 'equipamentos.php') ?>"
                class="btn btn-primary"
            >
                + Novo equipamento
            </a>

        <?php endif; ?>

    </div>

</div>


<!-- ======================================================
     MENSAGEM
     ====================================================== -->

<?php if ($mensagem !== ''): ?>

<div class="mensagem
    <?= $tipo_mensagem === 'sucesso'
        ? 'mensagem-sucesso'
        : 'mensagem-erro'
    ?>"
>

    <?= e($mensagem) ?>

</div>

<?php endif; ?>


<!-- ======================================================
     FORMULÁRIO EQUIPAMENTO
     ====================================================== -->

<?php if (
    ($equipamento_editar && has_permission('EQUIPAMENTOS_EDITAR')) ||
    (isset($_GET['novo']) && has_permission('EQUIPAMENTOS_CRIAR'))
): ?>

<div class="card">

    <h2 class="secao-titulo">

        <?= $equipamento_editar
            ? 'Editar equipamento'
            : 'Novo equipamento'
        ?>

    </h2>

    <form method="post">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

        <input
            type="hidden"
            name="acao"
            value="<?= $equipamento_editar
                ? 'atualizar'
                : 'adicionar'
            ?>"
        >

        <input type="hidden" name="return_url" value="<?= e($return_url_safe) ?>">

        <?php if ($equipamento_editar): ?>

            <input
                type="hidden"
                name="id_equipamento"
                value="<?= (int)
                    $equipamento_editar['id_equipamento']
                ?>"
            >

        <?php endif; ?>


        <div class="grid">


            <div class="campo campo-largo">
                <label>Responsabilidade</label>
                <div class="form-help">Selecione o ramo e a unidade. O especialista é opcional.</div>
            </div>

            <div class="campo">
                <label>Ramo *</label>
                <select name="id_ramo" id="id_ramo" required>
                    <option value="">Selecionar ramo</option>
                    <?php foreach($ramos as $r): ?>
                    <option value="<?=$r['id_ramo']?>" <?=((int)($equipamento_editar['id_ramo']??0)==$r['id_ramo'])?'selected':''?>><?=e($r['nome'])?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">
                <label>Unidade</label>
                <select name="id_unidade" id="id_unidade">
                    <option value="">Selecionar unidade</option>
                    <?php foreach($unidades as $u): ?>
                    <option value="<?=$u['id_unidade']?>" data-ramo="<?=$u['id_ramo']?>" <?=((int)($equipamento_editar['id_unidade']??0)==$u['id_unidade'])?'selected':''?>><?=e($u['nome'])?></option>
                    <?php endforeach; ?>
                </select>
            </div>
<div class="campo">
                <label>Região</label>
                <select name="id_regiao"><option value="">Selecionar região</option><?php foreach($regioes as $rg):?><option value="<?=$rg['id_regiao']?>" <?=((int)($equipamento_editar['id_regiao']??0)==$rg['id_regiao'])?'selected':''?>><?=e($rg['nome'])?></option><?php endforeach;?></select>
            </div>
            <div class="campo">
                <label>Especialista responsável</label>
                <select name="id_especialista_responsavel"><option value="">Nenhum</option><?php foreach($especialistas_responsaveis as $es):?><option value="<?=$es['id_especialista']?>" data-ramo="<?=$es['id_ramo']?>" <?=((int)($equipamento_editar['id_especialista_responsavel']??0)==$es['id_especialista'])?'selected':''?>><?=e($es['nome_completo'])?><?=!empty($es['nip'])?' — '.e($es['nip']):''?></option><?php endforeach;?></select>
            </div>

<div class="campo">

                <label>
                    Tipo de equipamento
                </label>

                <select
                    name="id_tipo_equipamento"
                >

                    <option value="">
                        Selecionar tipo
                    </option>

                    <?php foreach (
                        $tipos_equipamento
                        as $tipo
                    ): ?>

                        <option
                            value="<?= (int)
                                $tipo['id_tipo_equipamento']
                            ?>"
                            <?= (
                                $equipamento_editar &&
                                (int)$equipamento_editar[
                                    'id_tipo_equipamento'
                                ]
                                ===
                                (int)$tipo[
                                    'id_tipo_equipamento'
                                ]
                            )
                                ? 'selected'
                                : ''
                            ?>
                        >

                            <?= e($tipo['nome']) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="campo">

                <label>
                    Estado do equipamento
                </label>

                <select
                    name="id_estado_equipamento"
                >

                    <option value="">
                        Selecionar estado
                    </option>

                    <?php foreach (
                        $estados_equipamento
                        as $estado
                    ): ?>

                        <option
                            value="<?= (int)
                                $estado[
                                    'id_estado_equipamento'
                                ]
                            ?>"
                            <?= (
                                $equipamento_editar &&
                                (int)$equipamento_editar[
                                    'id_estado_equipamento'
                                ]
                                ===
                                (int)$estado[
                                    'id_estado_equipamento'
                                ]
                            )
                                ? 'selected'
                                : ''
                            ?>
                        >

                            <?= e($estado['nome']) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="campo campo-largo">

                <label>
                    Designação
                    <span class="obrigatorio">*</span>
                </label>

                <input
                    type="text"
                    name="designacao"
                    maxlength="200"
                    required
                    value="<?= e(
                        $equipamento_editar[
                            'designacao'
                        ] ?? ''
                    ) ?>"
                    placeholder="Ex.: Computador portátil Dell"
                >

            </div>


            <div class="campo">

                <label>
                    Marca
                </label>

                <input
                    type="text"
                    name="marca"
                    maxlength="100"
                    value="<?= e(
                        $equipamento_editar[
                            'marca'
                        ] ?? ''
                    ) ?>"
                >

            </div>


            <div class="campo">

                <label>
                    Modelo
                </label>

                <input
                    type="text"
                    name="modelo"
                    maxlength="100"
                    value="<?= e(
                        $equipamento_editar[
                            'modelo'
                        ] ?? ''
                    ) ?>"
                >

            </div>


            <div class="campo">

                <label>
                    Número de série
                </label>

                <input
                    type="text"
                    name="numero_serie"
                    maxlength="100"
                    value="<?= e(
                        $equipamento_editar[
                            'numero_serie'
                        ] ?? ''
                    ) ?>"
                >

            </div>


            <div class="campo">

                <label>
                    Número de património
                </label>

                <input
                    type="text"
                    name="numero_patrimonio"
                    maxlength="100"
                    value="<?= e(
                        $equipamento_editar[
                            'numero_patrimonio'
                        ] ?? ''
                    ) ?>"
                >

            </div>


            <div class="campo">

                <label>
                    Data de aquisição
                </label>

                <input
                    type="date"
                    name="data_aquisicao"
                    value="<?= e(
                        $equipamento_editar[
                            'data_aquisicao'
                        ] ?? ''
                    ) ?>"
                >

            </div>

            <div class="campo"><label>Quantidade total</label><input type="number" name="quantidade_total" min="1" step="1" value="<?= e($equipamento_editar['quantidade_total'] ?? 1) ?>" required></div>
            <div class="campo"><label>Quantidade distribuída</label><input type="number" name="quantidade_distribuida" min="0" step="1" value="<?= e($equipamento_editar['quantidade_distribuida'] ?? 0) ?>" required></div>
            <div class="campo"><label>Em stock (calculado)</label><input id="quantidade_stock_calculada" type="number" value="<?= max(0,(int)($equipamento_editar['quantidade_total']??1)-(int)($equipamento_editar['quantidade_distribuida']??0)) ?>" readonly aria-label="Quantidade em stock calculada"></div>


            <div class="campo campo-largo">

                <label>
                    Localização
                </label>

                <input
                    type="text"
                    name="localizacao"
                    maxlength="200"
                    value="<?= e(
                        $equipamento_editar[
                            'localizacao'
                        ] ?? ''
                    ) ?>"
                    placeholder="Ex.: Armazém central, Sala 02..."
                >

            </div>


            <div class="campo campo-completo">

                <label>
                    Descrição
                </label>

                <textarea
                    name="descricao"
                    placeholder="Descrição detalhada do equipamento..."
                ><?= e(
                    $equipamento_editar[
                        'descricao'
                    ] ?? ''
                ) ?></textarea>

            </div>


            <div class="campo campo-completo">

                <label>
                    Observações
                </label>

                <textarea
                    name="observacoes"
                    placeholder="Observações adicionais..."
                ><?= e(
                    $equipamento_editar[
                        'observacoes'
                    ] ?? ''
                ) ?></textarea>

            </div>

        </div>


        <div
            class="acoes"
            style="margin-top:20px;"
        >

            <button
                type="submit"
                class="btn btn-primary"
            >

                <?= $equipamento_editar
                    ? 'Guardar alterações'
                    : 'Cadastrar equipamento'
                ?>

            </button>

            <a
                href="<?= e($return_url_safe) ?>"
                class="btn btn-secondary"
            >
                Voltar
            </a>

        </div>

    </form>

</div>

<?php endif; ?>


<!-- ======================================================
     PESQUISA
     ====================================================== -->

<div class="card filtro-equipamentos-card">
    <div class="filtro-titulo"><div><h2>Pesquisar equipamentos</h2><p>Use os filtros para localizar rapidamente um equipamento.</p></div></div>
    <form method="get" class="filtros-equipamentos">
        <div class="campo-filtro campo-pesquisa"><label>Pesquisa livre</label><input type="text" name="pesquisa" value="<?= e($pesquisa) ?>" placeholder="Designação, marca, modelo, série ou património"></div>
        <div class="campo-filtro"><label>Ramo</label><select name="filtro_ramo" id="filtro_ramo"><option value="">Todos os ramos</option><?php foreach($ramos as $r):?><option value="<?=$r['id_ramo']?>" <?= $filtro_ramo===(int)$r['id_ramo']?'selected':'' ?>><?=e($r['nome'])?></option><?php endforeach;?></select></div>
        <div class="campo-filtro"><label>Região</label><select name="filtro_regiao"><option value="">Todas as regiões</option><?php foreach($regioes as $rg):?><option value="<?=$rg['id_regiao']?>" <?=$filtro_regiao===(int)$rg['id_regiao']?'selected':''?>><?=e($rg['nome'])?></option><?php endforeach;?></select></div><div class="campo-filtro"><label>Unidade</label><select name="filtro_unidade" id="filtro_unidade"><option value="">Todas as unidades</option><?php foreach($unidades as $u):?><option value="<?=$u['id_unidade']?>" data-ramo="<?=$u['id_ramo']?>" <?= $filtro_unidade===(int)$u['id_unidade']?'selected':'' ?>><?=e($u['nome'])?></option><?php endforeach;?></select></div>
        <div class="campo-filtro"><label>Tipo de equipamento</label><select name="filtro_tipo"><option value="">Todos os tipos</option><?php foreach($tipos_equipamento as $t):?><option value="<?=$t['id_tipo_equipamento']?>" <?= $filtro_tipo===(int)$t['id_tipo_equipamento']?'selected':'' ?>><?=e($t['nome'])?></option><?php endforeach;?></select></div>
        <div class="campo-filtro"><label>Estado</label><select name="filtro_estado"><option value="">Todos os estados</option><?php foreach($estados_equipamento as $eSt):?><option value="<?=$eSt['id_estado_equipamento']?>" <?= $filtro_estado===(int)$eSt['id_estado_equipamento']?'selected':'' ?>><?=e($eSt['nome'])?></option><?php endforeach;?></select></div>
        
        <div class="acoes-filtro"><button type="submit" class="btn btn-primary">Pesquisar</button><a href="equipamentos.php" class="btn btn-secondary">Limpar</a></div>
    </form>
</div>


<!-- ======================================================
     LISTAGEM
     ====================================================== -->

<?php
$com_fotos = 0;
$com_documentos = 0;
$sem_ficheiros = 0;
foreach ($equipamentos as $eqResumo) {
    $idResumo = (int)$eqResumo['id_equipamento'];
    if (!empty($fotografias_equipamentos[$idResumo])) $com_fotos++;
    if (!empty($documentos_equipamentos[$idResumo])) $com_documentos++;
    if (empty($fotografias_equipamentos[$idResumo]) && empty($documentos_equipamentos[$idResumo])) $sem_ficheiros++;
}
?>

<div class="resumo-equipamentos">
    <div class="resumo-item"><small>Equipamentos encontrados</small><strong><?= $total_equipamentos ?></strong></div>
    <div class="resumo-item"><small>Com fotografias</small><strong><?= $com_fotos ?></strong></div>
    <div class="resumo-item"><small>Com documentos</small><strong><?= $com_documentos ?></strong></div>
    <div class="resumo-item"><small>Sem ficheiros</small><strong><?= $sem_ficheiros ?></strong></div>
</div>

<div class="card">
    <div class="total">
        <span><?= $pesquisa !== '' ? 'Resultados da pesquisa' : 'Todos os equipamentos' ?></span>
        <strong><?= $total_equipamentos ?></strong>
    </div>

    <?php if (empty($equipamentos)): ?>
        <div class="empty">
            <strong>Nenhum equipamento encontrado.</strong><br>
            <span>Altere os termos da pesquisa ou cadastre um novo equipamento.</span>
        </div>
    <?php else: ?>
        <div class="equipamentos-grid">
        <?php foreach ($equipamentos as $equipamento): ?>
            <?php
            $id_eq = (int)$equipamento['id_equipamento'];
            $fotos = $fotografias_equipamentos[$id_eq] ?? [];
            $docs = $documentos_equipamentos[$id_eq] ?? [];
            $marcaModelo = trim(($equipamento['marca'] ?? '') . ' ' . ($equipamento['modelo'] ?? ''));
            $ramoTexto = trim(($equipamento['ramo_nome'] ?? '') . (!empty($equipamento['ramo_sigla']) ? ' · '.$equipamento['ramo_sigla'] : ''));
            $ramoSiglaVisual = strtoupper((string)($equipamento['ramo_sigla'] ?? ''));
            $ramoCorVisual = trim((string)($equipamento['ramo_cor'] ?? ''));
            if ($ramoSiglaVisual === 'MGA' && in_array(strtolower($ramoCorVisual), ['#ffffff','#fff','#fefefe'], true)) { $ramoCorVisual = '#a9bdcc'; }
            if (!preg_match('/^#[0-9a-fA-F]{6}$/', $ramoCorVisual)) { $ramoCorVisual = '#1f5f8b'; }
            $unidadeTexto = trim(($equipamento['unidade_nome'] ?? '') . (!empty($equipamento['unidade_sigla']) ? ' · '.$equipamento['unidade_sigla'] : ''));
            $responsavelPartes = [];
                            if (!empty($equipamento['ramo_nome'])) $responsavelPartes[] = 'Ramo: '. $equipamento['ramo_nome'];
                            if (!empty($equipamento['unidade_nome'])) $responsavelPartes[] = 'Unidade: '. $equipamento['unidade_nome'];
                            $responsavelTexto = $responsavelPartes ? implode(' | ', $responsavelPartes) : '—';
            ?>
            <article class="equip-card" style="--equip-accent: <?= e($ramoCorVisual) ?>;">
                <div class="equip-card-top">
                    <div>
                        <div class="equip-id">Equipamento #<?= $id_eq ?></div>
                        <h3 class="equip-name"><?= e($equipamento['designacao']) ?></h3>
                        <div class="equip-type"><?= e($equipamento['tipo_nome'] ?: 'Tipo não definido') ?></div>
                    </div>
                    <div class="equip-badges">
                        <?php if (!empty($equipamento['estado_nome'])): ?><span class="badge"><?= e($equipamento['estado_nome']) ?></span><?php endif; ?>
                        <?php if (!empty($equipamento['ramo_sigla'])): ?><span class="badge"><?= e($equipamento['ramo_sigla']) ?></span><?php endif; ?>
                    </div>
                </div>

                <div class="equip-photo-center">
                    <?php $fotoPrincipalEq = $fotos[0] ?? null; ?>
                    <?php if ($fotoPrincipalEq): ?>
                        <a href="<?= e(app_file_url($fotoPrincipalEq['caminho_ficheiro'])) ?>" target="_blank" title="Abrir fotografia do equipamento">
                            <img src="<?= e(app_file_url($fotoPrincipalEq['caminho_ficheiro'])) ?>" alt="Fotografia de <?= e($equipamento['designacao']) ?>">
                        </a>
                    <?php else: ?>
                        <div class="equip-photo-placeholder" aria-label="Sem fotografia">▣</div>
                    <?php endif; ?>
                </div>

                <div class="equip-details">
                    <div class="detail"><span class="detail-label">Marca / Modelo</span><span class="detail-value"><?= e($marcaModelo ?: '—') ?></span></div>
                    <div class="detail"><span class="detail-label">N.º de série</span><span class="detail-value"><?= e($equipamento['numero_serie'] ?: '—') ?></span></div>
                    <div class="detail"><span class="detail-label">N.º património</span><span class="detail-value"><?= e($equipamento['numero_patrimonio'] ?: '—') ?></span></div>
                    <div class="detail"><span class="detail-label">Ramo / Unidade</span><span class="detail-value" title="<?= e($ramoTexto . ($unidadeTexto ? ' · '.$unidadeTexto : '')) ?>"><?= e($ramoTexto . ($unidadeTexto ? ' · '.$unidadeTexto : '—')) ?></span></div>
                    <div class="detail"><span class="detail-label">Responsabilidade</span><span class="detail-value"><?= e($responsavelTexto) ?></span></div>
                    <div class="detail"><span class="detail-label">Localização</span><span class="detail-value"><?= e($equipamento['localizacao'] ?: '—') ?></span></div>
                    <div class="detail"><span class="detail-label">Aquisição</span><span class="detail-value"><?= e($equipamento['data_aquisicao'] ?: '—') ?></span></div>
                </div>

                <?php if (!empty($equipamento['descricao']) || !empty($equipamento['observacoes'])): ?>
                <div class="equip-files">
                    <?php if (!empty($equipamento['descricao'])): ?><div class="detail"><span class="detail-label">Descrição</span><span class="detail-value" style="white-space:normal;"><?= e($equipamento['descricao']) ?></span></div><?php endif; ?>
                    <?php if (!empty($equipamento['observacoes'])): ?><div class="detail" style="margin-top:8px;"><span class="detail-label">Observações</span><span class="detail-value" style="white-space:normal;"><?= e($equipamento['observacoes']) ?></span></div><?php endif; ?>
                </div>
                <?php endif; ?>

                <div class="equip-files">
                    <details>
                        <summary>📷 Fotografias (<?= count($fotos) ?>)</summary>
                        <div class="details-body">
                            <?php if ($fotos): foreach ($fotos as $foto): ?>
                                <div class="ficheiro-item">
                                    <span class="ficheiro-nome">
                                        <?php $fotoUrl = app_file_url($foto['caminho_ficheiro']); ?>
                                        <img class="foto-thumb" src="<?= e($fotoUrl) ?>" alt="Fotografia do equipamento">
                                        <?= e($foto['nome_ficheiro']) ?>
                                    </span>
                                    <div class="ficheiro-acoes">
                                        <?php if (!empty($foto['principal'])): ?>
                                            <span class="badge badge-principal">Principal</span>
                                        <?php elseif (has_permission('FOTOGRAFIAS_EDITAR')): ?>
                                            <form method="post">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="acao" value="foto_principal"><input type="hidden" name="id_fotografia" value="<?= (int)$foto['id_fotografia'] ?>"><input type="hidden" name="id_equipamento" value="<?= $id_eq ?>"><button class="btn btn-secondary btn-small" type="submit">Definir principal</button></form>
                                        <?php endif; ?>
                                        <a class="btn btn-secondary btn-small" href="equipamentos.php?download_foto=<?= (int)$foto['id_fotografia'] ?>">Abrir / baixar</a>
                                        <?php if (has_permission('FOTOGRAFIAS_ELIMINAR')): ?><form method="post" onsubmit="return confirm('Eliminar esta fotografia?');">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="acao" value="eliminar_foto"><input type="hidden" name="id_fotografia" value="<?= (int)$foto['id_fotografia'] ?>"><button class="btn btn-danger btn-small" type="submit">Eliminar</button></form><?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; else: ?><div class="empty" style="padding:15px;">Sem fotografias.</div><?php endif; ?>
                            <?php if (has_permission('FOTOGRAFIAS_CRIAR')): ?>
                            <div class="form-ficheiro">
                                <strong>Adicionar fotografia</strong>
                                <form method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="acao" value="upload_foto"><input type="hidden" name="id_equipamento" value="<?= $id_eq ?>">
                                    <input type="file" name="fotografia" accept=".jpg,.jpeg,.png,.webp" required>
                                    <input type="text" name="descricao_foto" maxlength="500" placeholder="Descrição (opcional)">
                                    <label><input type="checkbox" name="principal" value="1"> Definir como fotografia principal</label>
                                    <button type="submit" class="btn btn-primary btn-small" style="margin-top:8px;">Adicionar fotografia</button>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                    </details>

                    <details>
                        <summary>📄 Documentos (<?= count($docs) ?>)</summary>
                        <div class="details-body">
                            <?php if ($docs): foreach ($docs as $doc): ?>
                                <div class="ficheiro-item">
                                    <span class="ficheiro-nome">📄 <?= e($doc['titulo']) ?> · <?= e($doc['tipo_documento'] ?: 'Documento') ?></span>
                                    <small style="color:var(--suave);"> <?= e($doc['nome_ficheiro']) ?><?= $doc['data_validade'] ? ' · validade '.$doc['data_validade'] : '' ?></small>
                                    <div class="ficheiro-acoes">
                                        <a class="btn btn-secondary btn-small" href="equipamentos.php?download_documento=<?= (int)$doc['id_documento'] ?>">Abrir / baixar</a>
                                        <?php if (has_permission('DOCUMENTOS_ELIMINAR')): ?><form method="post" onsubmit="return confirm('Eliminar este documento?');">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="acao" value="eliminar_documento"><input type="hidden" name="id_documento" value="<?= (int)$doc['id_documento'] ?>"><button class="btn btn-danger btn-small" type="submit">Eliminar</button></form><?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; else: ?><div class="empty" style="padding:15px;">Sem documentos.</div><?php endif; ?>
                            <?php if (has_permission('DOCUMENTOS_CRIAR')): ?>
                            <div class="form-ficheiro">
                                <strong>Adicionar documento</strong>
                                <form method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="acao" value="upload_documento"><input type="hidden" name="id_equipamento" value="<?= $id_eq ?>">
                                    <input type="text" name="titulo" maxlength="200" placeholder="Título do documento" required>
                                    <select name="id_tipo_documento" required><option value="">Tipo de documento</option><?php foreach ($tipos_documento as $tipo_doc): ?><option value="<?= (int)$tipo_doc['id_tipo_documento'] ?>"><?= e($tipo_doc['nome']) ?></option><?php endforeach; ?></select>
                                    <input type="file" name="documento" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" required>
                                    <div class="grid" style="grid-template-columns:1fr 1fr;gap:8px;margin-top:6px;"><input type="date" name="data_documento" title="Data do documento"><input type="date" name="data_validade" title="Data de validade"></div>
                                    <textarea name="descricao_documento" placeholder="Descrição (opcional)" style="min-height:55px;"></textarea>
                                    <button type="submit" class="btn btn-primary btn-small" style="margin-top:8px;">Adicionar documento</button>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                    </details>
                </div>

                <div class="equip-actions">
                    <?php if (has_permission('EQUIPAMENTOS_EDITAR')): ?><a href="equipamentos.php?editar=<?= $id_eq ?>&return=<?= rawurlencode($return_url) ?>" class="btn btn-warning btn-small">Editar</a><?php endif; ?> <a href="equipamento_resumo.php?id=<?= $id_eq ?>" target="_blank" class="btn btn-secondary btn-small">Ficha resumida</a>
                    <?php if (has_permission('EQUIPAMENTOS_ELIMINAR')): ?><form method="post" onsubmit="return confirmarEliminacao();">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="acao" value="eliminar"><input type="hidden" name="id_equipamento" value="<?= $id_eq ?>"><button type="submit" class="btn btn-danger btn-small">Eliminar</button></form><?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

</div>
<script>


// ============================================================
// CONFIRMAR ELIMINAÇÃO
// ============================================================

function confirmarEliminacao()
{
    return confirm(
        'Tem certeza que deseja eliminar este equipamento?\n\n' +
        'Se existirem fotografias ou documentos associados, ' +
        'a eliminação poderá ser bloqueada pela base de dados.'
    );
}


// ============================================================
// FILTRAR UNIDADES PELO RAMO
// ============================================================

const ramoSelect =
    document.getElementById('id_ramo');

const unidadeSelect =
    document.getElementById('id_unidade');


function atualizarUnidades()
{
    if (
        !ramoSelect ||
        !unidadeSelect
    ) {
        return;
    }

    const ramoSelecionado =
        ramoSelect.value;

    const opcoes =
        unidadeSelect.querySelectorAll(
            'option'
        );

    opcoes.forEach(
        function(opcao, indice)
        {

            if (indice === 0) {

                opcao.hidden = false;
                return;
            }

            const idRamo =
                opcao.getAttribute(
                    'data-ramo'
                );

            if (
                ramoSelecionado === '' ||
                idRamo === ramoSelecionado
            ) {

                opcao.hidden = false;

            } else {

                opcao.hidden = true;

                if (opcao.selected) {
                    unidadeSelect.value = '';
                }
            }
        }
    );
}


if (ramoSelect) {

    ramoSelect.addEventListener(
        'change',
        atualizarUnidades
    );

    atualizarUnidades();
}

</script>


<script>
(function(){const r=document.getElementById('filtro_ramo'),u=document.getElementById('filtro_unidade');if(!r||!u)return;function f(){const v=r.value;[...u.options].forEach((o,i)=>{if(i===0)return;o.hidden=!!v&&o.dataset.ramo!==v;if(o.hidden&&o.selected)o.selected=false;});}r.addEventListener('change',f);f();})();
</script>
</div>

<?php require __DIR__ . '/../layout/footer.php'; ?>
