<?php
require_once __DIR__ . '/../../app/auth.php';
require_login();
require_permission('DASHBOARD_VISUALIZAR');
$pdo=db();
$temRH=has_permission('ESPECIALISTAS_VISUALIZAR');
$temRM=has_permission('EQUIPAMENTOS_VISUALIZAR');
$params=[];$where=$temRH?scope_sql($params,'v'):'0=1';
function dash_rows(PDO $pdo,string $sql,array $params=[]): array { try{$s=$pdo->prepare($sql);$s->execute($params);return $s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return [];} }
$st=['total'=>0,'ativos'=>0,'inativos'=>0,'masculino'=>0,'feminino'=>0];
if($temRH){try{$s=$pdo->prepare("SELECT COUNT(*) total,SUM(v.grupo_situacao='ATIVO') ativos,SUM(v.grupo_situacao='INATIVO') inativos,SUM(LOWER(v.sexo)='masculino') masculino,SUM(LOWER(v.sexo)='feminino') feminino FROM vw_especialistas_dashboard v WHERE $where");$s->execute($params);$st=array_merge($st,$s->fetch(PDO::FETCH_ASSOC)?:[]);}catch(Throwable $e){}}
$equipParams=[];$equipWhere=$temRM?scope_sql($equipParams,'e'):'0=1';
$eq=['total'=>0];if($temRM){try{$s=$pdo->prepare("SELECT COUNT(*) total FROM equipamentos e WHERE $equipWhere");$s->execute($equipParams);$eq=$s->fetch(PDO::FETCH_ASSOC)?:$eq;}catch(Throwable $e){}}
$quadros=$temRH?dash_rows($pdo,"SELECT v.quadro nome,COUNT(*) total FROM vw_especialistas_dashboard v WHERE $where GROUP BY v.id_quadro,v.quadro ORDER BY total DESC",$params):[];
$patentes=$temRH?dash_rows($pdo,"SELECT COALESCE(v.patente,'Sem patente') nome,COUNT(*) total FROM vw_especialistas_dashboard v LEFT JOIN patentes pat ON pat.id_patente=v.id_patente WHERE $where GROUP BY v.id_patente,v.patente,pat.ordem ORDER BY (v.id_patente IS NULL) ASC, COALESCE(pat.ordem,999999) ASC,v.patente ASC LIMIT 20",$params):[];
$patentesRamo=$temRH?dash_rows($pdo,"SELECT pat.ordem AS ordem_hierarquica,COALESCE(v.patente,'Sem patente') patente,COALESCE(r.sigla,r.nome,'Sem ramo') ramo,COUNT(*) total FROM vw_especialistas_dashboard v LEFT JOIN patentes pat ON pat.id_patente=v.id_patente LEFT JOIN ramo r ON r.id_ramo=v.id_ramo WHERE $where GROUP BY pat.ordem,v.id_patente,v.patente,r.id_ramo,r.sigla,r.nome ORDER BY (pat.ordem IS NULL),pat.ordem,v.patente,r.sigla",$params):[];
$patentesAgrupadas=[];foreach($patentesRamo as $linhaPat){$ord=$linhaPat['ordem_hierarquica']===null?'sem-ordem':(string)$linhaPat['ordem_hierarquica'];if(!isset($patentesAgrupadas[$ord]))$patentesAgrupadas[$ord]=['total'=>0,'itens'=>[]];$patentesAgrupadas[$ord]['total']+=(int)$linhaPat['total'];$patentesAgrupadas[$ord]['itens'][]=$linhaPat;}
$ramos=$temRH?dash_rows($pdo,"SELECT r.nome,r.sigla,r.cor_principal,COUNT(*) total FROM vw_especialistas_dashboard v JOIN ramo r ON r.id_ramo=v.id_ramo WHERE $where GROUP BY r.id_ramo,r.nome,r.sigla,r.cor_principal ORDER BY FIELD(r.sigla,'EMG','EXE','FAN','MGA'),r.nome",$params):[];
$equipEstados=$temRM?dash_rows($pdo,"SELECT COALESCE(ee.nome,'Sem estado') nome,COUNT(*) total FROM equipamentos e LEFT JOIN estados_equipamento ee ON ee.id_estado_equipamento=e.id_estado_equipamento WHERE $equipWhere GROUP BY ee.id_estado_equipamento,ee.nome ORDER BY total DESC",$equipParams):[];
$equipTipos=$temRM?dash_rows($pdo,"SELECT COALESCE(te.nome,'Sem tipo') nome,COUNT(*) total FROM equipamentos e LEFT JOIN tipos_equipamento te ON te.id_tipo_equipamento=e.id_tipo_equipamento WHERE $equipWhere GROUP BY te.id_tipo_equipamento,te.nome ORDER BY total DESC LIMIT 8",$equipParams):[];
$equipRamos=$temRM?dash_rows($pdo,"SELECT r.nome,COUNT(*) total FROM equipamentos e JOIN ramo r ON r.id_ramo=e.id_ramo WHERE $equipWhere GROUP BY r.id_ramo,r.nome ORDER BY total DESC LIMIT 8",$equipParams):[];
function bar_max(array $rows): int { $valores=array_map(fn($r)=>(int)($r['total']??0),$rows); $valores[]=1; return max($valores); }
function patent_group_label(string $ord, array $grupo): string {
    $nomes=[];
    foreach(($grupo['itens'] ?? []) as $item){
        $nome=trim((string)($item['patente'] ?? ''));
        if($nome!=='' && !in_array($nome,$nomes,true)) $nomes[]=$nome;
    }
    if(!$nomes) return 'Sem patente';
    $base=$nomes[0];
    return count($nomes) > 1 ? ($base.' / equivalentes') : $base;
}
function patent_group_summary(array $patentesAgrupadas): array {
    $out=[];
    foreach($patentesAgrupadas as $ord=>$grupo){
        $out[]=[
            'ord'=>$ord,
            'label'=>patent_group_label((string)$ord,$grupo),
            'total'=>(int)($grupo['total'] ?? 0),
            'itens'=>$grupo['itens'] ?? []
        ];
    }
    usort($out, function($a,$b){ return ($b['total'] ?? 0) <=> ($a['total'] ?? 0); });
    return $out;
}
function dash_hex_to_rgb(string $hex): array {
    $hex=ltrim(trim($hex),'#');
    if(strlen($hex)===3){ $hex=$hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2]; }
    if(!preg_match('/^[0-9a-fA-F]{6}$/',$hex)) return [64,110,150];
    return [hexdec(substr($hex,0,2)),hexdec(substr($hex,2,2)),hexdec(substr($hex,4,2))];
}
function dash_rgb_to_hex(array $rgb): string {
    return sprintf('#%02X%02X%02X', max(0,min(255,(int)round($rgb[0] ?? 0))), max(0,min(255,(int)round($rgb[1] ?? 0))), max(0,min(255,(int)round($rgb[2] ?? 0))));
}
function dash_mix_hex(string $hex,float $ratio=0.0): string {
    [$r,$g,$b]=dash_hex_to_rgb($hex);
    $ratio=max(0,min(0.82,$ratio));
    return dash_rgb_to_hex([$r + (255-$r)*$ratio, $g + (255-$g)*$ratio, $b + (255-$b)*$ratio]);
}
function patent_chart_groups(array $patentesAgrupadas): array {
    $grupos = patent_group_summary($patentesAgrupadas);
    $bases=['#1368CE','#F39A18','#43A55B','#8A56E2','#E45B82','#17879B'];
    $totalGeral=0; foreach($grupos as $g) $totalGeral += (int)($g['total'] ?? 0);
    foreach($grupos as $i=>&$grupo){
        $base=$bases[$i % count($bases)];
        $ramoMap=[];
        foreach(($grupo['itens'] ?? []) as $item){
            $ramo = trim((string)($item['ramo'] ?? 'Sem ramo')) ?: 'Sem ramo';
            $ramoMap[$ramo] = ($ramoMap[$ramo] ?? 0) + (int)($item['total'] ?? 0);
        }
        arsort($ramoMap);
        $count=max(1,count($ramoMap));
        $segments=[]; $j=0;
        foreach($ramoMap as $ramo=>$total){
            $ratio = $count===1 ? 0.10 : (0.08 + (($j / max(1,$count-1)) * 0.38));
            $segments[]=['ramo'=>$ramo,'total'=>$total,'color'=>dash_mix_hex($base,$ratio)];
            $j++;
        }
        $grupo['base_color']=$base;
        $grupo['segments']=$segments;
        $grupo['percent']=$totalGeral>0?(((int)$grupo['total'])/$totalGeral)*100:0;
    }
    unset($grupo);
    return ['total'=>$totalGeral,'groups'=>$grupos];
}
function donut_segment_path(float $cx,float $cy,float $rOuter,float $rInner,float $start,float $end): string {
    $x1=$cx + cos($start)*$rOuter; $y1=$cy + sin($start)*$rOuter;
    $x2=$cx + cos($end)*$rOuter;   $y2=$cy + sin($end)*$rOuter;
    $x3=$cx + cos($end)*$rInner;   $y3=$cy + sin($end)*$rInner;
    $x4=$cx + cos($start)*$rInner; $y4=$cy + sin($start)*$rInner;
    $large = (($end-$start) > M_PI) ? 1 : 0;
    return sprintf('M %.2F %.2F A %.2F %.2F 0 %d 1 %.2F %.2F L %.2F %.2F A %.2F %.2F 0 %d 0 %.2F %.2F Z',$x1,$y1,$rOuter,$rOuter,$large,$x2,$y2,$x3,$y3,$rInner,$rInner,$large,$x4,$y4);
}
function patent_donut_svg(array $chart, int $size=320): string {
    $groups=$chart['groups'] ?? []; $total=(int)($chart['total'] ?? 0); if($total<=0 || !$groups) return '';
    $cx=$size/2; $cy=$size/2; $rOuter=122; $rInner=58; $start=-M_PI/2;
    $svg='<svg viewBox="0 0 '.$size.' '.$size.'" width="'.$size.'" height="'.$size.'" aria-label="Especialistas por patentes" role="img">';
    foreach($groups as $group){
        $groupTotal=max(1,(int)($group['total'] ?? 0));
        $groupAngle=((int)$group['total']/$total) * M_PI * 2;
        foreach(($group['segments'] ?? []) as $seg){
            $segAngle=($seg['total']/$groupTotal) * $groupAngle;
            $segEnd=$start + $segAngle;
            $pctTotal=$total>0 ? (($seg['total']/$total)*100) : 0;
            $pctGroup=$groupTotal>0 ? (($seg['total']/$groupTotal)*100) : 0;
            $title=htmlspecialchars($group['label'].' — '.$seg['ramo'].' | '.$seg['total'].' especialista(s) | '.number_format($pctTotal,1,',','.').'% do total | '.number_format($pctGroup,1,',','.').'% da patente',ENT_QUOTES,'UTF-8');
            $svg.='<path class="patent-seg" d="'.donut_segment_path($cx,$cy,$rOuter,$rInner,$start,$segEnd).'" fill="'.$seg['color'].'" stroke="#ffffff" stroke-width="2"><title>'.$title.'</title></path>';
            $start=$segEnd;
        }
    }
    $svg.='<circle cx="'.$cx.'" cy="'.$cy.'" r="'.$rInner.'" fill="#ffffff" stroke="#e4edf5" stroke-width="2"></circle>';
    $svg.='<text x="'.$cx.'" y="'.($cy-8).'" text-anchor="middle" font-size="12" fill="#6c7f8f" font-weight="700">TOTAL</text>';
    $svg.='<text x="'.$cx.'" y="'.($cy+18).'" text-anchor="middle" font-size="40" fill="#102f50" font-weight="800">'.$total.'</text>';
    $svg.='</svg>';
    return $svg;
}
$patentesGrafico = patent_chart_groups($patentesAgrupadas);
$page_title='Dashboard'; require __DIR__.'/../layout/header.php';
?>
<div class="module-page module-dashboard dashboard-modern">
<style>
.dashboard-modern{max-width:1500px;margin:0 auto}.dashboard-hero{padding:28px 30px;border-radius:22px;background:linear-gradient(135deg,#ffffff,#edf5fa);color:#18344b;border:1px solid #dce8ef;box-shadow:0 16px 35px rgba(20,70,105,.10);margin-bottom:20px}.dashboard-hero h1{margin:0;font-size:34px;letter-spacing:-.03em;color:#18344b}.dashboard-hero p{margin:8px 0 0;color:#60788a;opacity:1}.dashboard-hero:after{content:'Painel de controlo';display:inline-flex;margin-top:15px;padding:6px 10px;border-radius:999px;background:#e2eff6;color:#1f5f8b;font-size:11px;font-weight:750}.dash-card{transition:transform .16s ease,box-shadow .16s ease}.dash-card:hover{transform:translateY(-2px);box-shadow:0 10px 26px rgba(24,45,65,.09)}.dash-cards{display:grid;grid-template-columns:repeat(6,1fr);gap:14px;margin-bottom:20px}.dash-card{background:var(--superficie);border:1px solid var(--borda);border-radius:16px;padding:18px;box-shadow:var(--sombra);min-height:104px}.dash-card small{color:var(--suave);font-weight:700}.dash-card strong{display:block;font-size:29px;margin-top:9px}.dash-card.equip{border-top:4px solid #d08b36}.dash-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.dash-panel{background:var(--superficie);border:1px solid var(--borda);border-radius:16px;padding:20px;box-shadow:var(--sombra)}.dash-panel h3{margin:0 0 16px}.dash-patentes-wrap{display:grid;grid-template-columns:minmax(320px,430px) minmax(280px,420px);gap:28px;align-items:center}.dash-pie-card{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0}.dash-pie{max-width:360px;width:100%;height:auto}.dash-pie svg{overflow:visible}.dash-pie .patent-seg{transition:opacity .15s ease}.dash-pie .patent-seg:hover{opacity:.92}.dash-legend{display:grid;gap:14px;width:100%}.dash-legend-item{display:grid;grid-template-columns:16px 1fr auto auto;gap:12px;align-items:center;padding:18px 18px;border:1px solid var(--borda);border-radius:16px;background:#fbfdff}.dash-legend-color{width:16px;height:16px;border-radius:50%;box-shadow:inset 0 0 0 2px rgba(255,255,255,.45)}.dash-legend strong{display:block;font-size:16px;color:#102f50}.dash-legend .value{font-weight:800;color:#18344b;font-size:16px}.dash-legend .percent{font-size:15px;color:#60788a;font-weight:800}.dash-legend-note{margin-top:16px;color:var(--suave);font-size:12px;text-align:left;padding-top:14px;border-top:1px solid var(--borda)}.dash-ramo-help{margin-top:14px;font-size:13px;color:#60788a}.dash-ramo-tags{display:flex;flex-wrap:wrap;gap:10px;margin-top:10px}.dash-ramo-tag{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border-radius:999px;background:#f4f8fb;border:1px solid var(--borda);font-size:12px;font-weight:700;color:#526b84}.dash-ramo-swatch{width:14px;height:14px;border-radius:50%}.dash-row{display:grid;grid-template-columns:minmax(130px,1fr) 3fr 48px;align-items:center;gap:10px;margin:11px 0;font-size:13px}.dash-track{height:9px;background:var(--azul-suave);border-radius:20px;overflow:hidden}.dash-fill{height:100%;border-radius:20px;background:#327aa4}.dash-equip .dash-fill{background:#c68a3d}.dash-empty{color:var(--suave);padding:20px 0}.dash-summary{display:flex;gap:10px;flex-wrap:wrap}.dash-pill{padding:7px 10px;border:1px solid var(--borda);border-radius:999px;font-size:12px}.dash-pill b{font-size:14px}.dash-panel-wide{grid-column:1/-1}.dash-columns{display:grid;grid-template-columns:1fr 1fr;gap:24px}.dash-subtitle{font-size:12px;color:var(--suave);font-weight:700;margin:0 0 10px;text-transform:uppercase;letter-spacing:.04em}
html.modo-escuro .dashboard-hero{background:linear-gradient(135deg,#172a38,#1d4056);border-color:#345164;color:#edf3f7}html.modo-escuro .dashboard-hero h1{color:#edf3f7}html.modo-escuro .dashboard-hero p{color:#b9c8d2}html.modo-escuro .dashboard-hero:after{background:#24465c;color:#d5ebf8}
@media(max-width:1200px){.dash-cards{grid-template-columns:repeat(3,1fr)}.dash-patentes-wrap{grid-template-columns:1fr}}@media(max-width:760px){.dash-cards,.dash-grid,.dash-columns,.dash-patentes-wrap{grid-template-columns:1fr}.dash-panel-wide{grid-column:auto}.dashboard-hero h1{font-size:27px}.dash-legend-item{grid-template-columns:16px 1fr auto}.dash-legend .percent{grid-column:2 / -1}}

/* V4.36 — patentes em barras finas, no estilo de especialistas por ramo */
.dash-patents-bar-panel{overflow:visible}
.patent-bars{display:grid;gap:11px;padding:2px 0 4px}
.patent-bar-row{display:grid;grid-template-columns:minmax(130px,190px) minmax(150px,1fr) 44px 60px;gap:10px;align-items:center}
.patent-bar-label{font-size:13px;font-weight:700;overflow-wrap:anywhere;color:var(--texto,#18344b)}
.patent-bar-track{height:10px;border-radius:20px;background:var(--azul-suave,#edf3f8);position:relative;overflow:visible}
.patent-bar-stack{height:100%;display:flex;border-radius:20px;overflow:visible;min-width:2px}
.patent-bar-segment{height:100%;position:relative;border-right:1px solid rgba(255,255,255,.9);min-width:1px;cursor:help}
.patent-bar-segment:first-child{border-radius:20px 0 0 20px}
.patent-bar-segment:last-child{border-right:0;border-radius:0 20px 20px 0}
.patent-bar-segment:only-child{border-radius:20px}
.patent-bar-segment:hover,.patent-bar-segment:focus-visible{filter:brightness(1.08);outline:none;z-index:5}
.patent-bar-tooltip{display:none;position:absolute;z-index:20;left:50%;bottom:calc(100% + 10px);transform:translateX(-50%);width:max-content;max-width:min(250px,75vw);box-sizing:border-box;padding:10px 12px;background:#17344e;color:white;border-radius:9px;font-size:12px;line-height:1.55;white-space:normal;box-shadow:0 8px 24px #17344e40;pointer-events:none}
.patent-bar-segment:hover .patent-bar-tooltip,.patent-bar-segment:focus-visible .patent-bar-tooltip{display:block}
.patent-bar-value{text-align:right;font-size:13px;font-weight:800;color:#18344b}
.patent-bar-percent{text-align:right;color:var(--suave,#60788a);font-weight:700;font-size:12px}
.patent-bar-hint{font-size:12px;color:var(--suave,#60788a);margin:14px 0 0}
@media(max-width:760px){.patent-bar-row{grid-template-columns:minmax(82px,110px) minmax(90px,1fr) 32px 48px;gap:7px}.patent-bar-label,.patent-bar-percent{font-size:11px}.patent-bar-track{height:9px}}
</style>
<section class="dashboard-hero"><h1>Visão geral</h1><p><?php if($temRH&&$temRM): ?>Indicadores atualizados de especialistas e equipamentos dentro do seu âmbito de acesso.<?php elseif($temRH): ?>Indicadores de Recursos Humanos dentro do seu âmbito de acesso.<?php else: ?>Indicadores de Recursos Materiais dentro do seu âmbito de acesso.<?php endif; ?></p></section>
<section class="dash-cards">
<?php $cards=[];if($temRH){$cards[]=['Especialistas',$st['total'],false];$cards[]=['Ativos',$st['ativos'],false];$cards[]=['Inativos',$st['inativos'],false];$cards[]=['Masculino',$st['masculino'],false];$cards[]=['Feminino',$st['feminino'],false];}if($temRM)$cards[]=['Equipamentos',$eq['total'],true];foreach($cards as $c):?><div class="dash-card <?=$c[2]?'equip':''?>"><small><?=$c[0]?></small><strong><?=number_format((int)$c[1],0,',','.')?></strong></div><?php endforeach; ?>
</section>
<section class="dash-grid">
<?php if($temRH): ?><div class="dash-panel"><h3>Quadro de serviço</h3><?php $m=bar_max($quadros); foreach($quadros as $r):?><div class="dash-row"><span><?=htmlspecialchars($r['nome'])?></span><div class="dash-track"><div class="dash-fill" style="width:<?=round(((int)$r['total']/$m)*100)?>%"></div></div><b><?=$r['total']?></b></div><?php endforeach; if(!$quadros):?><div class="dash-empty">Sem dados disponíveis.</div><?php endif;?></div>
<div class="dash-panel"><h3>Especialistas por ramo</h3><?php $m=bar_max($ramos); foreach($ramos as $r): $sig=strtoupper((string)($r['sigla']??'')); $cor=trim((string)($r['cor_principal']??'')); if(strcasecmp($sig,'MGA')===0 && in_array(strtolower($cor),['#ffffff','#fff','#fefefe'],true)) $cor='#a9bdcc'; if(!preg_match('/^#[0-9a-fA-F]{6}$/',$cor)) $cor=['EMG'=>'#e58a22','EXE'=>'#788b3a','FAN'=>'#55aee0','MGA'=>'#a9bdcc'][$sig]??'#327aa4';?><div class="dash-row branch-row"><span><i class="branch-dot" style="background:<?=$cor?>"></i><?=htmlspecialchars($sig?:$r['nome'])?></span><div class="dash-track"><div class="dash-fill" style="width:<?=round(((int)$r['total']/$m)*100)?>%;background:<?=$cor?>"></div></div><b><?=$r['total']?></b></div><?php endforeach; if(!$ramos):?><div class="dash-empty">Sem dados disponíveis.</div><?php endif;?></div>
<div class="dash-panel dash-panel-wide dash-patents-bar-panel">
<h3>Especialistas por patentes</h3>
<?php if(($patentesGrafico['total'] ?? 0)>0): ?>
<div class="patent-bars" role="list" aria-label="Distribuição de especialistas por patente e ramo">
<?php $maxPat=max(1,...array_map(static fn($g)=>(int)$g['total'],$patentesGrafico['groups'])); foreach($patentesGrafico['groups'] as $pg): ?>
<div class="patent-bar-row" role="listitem">
  <div class="patent-bar-label" title="<?=htmlspecialchars($pg['label'],ENT_QUOTES,'UTF-8')?>"><?=htmlspecialchars($pg['label'])?></div>
  <div class="patent-bar-track" role="img" aria-label="<?=htmlspecialchars($pg['label'].': '.$pg['total'].' especialistas',ENT_QUOTES,'UTF-8')?>">
    <div class="patent-bar-stack" style="width:<?=number_format((int)$pg['total']/$maxPat*100,4,'.','')?>%">
    <?php foreach($pg['segments'] as $seg): $pctGrupo=(int)$pg['total']>0?((int)$seg['total']/(int)$pg['total']*100):0; $pctGeral=(int)$patentesGrafico['total']>0?((int)$seg['total']/(int)$patentesGrafico['total']*100):0; ?>
      <div class="patent-bar-segment" style="width:<?=number_format($pctGrupo,5,'.','')?>%;background:<?=$seg['color']?>" tabindex="0" aria-label="<?=htmlspecialchars($pg['label'].' — '.$seg['ramo'].': '.$seg['total'].' especialistas, '.number_format($pctGeral,1,',','.').'% do total, '.number_format($pctGrupo,1,',','.').'% desta patente',ENT_QUOTES,'UTF-8')?>">
        <span class="patent-bar-tooltip"><b><?=htmlspecialchars($pg['label'])?> · <?=htmlspecialchars($seg['ramo'])?></b><br><?= (int)$seg['total'] ?> especialista(s)<br><?=number_format($pctGeral,1,',','.')?>% do total · <?=number_format($pctGrupo,1,',','.')?>% da patente</span>
      </div>
    <?php endforeach; ?>
    </div>
  </div>
  <strong class="patent-bar-value"><?= (int)$pg['total'] ?></strong>
  <span class="patent-bar-percent"><?=number_format((float)$pg['percent'],1,',','.')?>%</span>
</div>
<?php endforeach; ?>
</div>
<p class="patent-bar-hint">Cada barra representa uma patente. As tonalidades distinguem os ramos. Passe o cursor sobre os segmentos para ver os valores.</p>
<?php else: ?><div class="dash-empty">Sem dados disponíveis.</div><?php endif; ?>
</div><?php endif; ?>
<?php if($temRM): ?><div class="dash-panel dash-equip"><h3>Equipamentos por estado</h3><?php $m=bar_max($equipEstados); foreach($equipEstados as $r):?><div class="dash-row"><span><?=htmlspecialchars($r['nome'])?></span><div class="dash-track"><div class="dash-fill" style="width:<?=round(((int)$r['total']/$m)*100)?>%"></div></div><b><?=$r['total']?></b></div><?php endforeach; if(!$equipEstados):?><div class="dash-empty">Ainda não existem equipamentos registados.</div><?php endif;?></div>
<div class="dash-panel dash-panel-wide"><div class="dash-columns"><div><p class="dash-subtitle">Tipos de equipamento</p><?php $m=bar_max($equipTipos); foreach($equipTipos as $r):?><div class="dash-row"><span><?=htmlspecialchars($r['nome'])?></span><div class="dash-track"><div class="dash-fill" style="width:<?=round(((int)$r['total']/$m)*100)?>%"></div></div><b><?=$r['total']?></b></div><?php endforeach; if(!$equipTipos):?><div class="dash-empty">Sem dados disponíveis.</div><?php endif;?></div><div><p class="dash-subtitle">Equipamentos por ramo</p><?php $m=bar_max($equipRamos); foreach($equipRamos as $r):?><div class="dash-row"><span><?=htmlspecialchars($r['nome'])?></span><div class="dash-track"><div class="dash-fill" style="width:<?=round(((int)$r['total']/$m)*100)?>%"></div></div><b><?=$r['total']?></b></div><?php endforeach; if(!$equipRamos):?><div class="dash-empty">Sem dados disponíveis.</div><?php endif;?></div></div></div><?php endif; ?>
</section>
</div>
<?php require __DIR__.'/../layout/footer.php'; ?>
