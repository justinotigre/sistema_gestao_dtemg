<?php
require_once __DIR__ . '/../../app/auth.php';
require_login();
require_permission('UTILIZADORES_VISUALIZAR');

$pdo=db();
$page_title='Utilizadores';
$returnTo=$_SERVER['REQUEST_URI']??'utilizadores.php';

$pesquisa=trim($_GET['pesquisa']??'');
$perfil=(int)($_GET['perfil']??0);
$ramo=(int)($_GET['ramo']??0);
$unidade=(int)($_GET['unidade']??0);$regiaoFiltro=(int)($_GET['regiao']??0);
$estado=$_GET['estado']??'';

$params=[];$where='1=1';
$nivel=current_user_level();$uid=current_user_id();
if($nivel==='RAMO'){
    $where.=" AND EXISTS(SELECT 1 FROM utilizador_ramo urs JOIN utilizador_ramo uru ON uru.id_ramo=urs.id_ramo WHERE urs.id_utilizador=? AND uru.id_utilizador=u.id_utilizador)";
    $params[]=$uid;
}elseif($nivel==='REGIAO'){
    $where.=" AND (EXISTS(SELECT 1 FROM utilizador_regiao a JOIN utilizador_regiao b ON b.id_regiao=a.id_regiao WHERE a.id_utilizador=? AND b.id_utilizador=u.id_utilizador) OR EXISTS(SELECT 1 FROM utilizador_unidade a JOIN unidades ua ON ua.id_unidade=a.id_unidade JOIN utilizador_unidade b ON b.id_unidade=ua.id_unidade WHERE ua.id_regiao IN (SELECT id_regiao FROM utilizador_regiao WHERE id_utilizador=?) AND b.id_utilizador=u.id_utilizador) OR EXISTS(SELECT 1 FROM utilizadores ux JOIN dados_servico dx ON dx.id_especialista=ux.id_especialista WHERE ux.id_utilizador=u.id_utilizador AND dx.id_regiao IN (SELECT id_regiao FROM utilizador_regiao WHERE id_utilizador=?)))";
    $params[]=$uid;$params[]=$uid;$params[]=$uid;
}elseif($nivel==='UNIDADE'){
    $where.=" AND EXISTS(SELECT 1 FROM utilizador_unidade us JOIN utilizador_unidade uu ON uu.id_unidade=us.id_unidade WHERE us.id_utilizador=? AND uu.id_utilizador=u.id_utilizador)";
    $params[]=$uid;
}
if($pesquisa!==''){
    $where.=" AND (u.nome_utilizador LIKE ? OR u.email LIKE ? OR dp.nome_completo LIKE ? OR ds.nip LIKE ? OR dp.numero_bi LIKE ?)";
    $q='%'.$pesquisa.'%';for($i=0;$i<5;$i++)$params[]=$q;
}
if($perfil>0){$where.=' AND u.id_perfil=?';$params[]=$perfil;}
if(in_array($estado,['ATIVO','INATIVO'],true)){$where.=' AND u.estado=?';$params[]=$estado;}
if($ramo>0){$where.=' AND EXISTS(SELECT 1 FROM utilizador_ramo urf WHERE urf.id_utilizador=u.id_utilizador AND urf.id_ramo=?)';$params[]=$ramo;}
if($unidade>0){$where.=' AND EXISTS(SELECT 1 FROM utilizador_unidade uuf WHERE uuf.id_utilizador=u.id_utilizador AND uuf.id_unidade=?)';$params[]=$unidade;}
if($regiaoFiltro>0){$where.=' AND (EXISTS(SELECT 1 FROM utilizador_regiao urf WHERE urf.id_utilizador=u.id_utilizador AND urf.id_regiao=?) OR EXISTS(SELECT 1 FROM utilizador_unidade uu JOIN unidades un ON un.id_unidade=uu.id_unidade WHERE uu.id_utilizador=u.id_utilizador AND un.id_regiao=?) OR EXISTS(SELECT 1 FROM dados_servico dsr WHERE dsr.id_especialista=u.id_especialista AND dsr.id_regiao=?))';$params[]=$regiaoFiltro;$params[]=$regiaoFiltro;$params[]=$regiaoFiltro;}

$perfis=$pdo->query("SELECT id_perfil,nome,nivel_acesso FROM perfis WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$ramos=$pdo->query("SELECT id_ramo,nome,sigla FROM ramo WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$regioes=$pdo->query("SELECT id_regiao,nome FROM regioes WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$unidades=$pdo->query("SELECT id_unidade,id_ramo,nome,sigla FROM unidades WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
if($nivel==='RAMO'){
    $ids=current_user_branch_ids();
    $ramos=array_values(array_filter($ramos,fn($r)=>in_array((int)$r['id_ramo'],$ids,true)));
    $unidades=array_values(array_filter($unidades,fn($u)=>in_array((int)$u['id_ramo'],$ids,true)));
}

$sql="
SELECT u.id_utilizador,u.nome_utilizador,u.email,u.foto,u.estado,u.ultimo_acesso,
       u.id_especialista,
       p.nome perfil_nome,p.nivel_acesso,
       dp.nome_completo especialista_nome,ds.nip,
       GROUP_CONCAT(DISTINCT r.sigla ORDER BY r.sigla SEPARATOR ', ') ramos_nomes,
       (SELECT GROUP_CONCAT(DISTINCT uu.sigla ORDER BY uu.sigla SEPARATOR ', ')
          FROM utilizador_unidade ux JOIN unidades uu ON uu.id_unidade=ux.id_unidade
         WHERE ux.id_utilizador=u.id_utilizador) unidades_nomes
FROM utilizadores u
JOIN perfis p ON p.id_perfil=u.id_perfil
LEFT JOIN especialistas e ON e.id_especialista=u.id_especialista
LEFT JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista
LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista
LEFT JOIN utilizador_ramo ur ON ur.id_utilizador=u.id_utilizador
LEFT JOIN ramo r ON r.id_ramo=ur.id_ramo
WHERE $where
GROUP BY u.id_utilizador
ORDER BY u.nome_utilizador";
$st=$pdo->prepare($sql);$st->execute($params);$utilizadores=$st->fetchAll(PDO::FETCH_ASSOC);
if(user_is_rh_admin()) $utilizadores=array_values(array_filter($utilizadores,fn($u)=>user_can_manage_delegated_account((int)$u['id_utilizador'])));
if(user_is_rh_admin()) $perfis=array_values(array_filter($perfis,'user_may_delegate_profile'));
?>
<?php require __DIR__.'/../layout/header.php'; ?>
<div class="module-page module-utilizadores">
<section class="list-hero">
<div><span class="eyebrow">CONTROLO DE ACESSO</span><h1>Utilizadores</h1><p>Contas, especialistas associados e âmbito de acesso.</p></div>
<?php if(has_permission('UTILIZADORES_CRIAR')): ?><a class="btn btn-primary" href="utilizador_novo.php?return_to=<?=urlencode($returnTo)?>">+ Novo utilizador</a><?php endif; ?>
</section>
<form method="get" class="panel filters-card">
<div class="filters-grid">
<label>Pesquisa<input name="pesquisa" value="<?=htmlspecialchars($pesquisa)?>" placeholder="Utilizador, nome, NIP ou BI"></label>
<label>Perfil<select name="perfil"><option value="0">Todos</option><?php foreach($perfis as $p):?><option value="<?=$p['id_perfil']?>" <?=$perfil===$p['id_perfil']?'selected':''?>><?=htmlspecialchars($p['nome'])?></option><?php endforeach;?></select></label>
<label>Ramo<select name="ramo"><option value="0">Todos</option><?php foreach($ramos as $r):?><option value="<?=$r['id_ramo']?>" <?=$ramo===$r['id_ramo']?'selected':''?>><?=htmlspecialchars($r['sigla']?:$r['nome'])?></option><?php endforeach;?></select></label>
<label>Unidade<select name="unidade"><option value="0">Todas</option><?php foreach($unidades as $u):?><option value="<?=$u['id_unidade']?>" <?=$unidade===$u['id_unidade']?'selected':''?>><?=htmlspecialchars(($u['sigla']?:$u['nome']).' — '.$u['nome'])?></option><?php endforeach;?></select></label>
<label>Região<select name="regiao"><option value="0">Todas</option><?php foreach($regioes as $rg):?><option value="<?=$rg['id_regiao']?>" <?=$regiaoFiltro===(int)$rg['id_regiao']?'selected':''?>><?=htmlspecialchars($rg['nome'])?></option><?php endforeach;?></select></label>
<label>Estado<select name="estado"><option value="">Todos</option><option value="ATIVO" <?=$estado==='ATIVO'?'selected':''?>>Ativo</option><option value="INATIVO" <?=$estado==='INATIVO'?'selected':''?>>Inativo</option></select></label>
<div class="filter-actions"><button class="btn btn-primary">Pesquisar</button><a class="btn btn-secondary" href="utilizadores.php">Limpar</a></div>
</div>
</form>
<div class="list-meta"><strong><?=count($utilizadores)?></strong> utilizador(es) encontrado(s)</div>
<div class="panel table-card"><div class="table-scroll"><table class="data-table"><thead><tr><th>Utilizador</th><th>Especialista</th><th>Perfil</th><th>Ramo</th><th>Unidade</th><th>Âmbito de acesso</th><th>Estado</th><th></th></tr></thead><tbody>
<?php foreach($utilizadores as $u):?>
<?php
$ramoSiglaLinha = strtoupper(trim((string)($u['ramos_nomes'] ?? '')));
$ramoSiglaLinha = $ramoSiglaLinha !== '' ? trim(explode(',', $ramoSiglaLinha)[0]) : '';
$ramoClasseLinha = preg_replace('/[^A-Z0-9_-]/', '', $ramoSiglaLinha);
$nivelLinha = strtoupper((string)($u['nivel_acesso'] ?? 'GLOBAL'));
?>
<tr class="user-row identity-<?=htmlspecialchars($nivelLinha, ENT_QUOTES, 'UTF-8')?> ramo-<?=htmlspecialchars($ramoClasseLinha, ENT_QUOTES, 'UTF-8')?>">
<td><div class="user-cell"><?php if($u['foto']):?><img src="<?=htmlspecialchars(app_file_url($u['foto']))?>" alt=""><?php else:?><span class="avatar"><?=htmlspecialchars(strtoupper(substr($u['nome_utilizador'],0,1)))?></span><?php endif;?><strong><?=htmlspecialchars($u['nome_utilizador'])?></strong></div></td>
<td><?=htmlspecialchars($u['especialista_nome']?:'Não associado')?><?php if($u['nip']):?><small><?=htmlspecialchars($u['nip'])?></small><?php endif;?></td>
<td><span class="profile-badge <?= $nivelLinha === 'GLOBAL' ? 'profile-global' : 'profile-scoped' ?>"><?=htmlspecialchars($u['perfil_nome'])?></span></td>
<td><span class="user-branch-badge ramo-<?=htmlspecialchars($ramoClasseLinha, ENT_QUOTES, 'UTF-8')?>"><?=htmlspecialchars($u['ramos_nomes']?:'—')?></span></td>
<td><?=htmlspecialchars($u['unidades_nomes']?:'—')?></td>
<td><span class="scope-badge"><?=htmlspecialchars($u['nivel_acesso']?:'GLOBAL')?></span></td>
<td><span class="status-badge <?=$u['estado']==='ATIVO'?'ok':'off'?>"><?=htmlspecialchars($u['estado'])?></span></td>
<td><a class="btn btn-small btn-secondary" href="utilizador_editar.php?id=<?=$u['id_utilizador']?>&return_to=<?=urlencode($returnTo)?>">Editar</a></td>
</tr>
<?php endforeach;?>
<?php if(!$utilizadores):?><tr><td colspan="8" class="empty-state">Nenhum utilizador encontrado dentro do seu âmbito.</td></tr><?php endif;?>
</tbody></table></div></div>
</div>
<?php require __DIR__.'/../layout/footer.php'; ?>
