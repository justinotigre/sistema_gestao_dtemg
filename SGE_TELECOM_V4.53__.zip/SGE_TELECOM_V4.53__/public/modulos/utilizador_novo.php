<?php
require_once __DIR__ . '/../../app/auth.php';
require_login();
require_permission('UTILIZADORES_CRIAR');

$pdo = db();
$page_title = 'Novo Utilizador';
$erro = '';
$modalidadeSelecionada='RAMO';
$returnTo = safe_return_url($_POST['return_to'] ?? $_GET['return_to'] ?? null, 'utilizadores.php');

$nivelAtual = current_user_level();
$uidAtual = current_user_id();
$perfilAtual = (string)($_SESSION['user']['perfil'] ?? '');

function nivel_pode_criar(string $nivelAtual, string $nivelAlvo): bool {
    if ($nivelAtual === 'GLOBAL') return true;
    if ($nivelAtual === 'RAMO') return in_array($nivelAlvo, ['RAMO','UNIDADE'], true);
    if ($nivelAtual === 'REGIAO') return in_array($nivelAlvo, ['REGIAO','UNIDADE'], true);
    if ($nivelAtual === 'UNIDADE') return $nivelAlvo === 'UNIDADE';
    return false;
}

$perfis = $pdo->query("SELECT id_perfil,nome,nivel_acesso FROM perfis WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$regioes = $pdo->query("SELECT id_regiao,nome,sigla FROM regioes WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$ramos = $pdo->query("SELECT id_ramo,nome,sigla FROM ramo WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$unidades = $pdo->query("SELECT id_unidade,id_ramo,id_regiao,nome,sigla FROM unidades WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);

$especialistas = $pdo->query("
    SELECT e.id_especialista,e.id_ramo,
           dp.nome_completo,dp.numero_bi,ds.nip,
           r.nome ramo_nome,r.sigla ramo_sigla,
           u.id_unidade,u.nome unidade_nome
    FROM especialistas e
    INNER JOIN dados_pessoais dp ON dp.id_especialista=e.id_especialista
    LEFT JOIN dados_servico ds ON ds.id_especialista=e.id_especialista
    INNER JOIN ramo r ON r.id_ramo=e.id_ramo
    LEFT JOIN unidades u ON u.id_unidade=ds.id_unidade
    WHERE e.estado='ATIVO'
    ORDER BY dp.nome_completo
")->fetchAll(PDO::FETCH_ASSOC);

$meusRamos = current_user_branch_ids();
if ($nivelAtual === 'RAMO') {
    $ramos = array_values(array_filter($ramos, fn($r) => in_array((int)$r['id_ramo'], $meusRamos, true)));
    $unidades = array_values(array_filter($unidades, fn($u) => in_array((int)$u['id_ramo'], $meusRamos, true)));
    $especialistas = array_values(array_filter($especialistas, fn($e) => in_array((int)$e['id_ramo'], $meusRamos, true) && (!user_is_rh_admin() || user_can_edit_specialist((int)$e['id_especialista']))));
} elseif ($nivelAtual === 'REGIAO') {
    $minhasRegioes=current_user_region_ids();
    $unidades=array_values(array_filter($unidades,fn($u)=>in_array((int)($u['id_regiao']??0),$minhasRegioes,true)));
    $ramos=array_values(array_filter($ramos,fn($r)=>in_array((int)$r['id_ramo'],array_map('intval',array_column($unidades,'id_ramo')),true)));
    $especialistas=array_values(array_filter($especialistas,function($e) use ($minhasRegioes,$pdo){$st=$pdo->prepare('SELECT id_regiao FROM dados_servico WHERE id_especialista=?');$st->execute([(int)$e['id_especialista']]);return in_array((int)$st->fetchColumn(),$minhasRegioes,true);}));
} elseif ($nivelAtual === 'UNIDADE') {    $st = $pdo->prepare("SELECT id_unidade FROM utilizador_unidade WHERE id_utilizador=?");
    $st->execute([$uidAtual]);
    $minhasUnidades = array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN));
    $unidades = array_values(array_filter($unidades, fn($u) => in_array((int)$u['id_unidade'], $minhasUnidades, true)));
    $ramos = array_values(array_filter($ramos, fn($r) => in_array((int)$r['id_ramo'], array_map('intval',array_column($unidades,'id_ramo')), true)));
    $especialistas = array_values(array_filter($especialistas, function($e) use ($minhasUnidades) {
        return empty($e['id_unidade']) || in_array((int)$e['id_unidade'], $minhasUnidades, true);
    }));
}

$perfisPermitidos = array_values(array_filter($perfis, function($p) use ($nivelAtual) {
    return nivel_pode_criar($nivelAtual, (string)$p['nivel_acesso']) && user_may_delegate_profile($p);
}));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_utilizador'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = (string)($_POST['senha'] ?? '');
    $confirmacao = (string)($_POST['senha_confirmacao'] ?? '');
    $idPerfil = (int)($_POST['id_perfil'] ?? 0);
    $estado = in_array($_POST['estado'] ?? '', ['ATIVO','INATIVO'], true) ? $_POST['estado'] : 'ATIVO';
    $idEspecialista = (int)($_POST['id_especialista'] ?? 0);
    $idsRegioes = array_values(array_unique(array_filter(array_map('intval', $_POST['regioes'] ?? []))));
    $idsRamos = array_values(array_unique(array_filter(array_map('intval', $_POST['ramos'] ?? []))));
    $locaisServico = array_values(array_intersect(['EMG','EXE','FAN','MGA'], array_map('strtoupper', (array)($_POST['locais_servico'] ?? []))));
    $modalidadeGestao = strtoupper((string)($_POST['modalidade_gestao'] ?? 'RAMO'));
    if (!in_array($modalidadeGestao,['RAMO','LOCAL','COMBINADO'],true)) $modalidadeGestao='RAMO';
    $idsUnidades = array_values(array_unique(array_filter(array_map('intval', $_POST['unidades'] ?? []))));

    $perfilEscolhido = null;
    foreach ($perfisPermitidos as $p) {
        if ((int)$p['id_perfil'] === $idPerfil) { $perfilEscolhido = $p; break; }
    }

    if ($nome === '' || $senha === '' || $confirmacao === '' || $idPerfil <= 0) {
        $erro = 'Preencha utilizador, senha, confirmação da senha e perfil.';
    } elseif (strlen($senha) < 8) {
        $erro = 'A senha deve ter pelo menos 8 caracteres.';
    } elseif ($senha !== $confirmacao) {
        $erro = 'A confirmação da senha não coincide.';
    } elseif (!$perfilEscolhido) {
        $erro = 'O perfil selecionado não está disponível para o seu nível de acesso.';
    } elseif ($idEspecialista > 0 && !in_array($idEspecialista, array_map('intval',array_column($especialistas,'id_especialista')), true)) {
        $erro = 'O especialista selecionado está fora do seu âmbito de acesso.';
    } elseif ($idEspecialista > 0 && $pdo->query("SELECT COUNT(*) FROM utilizadores WHERE id_especialista=".(int)$idEspecialista)->fetchColumn() > 0) {
        $erro = 'Este especialista já possui uma conta de utilizador.';
    } elseif ($perfilEscolhido['nivel_acesso'] === 'REGIAO' && count($idsRegioes) !== 1) {
        $erro = 'Um gestor regional deve ter exactamente uma região no seu âmbito de acesso.';
    } elseif ($perfilEscolhido['nivel_acesso'] === 'RAMO' && !$idsRamos) {
        $erro = 'Este perfil exige pelo menos um ramo.';
    } elseif ($perfilEscolhido['nivel_acesso'] === 'UNIDADE' && count($idsUnidades) !== 1) {
        $erro = 'Um gestor local deve ter exactamente uma unidade no seu âmbito de acesso.';
    }

    // Nunca permitir que um administrador delegado atribua locais de edição
    // acima dos próprios direitos. Isto também protege chamadas POST diretas.
    if ($erro === '' && $nivelAtual !== 'GLOBAL' && $modalidadeGestao !== current_user_edit_mode()) $erro='Só um administrador global pode atribuir uma modalidade de gestão diferente.';
    if ($erro === '' && !user_can_delegate_scope($idsRamos,$locaisServico,$idsUnidades,$modalidadeGestao)) {
        $erro='Âmbito delegado superior ao seu âmbito autorizado.';
    }
    if ($erro === '' && $nivelAtual !== 'GLOBAL' && array_diff($locaisServico, user_service_locations())) {
        $erro='Não pode atribuir um Local de Serviço fora do seu próprio âmbito.';
    }

    if ($erro === '' && $nivelAtual === 'REGIAO') {
        $minhasRegioes=current_user_region_ids();
        if ($perfilEscolhido['nivel_acesso']==='REGIAO' && array_diff($idsRegioes,$minhasRegioes)) $erro='Só pode atribuir regiões do seu âmbito.';
    }

    if ($erro === '' && $nivelAtual === 'RAMO') {
        if ($perfilEscolhido['nivel_acesso'] === 'RAMO' && array_diff($idsRamos, $meusRamos)) {
            $erro = 'Só pode atribuir o seu próprio ramo.';
        }
        $permitidasUnidades = array_map('intval', array_column($unidades,'id_unidade'));
        if ($perfilEscolhido['nivel_acesso'] === 'UNIDADE' && array_diff($idsUnidades, $permitidasUnidades)) {
            $erro = 'Só pode atribuir unidades do seu próprio ramo.';
        }
    }

    if ($erro === '' && $nivelAtual === 'UNIDADE') {
        $permitidasUnidades = array_map('intval', array_column($unidades,'id_unidade'));
        if ($perfilEscolhido['nivel_acesso'] === 'UNIDADE' && array_diff($idsUnidades, $permitidasUnidades)) {
            $erro = 'Só pode atribuir unidades do seu âmbito.';
        }
    }

    if ($erro === '') {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                INSERT INTO utilizadores
                (nome_utilizador,senha,email,id_perfil,id_especialista,estado)
                VALUES (?,?,?,?,?,?)
            ");
            $stmt->execute([
                $nome,password_hash($senha,PASSWORD_DEFAULT),$email !== '' ? $email : null,
                $idPerfil,$idEspecialista ?: null,$estado
            ]);
            $id = (int)$pdo->lastInsertId();
            $pdo->prepare('UPDATE utilizadores SET modalidade_gestao=? WHERE id_utilizador=?')->execute([$modalidadeGestao,$id]);

            if ($perfilEscolhido['nivel_acesso'] === 'REGIAO') {
                $q = $pdo->prepare("INSERT INTO utilizador_regiao(id_utilizador,id_regiao) VALUES(?,?)"); foreach($idsRegioes as $rid) $q->execute([$id,$rid]);
            } elseif ($perfilEscolhido['nivel_acesso'] === 'RAMO') {
                $q = $pdo->prepare("INSERT INTO utilizador_ramo(id_utilizador,id_ramo) VALUES(?,?)");
                foreach ($idsRamos as $rid) $q->execute([$id,$rid]);
            } elseif ($perfilEscolhido['nivel_acesso'] === 'UNIDADE') {
                $q = $pdo->prepare("INSERT INTO utilizador_unidade(id_utilizador,id_unidade) VALUES(?,?)");
                foreach ($idsUnidades as $uid) $q->execute([$id,$uid]);

                $qR = $pdo->prepare("INSERT IGNORE INTO utilizador_ramo(id_utilizador,id_ramo) SELECT ?,id_ramo FROM unidades WHERE id_unidade=?");
                foreach ($idsUnidades as $uid) $qR->execute([$id,$uid]);
            }

            $insLocal=$pdo->prepare('INSERT INTO utilizador_local_servico(id_utilizador,local_servico) VALUES(?,?)');
            foreach ($locaisServico as $local) $insLocal->execute([$id,$local]);

            if (!empty($_FILES['foto']['name']) && is_uploaded_file($_FILES['foto']['tmp_name'])) {
                $ext = strtolower(pathinfo($_FILES['foto']['name'],PATHINFO_EXTENSION));
                if (!in_array($ext,['jpg','jpeg','png','webp'],true)) throw new RuntimeException('Formato de foto não permitido.');
                $dir = app_public_path('uploads/utilizadores');
                if (!is_dir($dir)) mkdir($dir,0775,true);
                $file = 'utilizador_'.$id.'_'.bin2hex(random_bytes(5)).'.'.$ext;
                if (!move_uploaded_file($_FILES['foto']['tmp_name'],$dir.DIRECTORY_SEPARATOR.$file)) throw new RuntimeException('Não foi possível guardar a fotografia.');
                $pdo->prepare("UPDATE utilizadores SET foto=? WHERE id_utilizador=?")->execute(['uploads/utilizadores/'.$file,$id]);
            }

            $pdo->commit();
            registar_auditoria($pdo,'UTILIZADORES','CRIACAO','UTILIZADORES','utilizadores',$id,'Utilizador criado.');
            header('Location: '.$returnTo.(str_contains($returnTo,'?')?'&':'?').'criado=1');
            exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $erro = 'Não foi possível criar o utilizador: '.$e->getMessage();
        }
    }
}
?>
<?php require __DIR__.'/../layout/header.php'; ?>
<div class="module-page module-utilizador-form">
<section class="form-hero">
    <div><span class="eyebrow">CONTROLO DE ACESSO</span><h1>Novo utilizador</h1><p>Crie a conta, associe o especialista e defina o âmbito de responsabilidade.</p></div>
    <a class="btn btn-secondary" href="<?=htmlspecialchars($returnTo)?>">← Voltar</a>
</section>
<?php if($erro):?><div class="erro form-alert"><?=htmlspecialchars($erro)?></div><?php endif;?>
<form method="post" enctype="multipart/form-data" class="user-form">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
<input type="hidden" name="return_to" value="<?=htmlspecialchars($returnTo,ENT_QUOTES)?>">
<section class="panel form-card">
<h2>Identidade de acesso</h2>
<div class="form-grid">
<label>Nome de utilizador *<input required name="nome_utilizador" value="<?=htmlspecialchars($_POST['nome_utilizador']??'')?>" autocomplete="username"></label>
<label>E-mail<input type="email" name="email" value="<?=htmlspecialchars($_POST['email']??'')?>"></label>
<label>Senha *<input required type="password" name="senha" autocomplete="new-password"></label>
<label>Confirmar senha *<input required type="password" name="senha_confirmacao" autocomplete="new-password"></label>
<label>Perfil *<select required name="id_perfil" id="idPerfil"><option value="">Selecione</option><?php foreach($perfisPermitidos as $p):?><option value="<?=$p['id_perfil']?>" data-nivel="<?=htmlspecialchars($p['nivel_acesso'])?>"><?=htmlspecialchars($p['nome'])?></option><?php endforeach;?></select></label>
<label>Estado<select name="estado"><option value="ATIVO">ATIVO</option><option value="INATIVO">INATIVO</option></select></label>
</div>
</section>

<section class="panel form-card">
<h2>Especialista associado</h2>
<p class="help">Um especialista pode ter uma única conta. A associação não duplica o cadastro profissional.</p>
<label class="full">Especialista
<select name="id_especialista" id="idEspecialista">
<option value="0">Não associar agora</option>
<?php foreach($especialistas as $e):?>
<option value="<?=$e['id_especialista']?>" data-ramo="<?=$e['id_ramo']?>" data-nip="<?=htmlspecialchars($e['nip']??'')?>" data-bi="<?=htmlspecialchars($e['numero_bi']??'')?>" data-unidade="<?=htmlspecialchars($e['unidade_nome']??'')?>"><?=htmlspecialchars($e['nome_completo'].' — NIP '.($e['nip']??'—').' — BI '.($e['numero_bi']??'—'))?></option>
<?php endforeach;?>
</select>
</label>
<div id="especialistaResumo" class="selection-summary">Selecione um especialista para confirmar nome, NIP, BI, ramo e unidade.</div>
</section>

<section class="panel form-card">
<h2>Âmbito de acesso</h2>
<label class="full">Modalidade de Gestão
<select name="modalidade_gestao" <?= $nivelAtual==='GLOBAL'?'':'disabled' ?>>
<option value="RAMO" <?= ($modalidadeSelecionada??'RAMO')==='RAMO'?'selected':'' ?>>Ramo — editar apenas no Local do próprio Ramo</option>
<option value="LOCAL" <?= ($modalidadeSelecionada??'RAMO')==='LOCAL'?'selected':'' ?>>Local de Serviço — gerir os especialistas colocados no Local autorizado, independentemente do Ramo</option>
<option value="COMBINADO" <?= ($modalidadeSelecionada??'RAMO')==='COMBINADO'?'selected':'' ?>>Combinado — Ramo e Locais de Serviço autorizados</option>
</select><?php if($nivelAtual!=='GLOBAL'): ?><input type="hidden" name="modalidade_gestao" value="<?=htmlspecialchars($modalidadeSelecionada??'RAMO')?>"><?php endif; ?>
<small>O acesso à consulta e as permissões de edição são validados no servidor. Locais de Serviço devem estar autorizados abaixo.</small></label>

<div class="access-note" id="acessoNota">Selecione o perfil para definir o âmbito.</div>
<label id="campoRegioes" class="full">Regiões<select name="regioes[]" id="regioes" multiple size="4"><?php foreach($regioes as $r):?><option value="<?=$r['id_regiao']?>"><?=htmlspecialchars(($r['sigla']?:$r['nome']).' — '.$r['nome'])?></option><?php endforeach;?></select><small>Para perfis com nível REGIÃO.</small></label>
<div id="campoRamos" class="full"><div class="access-choice-title">Ramos autorizados para consulta</div><div class="access-choice-grid"><?php foreach($ramos as $r): ?><label class="access-choice"><input type="checkbox" name="ramos[]" value="<?=$r['id_ramo']?>" <?=in_array((int)$r['id_ramo'],array_map('intval',(array)($_POST['ramos']??[])),true)?'checked':''?> ><span><?=htmlspecialchars(($r['sigla']?:$r['nome']).' — '.$r['nome'])?></span></label><?php endforeach; ?></div><small>Selecione um ou vários Ramos, independentemente dos Locais de Serviço.</small></div>
<div class="full"><div class="access-choice-title">Locais de Serviço autorizados para edição</div><div class="access-choice-grid"><?php foreach(($nivelAtual==='GLOBAL'?['EMG','EXE','FAN','MGA']:user_service_locations()) as $ls): ?><label class="access-choice"><input type="checkbox" name="locais_servico[]" value="<?=$ls?>" <?=in_array($ls,array_map('strtoupper',(array)($_POST['locais_servico']??[])),true)?'checked':''?> ><span><?=$ls?></span></label><?php endforeach; ?></div><small>No modo Combinado pode assinalar simultaneamente Ramos e Locais de Serviço. Os direitos de edição são validados no servidor.</small></div>
<label id="campoUnidades" class="full">Unidades<select name="unidades[]" id="unidades" multiple size="6"><?php foreach($unidades as $u):?><option value="<?=$u['id_unidade']?>" data-ramo="<?=$u['id_ramo']?>"><?=htmlspecialchars(($u['sigla']?:$u['nome']).' — '.$u['nome'])?></option><?php endforeach;?></select><small>Para perfis com nível UNIDADE.</small></label>
</section>

<section class="panel form-card">
<h2>Fotografia</h2>
<div class="photo-upload"><div class="photo-preview" id="fotoPreview"><span>U</span></div><div><input id="fotoInput" type="file" name="foto" accept="image/jpeg,image/png,image/webp"><p class="help">JPG, PNG ou WEBP.</p></div></div>
</section>

<div class="form-actions"><a class="btn btn-secondary" href="<?=htmlspecialchars($returnTo)?>">Cancelar</a><button class="btn btn-primary">Criar utilizador</button></div>
</form>
<script>
(function(){
 const perfil=document.getElementById('idPerfil'), nota=document.getElementById('acessoNota');
 function atualizar(){const o=perfil.options[perfil.selectedIndex],n=o?o.dataset.nivel:'';document.getElementById('campoRegioes').style.display=n==='REGIAO'?'':'none';document.getElementById('campoRamos').style.display=n==='RAMO'?'':'none';document.getElementById('campoUnidades').style.display=n==='UNIDADE'?'':'none';nota.textContent=n==='GLOBAL'?'Acesso global.':n==='REGIAO'?'Acesso limitado à(s) região(ões) selecionada(s).':n==='RAMO'?'Acesso limitado ao(s) ramo(s) selecionado(s).':'Acesso limitado à(s) unidade(s) selecionada(s).';}
 perfil.addEventListener('change',atualizar);atualizar();
 const si=document.getElementById('idEspecialista'), resumo=document.getElementById('especialistaResumo');
 si.addEventListener('change',()=>{const o=si.options[si.selectedIndex];resumo.innerHTML=o.value==='0'?'Selecione um especialista para confirmar nome, NIP, BI, ramo e unidade.':'<strong>'+o.text.split(' — ')[0]+'</strong><br>NIP: '+(o.dataset.nip||'—')+' · BI: '+(o.dataset.bi||'—')+' · Unidade: '+(o.dataset.unidade||'—');});
 const fi=document.getElementById('fotoInput'),fp=document.getElementById('fotoPreview');fi.addEventListener('change',()=>{const f=fi.files?.[0];if(!f)return;const rd=new FileReader();rd.onload=e=>fp.innerHTML='<img src="'+e.target.result+'" alt="Pré-visualização">';rd.readAsDataURL(f);});
})();
</script>
</div>
<?php require __DIR__.'/../layout/footer.php'; ?>
