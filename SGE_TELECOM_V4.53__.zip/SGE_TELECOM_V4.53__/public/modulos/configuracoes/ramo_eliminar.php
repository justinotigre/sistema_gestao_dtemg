<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/historico.php';
require_login();
require_permission('RAMOS_GERIR');
$pdo=db();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Método não permitido.'); }
$id=(int)($_POST['id']??0);
if($id>0){$q=$pdo->prepare('SELECT * FROM ramo WHERE id_ramo=?');$q->execute([$id]);$a=$q->fetch(PDO::FETCH_ASSOC);if($a&&$a['estado']==='ATIVO'){$pdo->prepare("UPDATE ramo SET estado='INATIVO' WHERE id_ramo=?")->execute([$id]);$d=$a;$d['estado']='INATIVO';registar_historico($pdo,'ramo',$id,'INATIVACAO',$a,$d);}}
header('Location: ramos.php?estado=1');exit;
