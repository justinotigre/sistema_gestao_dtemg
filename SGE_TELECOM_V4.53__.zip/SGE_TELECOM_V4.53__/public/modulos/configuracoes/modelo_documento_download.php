<?php
require_once __DIR__ . '/../../../app/auth.php';
require_login();
if (($_SESSION['user']['nivel'] ?? '') !== 'GLOBAL') { http_response_code(403); exit('Acesso restrito ao administrador global.'); }
$id=(int)($_GET['id']??0);
$dir=app_public_path('uploads/modelos_documentos');
$file=null;
foreach(['docx','html','htm','txt'] as $ext){$p=$dir.DIRECTORY_SEPARATOR.'modelo_'.$id.'.'.$ext;if(is_file($p)){$file=$p;break;}}
if(!$file){http_response_code(404);exit('Ficheiro de modelo não encontrado.');}
$mime=['docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document','html'=>'text/html; charset=UTF-8','htm'=>'text/html; charset=UTF-8','txt'=>'text/plain; charset=UTF-8'][$ext];
header('Content-Type: '.$mime);
header('Content-Length: '.filesize($file));
header('Content-Disposition: inline; filename="modelo_'.$id.'.'.$ext.'"');
readfile($file); exit;
