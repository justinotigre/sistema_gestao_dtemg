<?php
require_once __DIR__.'/../../../app/auth.php';
require_login();
require_permission('CONFIGURACOES_VISUALIZAR');
$page_title='Configurações';
require __DIR__.'/../../layout/header.php';
?>
<div class="module-page config-home"><main class="page">
  <div class="page-header config-home-header"><div><span class="config-kicker">ADMINISTRAÇÃO DO SISTEMA</span><h1>Configurações</h1><p>Organize as listas, referências e modelos utilizados no cadastro e na emissão de documentos.</p></div></div>
  <div class="config-grid config-grid-elegante">
    <section class="panel config-card config-card-structure"><div class="config-icon">◆</div><h3>Estrutura</h3><p>Elementos principais da organização.</p><div class="config-links-grid"><a class="config-link" href="ramos.php"><span>Ramos</span><b>→</b></a><a class="config-link" href="regioes.php"><span>Regiões</span><b>→</b></a><a class="config-link" href="unidades.php"><span>Unidades</span><b>→</b></a><a class="config-link" href="patentes.php"><span>Patentes</span><b>→</b></a><a class="config-link" href="funcoes.php"><span>Funções</span><b>→</b></a><a class="config-link" href="categorias_civis.php"><span>Categorias Civis</span><b>→</b></a><a class="config-link" href="fps.php"><span>Formas de Prestação de Serviço (FPS)</span><b>→</b></a><a class="config-link" href="situacoes_servico.php"><span>Estado funcional</span><b>→</b></a><a class="config-link" href="bancos.php"><span>Bancos</span><b>→</b></a></div></section>
    <section class="panel config-card"><div class="config-icon">♙</div><h3>Perfis e módulos</h3><p>Defina os módulos visíveis para cada perfil sem alterar código nem a estrutura da base de dados.</p><a class="config-link" href="perfis.php"><span>Gerir perfis e acessos</span><b>→</b></a></section>
    <section class="panel config-card"><div class="config-icon">▦</div><h3>Formação</h3><p>Listas utilizadas nas formações e habilitações.</p><a class="config-link" href="formacoes.php"><span>Formações</span><b>→</b></a><a class="config-link" href="instituicoes.php"><span>Instituições</span><b>→</b></a></section>
    <section class="panel config-card"><div class="config-icon">◷</div><h3>Licenças</h3><p>Tipos de licença utilizados no histórico do especialista.</p><a class="config-link" href="tipos_licenca.php"><span>Tipos de licença</span><b>→</b></a></section>
    <section class="panel config-card"><div class="config-icon">▤</div><h3>Documentos</h3><p>Arquivo documental e tipos disponíveis.</p><a class="config-link" href="modelos_listas.php"><span>Modelos de Listas</span><b>→</b></a><a class="config-link" href="modelos_documentos.php"><span>Modelos de documentos</span><b>→</b></a><a class="config-link" href="tipos_documento.php"><span>Tipos de documento</span><b>→</b></a></section>
    <section class="panel config-card"><div class="config-icon">☷</div><h3>Feed e comunicação</h3><p>Defina o acesso às publicações, oportunidades e comunicados por perfil.</p><a class="config-link" href="feed_permissoes.php"><span>Permissões do Feed</span><b>→</b></a></section>
    <section class="panel config-card config-card-history"><div class="config-icon">◫</div><h3>Histórico</h3><p>Rastreabilidade das alterações feitas nas configurações.</p><a class="config-link" href="historico.php"><span>Histórico de configurações</span><b>→</b></a></section>
  </div>
</main></div>
<?php require __DIR__.'/../../layout/footer.php'; ?>
