<?php
require_once __DIR__ . '/../../../app/auth.php';
require_login();
require_permission('CONFIGURACOES_GERIR');
if (($_SESSION['user']['nivel'] ?? '') !== 'GLOBAL') { http_response_code(403); exit('Acesso restrito ao administrador global.'); }

$pdo = db();
$msg = '';
$erro = '';
$edit = null;
$uploadDir = app_public_path('uploads/modelos_documentos');
if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);

function md_escape(string $text): string { return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function md_sanitize_html(string $html): string {
    $html = preg_replace('~<\s*(script|style|iframe|object|embed|form|input|button|textarea|select)[^>]*>.*?<\s*/\s*\1\s*>~is', '', $html);
    $html = preg_replace('/\s+on[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);
    $html = preg_replace('/javascript\s*:/i', '', $html);
    return strip_tags($html, '<p><br><strong><b><em><i><u><s><h1><h2><h3><h4><h5><h6><ul><ol><li><table><thead><tbody><tr><th><td><div><span><blockquote><hr>');
}
function md_docx_to_html(string $path): string {
    if (!class_exists('ZipArchive')) throw new RuntimeException('A extensão ZIP do PHP não está disponível no XAMPP.');
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) throw new RuntimeException('Não foi possível abrir o ficheiro DOCX.');
    $xml = $zip->getFromName('word/document.xml');
    $zip->close();
    if ($xml === false) throw new RuntimeException('O DOCX não contém um documento Word válido.');
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    if (!@$dom->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING)) throw new RuntimeException('Não foi possível interpretar a estrutura do DOCX.');
    $xp = new DOMXPath($dom);
    $xp->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
    $body = $xp->query('//w:body')->item(0);
    if (!$body) return '';
    $out = '';
    foreach ($body->childNodes as $node) {
        if ($node->nodeType !== XML_ELEMENT_NODE) continue;
        if ($node->localName === 'p') {
            $parts = [];
            foreach ($xp->query('.//w:r', $node) as $run) {
                $txt = '';
                foreach ($xp->query('.//w:t|.//w:tab|.//w:br|.//w:cr', $run) as $tn) {
                    if ($tn->localName === 'tab') $txt .= '    ';
                    elseif ($tn->localName === 'br' || $tn->localName === 'cr') $txt .= '<br>';
                    else $txt .= md_escape($tn->textContent);
                }
                $rPr = $xp->query('./w:rPr', $run)->item(0);
                $bold = $rPr && $xp->query('./w:b', $rPr)->length;
                $italic = $rPr && $xp->query('./w:i', $rPr)->length;
                $underline = $rPr && $xp->query('./w:u', $rPr)->length;
                if ($bold) $txt = '<strong>'.$txt.'</strong>';
                if ($italic) $txt = '<em>'.$txt.'</em>';
                if ($underline) $txt = '<u>'.$txt.'</u>';
                $parts[] = $txt;
            }
            $text = implode('', $parts);
            $pPr = $xp->query('./w:pPr', $node)->item(0);
            $align = '';
            if ($pPr) {
                $a = $xp->query('./w:jc', $pPr)->item(0);
                if ($a) {
                    $v = $a->getAttribute('w:val');
                    if (in_array($v, ['center','right','both','left'], true)) $align = ' style="text-align:'.($v==='both'?'justify':$v).'"';
                }
            }
            $out .= '<p'.$align.'>'.$text.'</p>';
        } elseif ($node->localName === 'tbl') {
            $out .= '<table><tbody>';
            foreach ($xp->query('./w:tr', $node) as $tr) {
                $out .= '<tr>';
                foreach ($xp->query('./w:tc', $tr) as $tc) {
                    $cell = '';
                    foreach ($xp->query('./w:p', $tc) as $p) {
                        $parts = [];
                        foreach ($xp->query('.//w:t|.//w:tab|.//w:br|.//w:cr', $p) as $tn) {
                            if ($tn->localName === 'tab') $parts[] = '    ';
                            elseif ($tn->localName === 'br' || $tn->localName === 'cr') $parts[] = '<br>';
                            else $parts[] = md_escape($tn->textContent);
                        }
                        $cell .= '<div>'.implode('', $parts).'</div>';
                    }
                    $out .= '<td>'.$cell.'</td>';
                }
                $out .= '</tr>';
            }
            $out .= '</tbody></table>';
        }
    }
    return $out;
}
function md_import_file(string $path, string $ext): string {
    if ($ext === 'docx') return md_docx_to_html($path);
    $raw = file_get_contents($path);
    if ($raw === false) throw new RuntimeException('Não foi possível ler o ficheiro enviado.');
    if ($ext === 'html' || $ext === 'htm') return md_sanitize_html($raw);
    return '<p>'.nl2br(md_escape($raw)).'</p>';
}
function md_find_file(int $id): ?string {
    $dir = app_public_path('uploads/modelos_documentos');
    foreach (['docx','html','htm','txt'] as $ext) {
        $p = $dir . DIRECTORY_SEPARATOR . 'modelo_' . $id . '.' . $ext;
        if (is_file($p)) return $p;
    }
    return null;
}
function md_relative_file(int $id): ?string {
    $p = md_find_file($id);
    if (!$p) return null;
    return 'uploads/modelos_documentos/' . basename($p);
}

if (isset($_GET['editar'])) {
    $q = $pdo->prepare('SELECT * FROM modelos_solicitacao WHERE id_modelo=?');
    $q->execute([(int)$_GET['editar']]);
    $edit = $q->fetch(PDO::FETCH_ASSOC);
}

if(isset($_GET['sucesso'])) $msg=urldecode((string)$_GET['sucesso']); if(isset($_GET['erro'])) $erro=urldecode((string)$_GET['erro']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $acao = $_POST['acao'] ?? '';
        $id = (int)($_POST['id'] ?? 0);
        if ($acao === 'estado') {
            $pdo->prepare("UPDATE modelos_solicitacao SET estado=IF(estado='ATIVO','INATIVO','ATIVO') WHERE id_modelo=?")->execute([$id]);
            $msg = 'Estado do modelo atualizado.';
        } else {
            $nome = trim($_POST['nome'] ?? '');
            $codigo = strtoupper(trim($_POST['codigo'] ?? ''));
            $assunto = trim($_POST['assunto'] ?? '');
            $categoria = trim($_POST['categoria'] ?? '');
            $conteudo = trim($_POST['conteudo'] ?? '');
            $arquivo = $_FILES['arquivo_modelo'] ?? null;
            $ext = '';
            $temp = null;
            if ($arquivo && ($arquivo['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                if ($arquivo['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Não foi possível receber o ficheiro.');
                if (($arquivo['size'] ?? 0) > 10 * 1024 * 1024) throw new RuntimeException('O ficheiro ultrapassa o limite de 10 MB.');
                $ext = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['docx','html','htm','txt'], true)) throw new RuntimeException('Formato não suportado. Use DOCX, HTML ou TXT.');
                $temp = $arquivo['tmp_name'];
                $conteudo = md_import_file($temp, $ext);
                if ($conteudo === '') throw new RuntimeException('O ficheiro não possui conteúdo utilizável.');
            }
            if ($nome === '' || $codigo === '') throw new RuntimeException('Informe o nome e o código do modelo.');
            if ($id) {
                $pdo->prepare('UPDATE modelos_solicitacao SET nome=?,codigo=?,assunto=?,categoria=?,conteudo=? WHERE id_modelo=?')->execute([$nome,$codigo,$assunto?:null,$categoria?:null,$conteudo?:null,$id]);
                if ($temp) {
                    foreach (['docx','html','htm','txt'] as $old) @unlink($uploadDir . DIRECTORY_SEPARATOR . 'modelo_'.$id.'.'.$old);
                    if (!move_uploaded_file($temp, $uploadDir . DIRECTORY_SEPARATOR . 'modelo_'.$id.'.'.$ext)) throw new RuntimeException('O modelo foi guardado, mas não foi possível guardar o ficheiro original.');
                }
                $msg = 'Modelo atualizado.';
            } else {
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO modelos_solicitacao(nome,codigo,assunto,categoria,conteudo) VALUES(?,?,?,?,?)')->execute([$nome,$codigo,$assunto?:null,$categoria?:null,$conteudo?:null]);
                $id = (int)$pdo->lastInsertId();
                if ($temp && !move_uploaded_file($temp, $uploadDir . DIRECTORY_SEPARATOR . 'modelo_'.$id.'.'.$ext)) throw new RuntimeException('Não foi possível guardar o ficheiro original.');
                $pdo->commit();
                $msg = 'Modelo adicionado.';
            }
            $edit = null;
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $erro = $e->getMessage();
    }
}

$items = $pdo->query('SELECT * FROM modelos_solicitacao ORDER BY categoria,nome')->fetchAll(PDO::FETCH_ASSOC);
$page_title = 'Modelos de Documentos';
require __DIR__.'/../../layout/header.php';
?>
<div class="module-page config-crud-page"><main class="page">
<div class="page-header"><div><span class="config-kicker">DOCUMENTOS</span><h1>Modelos de Documentos</h1><p>Crie modelos no sistema ou importe a estrutura de um documento já preparado no computador.</p></div><a class="btn btn-secondary" href="configuracoes.php">← Configurações</a></div>
<?php if($msg):?><div class="alert-success"><?=md_escape($msg)?></div><?php endif;?>
<?php if($erro):?><div class="alert-error"><?=md_escape($erro)?></div><?php endif;?>
<div class="panel" style="margin-bottom:18px;padding:18px 20px;background:linear-gradient(135deg,#f5f9fc,#fff);border:1px solid var(--borda)"><strong>Importar estrutura existente</strong><p style="margin:7px 0 0;color:#667786">Pode selecionar um ficheiro <b>Word DOCX</b>, HTML ou TXT já preparado. O sistema lê a estrutura básica, transforma-a em modelo editável e guarda também o ficheiro original para referência.</p></div>
<div class="config-editor-grid"><section class="panel form-box"><h2><?=$edit?'Editar modelo':'Novo modelo'?></h2>
<form method="post" enctype="multipart/form-data" class="form-grid">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
<input type="hidden" name="id" value="<?= (int)($edit['id_modelo']??0) ?>">
<div class="form-group"><label>Nome *</label><input name="nome" required value="<?=md_escape($edit['nome']??'')?>"></div>
<div class="form-group"><label>Código *</label><input name="codigo" required value="<?=md_escape($edit['codigo']??'')?>"></div>
<div class="form-group"><label>Categoria</label><input name="categoria" placeholder="Declarações, Serviço..." value="<?=md_escape($edit['categoria']??'')?>"></div>
<div class="form-group"><label>Assunto</label><input name="assunto" value="<?=md_escape($edit['assunto']??'')?>"></div>
<div class="form-group full"><label>Ficheiro de modelo existente</label><input type="file" name="arquivo_modelo" accept=".docx,.html,.htm,.txt"><small class="file-help">Ao importar um DOCX, o texto, parágrafos, alinhamentos, negrito, itálico, sublinhado e tabelas básicas são aproveitados. Limite: 10 MB.</small>
<?php if($edit && md_find_file((int)$edit['id_modelo'])):?><div style="margin-top:8px"><a class="btn btn-small btn-secondary" href="modelo_documento_download.php?id=<?=$edit['id_modelo']?>">Abrir ficheiro original</a></div><?php endif;?></div>
<div class="form-group full"><label>Conteúdo / Modelo</label><textarea name="conteudo" rows="14" placeholder="Escreva ou ajuste o conteúdo do documento..." style="min-height:280px;"> <?=md_escape($edit['conteudo']??'')?></textarea><small class="file-help">Variáveis: {NOME_COMPLETO}, {NIP}, {PATENTE}, {RAMO}, {UNIDADE}, {QUADRO}, {SITUACAO}, {ESTADO}, {NUMERO_BI}, {DATA_NASCIMENTO}, {DATA_ATUAL}. Pode importar primeiro e depois ajustar o modelo.</small></div>
<div class="actions full"><button class="btn btn-primary">Guardar modelo</button><?php if($edit):?><a class="btn btn-secondary" href="modelos_documentos.php">Cancelar</a><?php endif;?></div>
</form></section>
<section class="panel table-wrap"><table><thead><tr><th>Modelo</th><th>Código</th><th>Categoria</th><th>Origem</th><th>Estado</th><th>Ações</th></tr></thead><tbody>
<?php foreach($items as $i): $ficheiro=md_find_file((int)$i['id_modelo']); ?><tr><td><strong><?=md_escape($i['nome'])?></strong><br><small><?=md_escape($i['assunto']?:'')?></small></td><td><?=md_escape($i['codigo'])?></td><td><?=md_escape($i['categoria']?:'—')?></td><td><?=$ficheiro?'<span class="badge badge-success">Ficheiro importado</span>':'Modelo interno'?></td><td><?=md_escape($i['estado'])?></td><td><a class="btn btn-small btn-secondary" href="modelos_documentos.php?editar=<?=$i['id_modelo']?>">Editar</a> <?php if($ficheiro):?><a class="btn btn-small btn-secondary" href="modelo_documento_download.php?id=<?=$i['id_modelo']?>">Ficheiro</a><?php endif;?> <form method="post" style="display:inline">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="acao" value="estado"><input type="hidden" name="id" value="<?=$i['id_modelo']?>"><button class="btn btn-small <?= $i['estado']==='ATIVO'?'btn-danger':'btn-success' ?>"><?= $i['estado']==='ATIVO'?'Desativar':'Ativar' ?></button></form> <form method="post" action="configuracao_eliminar.php" style="display:inline" onsubmit="return confirm('Eliminar este modelo? O registo e o ficheiro original serão removidos.');">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="tabela" value="modelos_solicitacao"><input type="hidden" name="id" value="<?=$i['id_modelo']?>"><button class="btn btn-small btn-secondary">Eliminar</button></form></td></tr><?php endforeach;?></tbody></table></section></div>
</main></div><?php require __DIR__.'/../../layout/footer.php'; ?>
