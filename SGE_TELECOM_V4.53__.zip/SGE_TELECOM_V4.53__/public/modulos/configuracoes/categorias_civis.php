<?php
require_once __DIR__.'/../../../app/auth.php';
require_login(); require_permission('CONFIGURACOES_VISUALIZAR');
$pdo=db(); $erro=''; $sucesso='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 require_permission('CONFIGURACOES_EDITAR'); csrf_verify_post();
 try {
  $acao=(string)($_POST['acao']??''); $id=(int)($_POST['id']??0);
  if ($acao==='criar' || $acao==='editar') {
   $nome=trim((string)($_POST['nome']??''));
   if ($nome==='' || mb_strlen($nome)>160) throw new RuntimeException('Indique uma Categoria válida (até 160 caracteres).');
   if ($acao==='criar') {$st=$pdo->prepare("INSERT INTO categorias_civis(nome) VALUES (?)");$st->execute([$nome]);}
   else {$st=$pdo->prepare('UPDATE categorias_civis SET nome=? WHERE id_categoria_civil=?');$st->execute([$nome,$id]);}
   $sucesso='Categoria guardada.';
  } elseif ($acao==='estado' && $id>0) {
   $st=$pdo->prepare("UPDATE categorias_civis SET estado=IF(estado='ATIVO','INATIVO','ATIVO') WHERE id_categoria_civil=?");$st->execute([$id]);
   $sucesso='Disponibilidade atualizada.';
  }
 }catch(Throwable $e){$erro='Não foi possível concluir a operação: '.$e->getMessage();}
}
$lista=$pdo->query('SELECT id_categoria_civil,nome,estado FROM categorias_civis ORDER BY ordem,nome')->fetchAll(PDO::FETCH_ASSOC);
$page_title='Categorias Civis'; require __DIR__.'/../../layout/header.php';
?>
<div class="module-page"><main class="page"><div class="page-header"><h1>Categorias Civis</h1><p>Gerir as categorias utilizadas no pré-cadastro e na pesquisa de especialistas civis.</p></div>
<?php if($erro):?><div class="alert alert-danger"><?=htmlspecialchars($erro,ENT_QUOTES,'UTF-8')?></div><?php endif;?>
<?php if($sucesso):?><div class="alert alert-success"><?=htmlspecialchars($sucesso,ENT_QUOTES,'UTF-8')?></div><?php endif;?>
<section class="panel" style="padding:20px;margin-bottom:20px"><h2>Adicionar Categoria</h2><form method="post" style="display:flex;align-items:end;gap:12px;flex-wrap:wrap"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="acao" value="criar"><label>Nome <input name="nome" maxlength="160" required placeholder="Ex.: Assessor Principal"></label><button class="btn btn-primary">Adicionar</button></form></section>
<section class="panel" style="padding:20px"><h2>Categorias Registadas</h2><div style="overflow-x:auto"><table class="table" style="width:100%"><thead><tr><th>Categoria</th><th>Estado</th><th>Ações</th></tr></thead><tbody>
<?php foreach($lista as $q): $id=(int)$q['id_categoria_civil']; ?><tr><td><form method="post" id="cat-edit-<?=$id?>"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="acao" value="editar"><input type="hidden" name="id" value="<?=$id?>"><input name="nome" maxlength="160" required value="<?=htmlspecialchars($q['nome'],ENT_QUOTES,'UTF-8')?>"></form></td><td><?=htmlspecialchars($q['estado'])?></td><td><button form="cat-edit-<?=$id?>" class="btn btn-secondary" type="submit">Guardar</button> <form method="post" style="display:inline"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="acao" value="estado"><input type="hidden" name="id" value="<?=$id?>"><button type="submit" class="btn btn-secondary"><?=$q['estado']==='ATIVO'?'Desativar':'Ativar'?></button></form></td></tr><?php endforeach; ?></tbody></table></div></section></main></div>
<?php require __DIR__.'/../../layout/footer.php';
