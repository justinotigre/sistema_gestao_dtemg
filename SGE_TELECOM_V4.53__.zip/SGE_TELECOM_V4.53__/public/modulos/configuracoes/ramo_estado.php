<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/historico.php';
require_login();
require_permission('RAMOS_GERIR');
$pdo=db();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Método não permitido.'); }
$id=(int)($_POST['id']??0); $estado=$_POST['estado']??'';
if($id<=0||!in_array($estado,['ATIVO','INATIVO'],true)){header('Location: ramos.php');exit;}
$q=$pdo->prepare('SELECT * FROM ramo WHERE id_ramo=?');$q->execute([$id]);$antes=$q->fetch(PDO::FETCH_ASSOC);
if($antes){$pdo->prepare('UPDATE ramo SET estado=? WHERE id_ramo=?')->execute([$estado,$id]);$depois=$antes;$depois['estado']=$estado;registar_historico($pdo,'ramo',$id,$estado==='INATIVO'?'INATIVACAO':'REACTIVACAO',$antes,$depois);}
header('Location: ramos.php?estado=1');exit;
