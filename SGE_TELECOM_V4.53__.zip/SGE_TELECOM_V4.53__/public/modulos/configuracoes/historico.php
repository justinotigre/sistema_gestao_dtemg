<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/historico.php';
require_login();
require_permission('CONFIGURACOES_VISUALIZAR');
if (($_SESSION['user']['nivel'] ?? '') !== 'GLOBAL') { http_response_code(403); exit('Acesso restrito ao administrador global.'); }
$pdo = db();
$fTabela = trim($_GET['tabela'] ?? '');
$acao = trim($_GET['acao'] ?? '');
$sql = "SELECT h.*, u.nome_utilizador FROM historico_configuracoes h LEFT JOIN utilizadores u ON u.id_utilizador=h.id_utilizador WHERE 1=1";
$params=[];
if($fTabela!==''){ $sql.=' AND h.tabela=:tabela'; $params[':tabela']=$fTabela; }
if($acao!==''){ $sql.=' AND h.acao=:acao'; $params[':acao']=$acao; }
$sql.=' ORDER BY h.data_registo DESC, h.id_historico DESC LIMIT 500';
$st=$pdo->prepare($sql); $st->execute($params); $items=$st->fetchAll(PDO::FETCH_ASSOC);
$tabelas=$pdo->query("SELECT DISTINCT tabela FROM historico_configuracoes ORDER BY tabela")->fetchAll(PDO::FETCH_COLUMN);
$page_title='Histórico de Configurações'; require __DIR__.'/../../layout/header.php';
function hh($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<div class="module-page config-crud-page"><main class="page">
<div class="page-header"><div><span class="config-kicker">CONTROLO E RASTREABILIDADE</span><h1>Histórico de configurações</h1><p>Registos inativados, reativados, alterados, substituídos ou eliminados ficam preservados para consulta.</p></div><a class="btn btn-secondary" href="configuracoes.php">← Configurações</a></div>
<section class="panel" style="padding:18px;margin-bottom:18px"><form method="get" class="form-grid" style="align-items:end"><div class="form-group"><label>Variável</label><select name="tabela"><option value="">Todas</option><?php foreach($tabelas as $t):?><option value="<?=hh($t)?>" <?=$fTabela===$t?'selected':''?>><?=hh(ucwords(str_replace('_',' ',$t)))?></option><?php endforeach;?></select></div><div class="form-group"><label>Ação</label><select name="acao"><option value="">Todas</option><?php foreach(['CRIACAO','ALTERACAO','INATIVACAO','REACTIVACAO','SUBSTITUICAO','ELIMINACAO'] as $a):?><option <?=$acao===$a?'selected':''?>><?=$a?></option><?php endforeach;?></select></div><div class="actions"><button class="btn btn-primary">Filtrar</button><a class="btn btn-secondary" href="historico.php">Limpar</a></div></form></section>
<section class="panel table-wrap"><table><thead><tr><th>Data</th><th>Variável</th><th>ID</th><th>Ação</th><th>Utilizador</th><th>Detalhes</th></tr></thead><tbody>
<?php foreach($items as $i): $antes=json_decode((string)$i['dados_anteriores'],true)?:[]; $depois=json_decode((string)$i['dados_novos'],true)?:[]; $nome=$depois['nome']??$antes['nome']??$depois['designacao']??$antes['designacao']??('ID '.$i['id_registo']); ?>
<tr><td><?=hh(date('d/m/Y H:i',strtotime($i['data_registo'])))?></td><td><?=hh(ucwords(str_replace('_',' ',$i['tabela'])))?></td><td><?= (int)$i['id_registo']?></td><td><strong><?=hh($i['acao'])?></strong></td><td><?=hh($i['nome_utilizador']??'Sistema')?></td><td><?=hh($nome)?></td></tr>
<?php endforeach; if(!$items):?><tr><td colspan="6" style="text-align:center;padding:30px">Nenhum histórico encontrado.</td></tr><?php endif;?></tbody></table></section>
</main></div><?php require __DIR__.'/../../layout/footer.php'; ?>
