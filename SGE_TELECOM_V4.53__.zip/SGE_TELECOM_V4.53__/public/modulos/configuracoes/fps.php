<?php
require_once __DIR__ . '/../../../app/auth.php';
require_login();
require_permission('CONFIGURACOES_VISUALIZAR');
$pdo=db();
$erro='';$sucesso='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_permission('CONFIGURACOES_EDITAR');
    csrf_verify_post();
    try {
        $acao=(string)($_POST['acao']??'');
        if ($acao==='criar') {
            $nome=trim((string)($_POST['nome']??''));
            $sigla=trim((string)($_POST['sigla']??''));
            if ($nome==='' || mb_strlen($nome)>150 || mb_strlen($sigla)>30) throw new RuntimeException('Indique um nome válido (até 150 caracteres).');
            $st=$pdo->prepare("INSERT INTO quadros_servico(nome,sigla,estado) VALUES (?,?,'ATIVO')");
            $st->execute([$nome,$sigla!==''?$sigla:null]);
            $sucesso='FPS adicionada.';
        } elseif ($acao==='estado') {
            $id=(int)($_POST['id_quadro']??0);
            $st=$pdo->prepare("UPDATE quadros_servico SET estado=CASE WHEN estado='ATIVO' THEN 'INATIVO' ELSE 'ATIVO' END WHERE id_quadro=?");
            $st->execute([$id]);
            $sucesso='Disponibilidade da FPS atualizada.';
        } elseif ($acao==='editar') {
            $id=(int)($_POST['id_quadro']??0);
            $nome=trim((string)($_POST['nome']??''));
            if ($nome==='' || mb_strlen($nome)>150) throw new RuntimeException('Nome inválido.');
            $pdo->prepare('UPDATE quadros_servico SET nome=? WHERE id_quadro=?')->execute([$nome,$id]);
            $sucesso='FPS atualizada.';
        }
    } catch(Throwable $ex) {$erro='Não foi possível aplicar a alteração: '.$ex->getMessage();}
}
$lista=$pdo->query('SELECT id_quadro,nome,sigla,estado FROM quadros_servico ORDER BY nome')->fetchAll(PDO::FETCH_ASSOC);
$page_title='Formas de Prestação de Serviço';
require __DIR__.'/../../layout/header.php';
?>
<div class="module-page"><main class="page"><div class="page-header"><h1>Formas de Prestação de Serviço (FPS)</h1><p>Adicione, altere ou desative as opções disponíveis no cadastro. Os registos existentes mantêm-se preservados.</p></div>
<?php if($erro):?><div class="alert alert-danger"><?=htmlspecialchars($erro)?></div><?php endif;?>
<?php if($sucesso):?><div class="alert alert-success"><?=htmlspecialchars($sucesso)?></div><?php endif;?>
<section class="panel" style="padding:20px;margin-bottom:20px"><h2>Adicionar FPS</h2><form method="post" style="display:flex;gap:12px;flex-wrap:wrap;align-items:end">
<input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="acao" value="criar">
<label>Nome <input name="nome" maxlength="150" required placeholder="Ex.: Serviço efetivo"></label>
<label>Sigla <input name="sigla" maxlength="30" placeholder="Opcional"></label><button class="btn btn-primary">Adicionar</button></form></section>
<section class="panel" style="padding:20px"><h2>Opções registadas</h2><div style="overflow-x:auto"><table class="table" style="width:100%"><thead><tr><th>Nome</th><th>Sigla</th><th>Estado</th><th>Ações</th></tr></thead><tbody>
<?php foreach($lista as $q):?><tr><td><form method="post" id="fps-edit-<?= (int)$q['id_quadro']?>"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="acao" value="editar"><input type="hidden" name="id_quadro" value="<?= (int)$q['id_quadro'] ?>"><input name="nome" maxlength="150" required value="<?=htmlspecialchars($q['nome'])?>"></form></td><td><?=htmlspecialchars($q['sigla']??'')?></td><td><?=htmlspecialchars($q['estado'])?></td><td style="white-space:nowrap"><button type="submit" form="fps-edit-<?= (int)$q['id_quadro']?>" class="btn btn-secondary">Guardar</button> <form method="post" style="display:inline"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="acao" value="estado"><input type="hidden" name="id_quadro" value="<?= (int)$q['id_quadro'] ?>"><button class="btn btn-secondary" type="submit"><?= $q['estado']==='ATIVO'?'Desativar':'Ativar' ?></button></form></td></tr><?php endforeach;?></tbody></table></div></section>
</main></div>
<?php require __DIR__.'/../../layout/footer.php'; ?>
