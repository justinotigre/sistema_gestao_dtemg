<?php
require_once __DIR__.'/../../../app/auth.php';
require_login(); require_permission('CONFIGURACOES_VISUALIZAR');
$pdo=db();$erro='';$ok='';
$colunasPermitidas=['nome'=>'Nome','bi'=>'BI','identificador'=>'NIP / NO','ramo'=>'Ramo','patente'=>'Patente','local'=>'Local de Serviço','unidade'=>'Unidade','estado'=>'Estado','categoria'=>'Categoria'];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_permission('CONFIGURACOES_EDITAR');
    try {
        if (!hash_equals(csrf_token(),(string)($_POST['csrf_token']??''))) throw new RuntimeException('Sessão expirada. Atualize a página.');
        $id=(int)($_POST['id']??0);
        $titulo=trim((string)($_POST['titulo']??''));
        $codigo=preg_replace('/[^a-z0-9_]/','',strtolower((string)($_POST['codigo']??'')));
        $selecionadas=array_values(array_intersect(array_keys($colunasPermitidas),(array)($_POST['colunas']??[])));
        $estado=($_POST['estado']??'ATIVO')==='INATIVO'?'INATIVO':'ATIVO';
        if ($titulo===''||$codigo===''||!$selecionadas) throw new RuntimeException('Indique código, título e pelo menos uma coluna.');
        if ($id>0) {
            $pdo->prepare('UPDATE modelos_listas SET titulo=?,colunas=?,estado=? WHERE id_modelo=?')->execute([$titulo,implode(',',$selecionadas),$estado,$id]);
        } else {
            $pdo->prepare('INSERT INTO modelos_listas(codigo,titulo,colunas,estado) VALUES(?,?,?,?)')->execute([$codigo,$titulo,implode(',',$selecionadas),$estado]);
        }
        $ok='Modelo guardado com sucesso.';
    } catch(Throwable $e){$erro=$e->getMessage();}
}
$registos=$pdo->query('SELECT * FROM modelos_listas ORDER BY id_modelo')->fetchAll(PDO::FETCH_ASSOC);
$page_title='Modelos de Listas';require __DIR__.'/../../layout/header.php';
?>
<div class="module-page"><main class="page"><div class="page-header"><div><h1>Modelos de Listas</h1><p>Configure as colunas e os títulos das listas de especialistas.</p></div><a href="configuracoes.php" class="btn btn-secondary">← Configurações</a></div>
<?php if ($erro):?><div class="alert-error"><?=htmlspecialchars($erro)?></div><?php endif;?>
<?php if ($ok):?><div class="alert-success"><?=htmlspecialchars($ok)?></div><?php endif;?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:15px">
<?php foreach (array_merge($registos,[['id_modelo'=>0,'codigo'=>'','titulo'=>'','colunas'=>'nome,identificador,unidade','estado'=>'ATIVO']]) as $m):?>
<section class="panel" style="padding:20px"><h2><?= $m['id_modelo']?'Editar: '.htmlspecialchars($m['titulo']):'Novo Modelo' ?></h2>
<form method="post"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="id" value="<?=(int)$m['id_modelo']?>">
<div class="form-group"><label>Código</label><input name="codigo" pattern="[a-z0-9_]+" required maxlength="40" value="<?=htmlspecialchars($m['codigo'])?>" <?= $m['id_modelo']?'readonly':'' ?>></div>
<div class="form-group"><label>Título</label><input name="titulo" required maxlength="150" value="<?=htmlspecialchars($m['titulo'])?>"></div>
<div class="form-group"><label>Colunas da lista</label><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
<?php $sel=explode(',',$m['colunas']);foreach($colunasPermitidas as $key=>$label):?><label style="display:flex;gap:6px;align-items:center"><input type="checkbox" name="colunas[]" value="<?=htmlspecialchars($key)?>" <?=in_array($key,$sel,true)?'checked':''?>><?=htmlspecialchars($label)?></label><?php endforeach;?></div></div>
<div class="form-group"><label>Estado</label><select name="estado"><option value="ATIVO" <?=$m['estado']==='ATIVO'?'selected':''?>>ATIVO</option><option value="INATIVO" <?=$m['estado']==='INATIVO'?'selected':''?>>INATIVO</option></select></div>
<button class="btn btn-primary">Guardar</button></form></section>
<?php endforeach;?></div></main></div>
<?php require __DIR__.'/../../layout/footer.php'; ?>
