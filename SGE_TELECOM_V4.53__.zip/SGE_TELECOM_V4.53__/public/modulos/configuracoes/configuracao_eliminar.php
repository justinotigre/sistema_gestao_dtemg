<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/historico.php';
require_login();
$pdo = db();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Método não permitido.'); }
if (!hash_equals(csrf_token(), (string)($_POST['csrf_token'] ?? ''))) { http_response_code(403); exit('Token de segurança inválido.'); }

$alvos = [
    'ramo' => ['pk'=>'id_ramo','rotulo'=>'ramo','retorno'=>'ramos.php','permissao'=>'RAMOS_GERIR'],
    'regioes' => ['pk'=>'id_regiao','rotulo'=>'região','retorno'=>'regioes.php'],
    'unidades' => ['pk'=>'id_unidade','rotulo'=>'unidade','retorno'=>'unidades.php'],
    'patentes' => ['pk'=>'id_patente','rotulo'=>'patente','retorno'=>'patentes.php'],
    'funcoes' => ['pk'=>'id_funcao','rotulo'=>'função','retorno'=>'funcoes.php'],
    'quadros_servico' => ['pk'=>'id_quadro','rotulo'=>'quadro de serviço','retorno'=>'../configuracoes.php'],
    'tipos_formacao' => ['pk'=>'id_tipo_formacao','rotulo'=>'tipo de formação','retorno'=>'tipos_formacao.php'],
    'instituicoes' => ['pk'=>'id_instituicao','rotulo'=>'instituição','retorno'=>'instituicoes.php'],
    'tipos_licenca' => ['pk'=>'id_tipo_licenca','rotulo'=>'tipo de licença','retorno'=>'tipos_licenca.php'],
    'tipos_documento' => ['pk'=>'id_tipo_documento','rotulo'=>'tipo de documento','retorno'=>'tipos_documento.php'],
    'modelos_solicitacao' => ['pk'=>'id_modelo','rotulo'=>'modelo de documento','retorno'=>'modelos_documentos.php'],
    'situacoes_servico' => ['pk'=>'id_situacao_servico','rotulo'=>'estado funcional','retorno'=>'situacoes_servico.php'],
];

$tabela = $_POST['tabela'] ?? '';
$id = (int)($_POST['id'] ?? 0);
if (!isset($alvos[$tabela]) || $id <= 0) { header('Location: configuracoes.php'); exit; }
$cfg = $alvos[$tabela];
require_permission($cfg['permissao'] ?? 'CONFIGURACOES_GERIR');

function redir_cfg(string $url, string $status, string $msg): never {
    header('Location: '.$url.'?'.$status.'='.rawurlencode($msg)); exit;
}

try {
    $pk = $cfg['pk'];
    $q = $pdo->prepare("SELECT * FROM `{$tabela}` WHERE `{$pk}`=?");
    $q->execute([$id]);
    $antes = $q->fetch(PDO::FETCH_ASSOC);
    if (!$antes) redir_cfg($cfg['retorno'], 'erro', 'Registo não encontrado.');

    // Dependências conhecidas também são verificadas mesmo quando a BD antiga não tem FK.
    $dependencias = [
        'ramo' => [['dados_servico','id_ramo'],['unidades','id_ramo'],['equipamentos','id_ramo'],['utilizador_ramo','id_ramo']],
        'regioes' => [['unidades','id_regiao'],['dados_servico','id_regiao'],['equipamentos','id_regiao'],['utilizador_regiao','id_regiao']],
        'unidades' => [['dados_servico','id_unidade'],['equipamentos','id_unidade'],['utilizador_unidade','id_unidade']],
        'patentes' => [['dados_servico','id_patente']],
        'funcoes' => [['dados_servico','id_funcao']],
        'quadros_servico' => [['especialistas','id_quadro']],
        'tipos_formacao' => [['formacoes','id_tipo_formacao']],
        'instituicoes' => [['formacoes','id_instituicao'],['habilitacoes_literarias','id_instituicao']],
        'tipos_licenca' => [['licencas','id_tipo_licenca']],
        'tipos_documento' => [['documentos','id_tipo_documento'],['solicitacoes','id_tipo_documento']],
        'modelos_solicitacao' => [['solicitacoes','id_modelo']],
        'situacoes_servico' => [['dados_servico','id_situacao_servico']],
    ];
    $ignorar = $tabela === 'regioes' ? ['regiao_provincias'] : [];
    $refs = [];
    foreach (($dependencias[$tabela] ?? []) as $dep) {
        [$dt,$dc] = $dep;
        $check = $pdo->prepare("SELECT COUNT(*) FROM `{$dt}` WHERE `{$dc}`=?");
        try { $check->execute([$id]); $n=(int)$check->fetchColumn(); } catch (Throwable $ignore) { $n=0; }
        if ($n>0) $refs[]=$dt.' ('.$n.')';
    }
    $stmt = $pdo->prepare("SELECT TABLE_NAME,COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE CONSTRAINT_SCHEMA=DATABASE() AND REFERENCED_TABLE_NAME=? AND REFERENCED_COLUMN_NAME=? AND TABLE_NAME<>?");
    $stmt->execute([$tabela,$pk,$tabela]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $ref) {
        if (in_array($ref['TABLE_NAME'],$ignorar,true)) continue;
        $st = $pdo->prepare("SELECT COUNT(*) FROM `{$ref['TABLE_NAME']}` WHERE `{$ref['COLUMN_NAME']}`=?");
        $st->execute([$id]);
        $n=(int)$st->fetchColumn();
        if ($n>0) $refs[]=$ref['TABLE_NAME'].' ('.$n.')';
    }
    if ($refs) {
        redir_cfg($cfg['retorno'], 'erro', 'Não é possível eliminar '.$cfg['rotulo'].' porque existem dados dependentes: '.implode(', ',$refs).'. Inative o registo para preservar o histórico.');
    }

    $pdo->beginTransaction();
    if ($tabela === 'regioes') $pdo->prepare('DELETE FROM regiao_provincias WHERE id_regiao=?')->execute([$id]);
    $pdo->prepare("DELETE FROM `{$tabela}` WHERE `{$pk}`=?")->execute([$id]);
    if ($tabela === 'modelos_solicitacao') {
        $dir = app_public_path('uploads/modelos_documentos');
        foreach (['docx','html','htm','txt'] as $ext) @unlink($dir . DIRECTORY_SEPARATOR . 'modelo_' . $id . '.' . $ext);
    }
    registar_historico($pdo,$tabela,$id,'ELIMINACAO',$antes,null);
    registar_auditoria($pdo,'CONFIGURACAO','ELIMINACAO','CONFIGURACOES',$tabela,$id,'Registo eliminado pela interface de configurações.',$antes,null);
    $pdo->commit();
    redir_cfg($cfg['retorno'], 'sucesso', ucfirst($cfg['rotulo']).' eliminado com sucesso.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    redir_cfg($cfg['retorno'], 'erro', 'Não foi possível eliminar: '.$e->getMessage());
}
