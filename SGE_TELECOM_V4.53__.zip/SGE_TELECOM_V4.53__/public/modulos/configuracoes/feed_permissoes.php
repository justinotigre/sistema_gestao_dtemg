<?php
require_once __DIR__.'/../../../app/auth.php';
require_login(); require_permission('CONFIGURACOES_VISUALIZAR');
$pdo=db(); $erro=''; $sucesso='';
try {
 // Recuperação compatível: evita erro fatal se a migração v4.21 ainda não foi aplicada.
 $pdo->exec("CREATE TABLE IF NOT EXISTS feed_permissoes_perfil (id_perfil INT NOT NULL PRIMARY KEY, pode_ler TINYINT(1) NOT NULL DEFAULT 1, pode_publicar TINYINT(1) NOT NULL DEFAULT 0, pode_submeter TINYINT(1) NOT NULL DEFAULT 1, pode_gerir TINYINT(1) NOT NULL DEFAULT 0, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
 $pdo->exec("INSERT IGNORE INTO feed_permissoes_perfil (id_perfil,pode_ler,pode_publicar,pode_submeter,pode_gerir) SELECT id_perfil,1,CASE WHEN nome LIKE '%ADMINISTRADOR%' THEN 1 ELSE 0 END,1,CASE WHEN nome LIKE '%ADMINISTRADOR%' THEN 1 ELSE 0 END FROM perfis WHERE estado='ATIVO'");

 if($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_verify_post();
  if(!has_permission('UTILIZADORES_EDITAR')) throw new RuntimeException('É necessária a permissão de edição de utilizadores para alterar estas regras.');
  $st=$pdo->prepare('INSERT INTO feed_permissoes_perfil (id_perfil,pode_ler,pode_publicar,pode_submeter,pode_gerir) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE pode_ler=VALUES(pode_ler),pode_publicar=VALUES(pode_publicar),pode_submeter=VALUES(pode_submeter),pode_gerir=VALUES(pode_gerir)');
  foreach((array)($_POST['perfil']??[]) as $id=>$v) $st->execute([(int)$id,isset($v['ler'])?1:0,isset($v['publicar'])?1:0,isset($v['submeter'])?1:0,isset($v['gerir'])?1:0]);
  $sucesso='Permissões do Feed guardadas.';
 }
 $perfis=$pdo->query("SELECT p.id_perfil,p.nome,p.descricao,COALESCE(f.pode_ler,1) pode_ler,COALESCE(f.pode_publicar,0) pode_publicar,COALESCE(f.pode_submeter,1) pode_submeter,COALESCE(f.pode_gerir,0) pode_gerir FROM perfis p LEFT JOIN feed_permissoes_perfil f ON f.id_perfil=p.id_perfil WHERE p.estado='ATIVO' ORDER BY p.nome")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) { $erro='Não foi possível preparar as permissões do Feed. Verifique se o utilizador da base de dados pode criar/alterar tabelas e execute database/migracao_v4_21_feed_permissoes_oportunidades.sql. Detalhe: '.$e->getMessage(); $perfis=$perfis??[]; }
$page_title='Permissões do Feed'; require __DIR__.'/../../layout/header.php';
?>
<div class="module-page"><main class="page"><div class="page-header"><div><h1>Permissões do Feed</h1><p>Defina por perfil quem pode ler, publicar, submeter especialistas e gerir publicações.</p></div></div>
<?php if($erro): ?><div class="alert alert-danger"><?=htmlspecialchars($erro)?></div><?php endif; ?><?php if($sucesso): ?><div class="alert alert-success"><?=htmlspecialchars($sucesso)?></div><?php endif; ?>
<style>.feed-permissoes-form{padding:12px!important}.feed-permissoes-form .table th,.feed-permissoes-form .table td{padding:7px 10px!important;font-size:12px}.feed-permissoes-form input[type=checkbox]{width:14px;height:14px;margin:0;vertical-align:middle}.feed-permissoes-form .table small{font-size:10px;color:var(--suave)}.feed-permissoes-form .btn{padding:8px 12px;font-size:12px}</style><form method="post" class="panel feed-permissoes-form" style="padding:12px"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><div style="overflow:auto"><table class="table"><thead><tr><th>Perfil</th><th>Ler</th><th>Publicar</th><th>Submeter</th><th>Gerir</th></tr></thead><tbody>
<?php foreach($perfis as $p): ?><tr><td><strong><?=htmlspecialchars($p['nome'])?></strong><br><small><?=htmlspecialchars($p['descricao']??'')?></small></td><?php foreach(['pode_ler'=>'ler','pode_publicar'=>'publicar','pode_submeter'=>'submeter','pode_gerir'=>'gerir'] as $col=>$key): ?><td><input type="checkbox" name="perfil[<?=(int)$p['id_perfil']?>][<?=$key?>]" value="1" <?=((int)$p[$col]===1?'checked':'')?> aria-label="<?=$key?> — <?=htmlspecialchars($p['nome'])?>"></td><?php endforeach; ?></tr><?php endforeach; ?>
</tbody></table></div><div style="margin-top:18px"><button class="btn" type="submit">Guardar permissões</button></div></form></main></div><?php require __DIR__.'/../../layout/footer.php'; ?>
