<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/historico.php';
require_login();
require_permission('CONFIGURACOES_GERIR');
if(($_SESSION['user']['nivel']??'')!=='GLOBAL'){http_response_code(403);die('Acesso restrito ao administrador global.');}
$pdo=db();$msg='';$edit=null;
if(isset($_GET['editar'])){$q=$pdo->prepare('SELECT * FROM funcoes WHERE id_funcao=?');$q->execute([(int)$_GET['editar']]);$edit=$q->fetch(PDO::FETCH_ASSOC);}
if(isset($_GET['sucesso'])) $msg=urldecode((string)$_GET['sucesso']); if(isset($_GET['erro'])) $erro=urldecode((string)$_GET['erro']);
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $acao=$_POST['acao']??'';$id=(int)($_POST['id']??0);$nome=trim($_POST['nome']??'');$desc=trim($_POST['descricao']??'');
  if($acao==='estado'){
   $q=$pdo->prepare('SELECT * FROM funcoes WHERE id_funcao=?');$q->execute([$id]);$antes=$q->fetch(PDO::FETCH_ASSOC);
   if($antes){$novo=$antes['estado']==='ATIVO'?'INATIVO':'ATIVO';$pdo->prepare('UPDATE funcoes SET estado=? WHERE id_funcao=?')->execute([$novo,$id]);$depois=$antes;$depois['estado']=$novo;registar_historico($pdo,'funcoes',$id,$novo==='INATIVO'?'INATIVACAO':'REACTIVACAO',$antes,$depois);$msg='Estado da função atualizado.';}
  } elseif($nome===''){$msg='Informe o nome.';}
  elseif($id){$q=$pdo->prepare('SELECT * FROM funcoes WHERE id_funcao=?');$q->execute([$id]);$antes=$q->fetch(PDO::FETCH_ASSOC);$pdo->prepare('UPDATE funcoes SET nome=?,descricao=? WHERE id_funcao=?')->execute([$nome,$desc?:null,$id]);$q=$pdo->prepare('SELECT * FROM funcoes WHERE id_funcao=?');$q->execute([$id]);$depois=$q->fetch(PDO::FETCH_ASSOC);registar_historico($pdo,'funcoes',$id,'ALTERACAO',$antes,$depois);$msg='Função atualizada.';
  } else {$pdo->prepare('INSERT INTO funcoes(nome,descricao) VALUES(?,?)')->execute([$nome,$desc?:null]);$id=(int)$pdo->lastInsertId();$q=$pdo->prepare('SELECT * FROM funcoes WHERE id_funcao=?');$q->execute([$id]);registar_historico($pdo,'funcoes',$id,'CRIACAO',null,$q->fetch(PDO::FETCH_ASSOC));$msg='Função adicionada.';}
 }catch(Throwable $e){$msg='Não foi possível concluir. A função pode já existir.';}
}
$items=$pdo->query('SELECT id_funcao,nome,descricao,estado FROM funcoes ORDER BY nome')->fetchAll(PDO::FETCH_ASSOC);$page_title='Funções';require __DIR__.'/../../layout/header.php';
?>
<div class="module-page config-crud-page"><main class="page"><div class="page-header"><div><h1>Funções</h1><p>Funções encerradas ou substituídas permanecem preservadas e podem ser consultadas no histórico.</p></div><a class="btn btn-secondary" href="configuracoes.php">← Configurações</a></div><?php if($msg):?><div class="alert-success"><?=htmlspecialchars($msg)?></div><?php endif;?><div class="config-editor-grid"><section class="panel form-box"><h2><?=$edit?'Editar função':'Nova função'?></h2><form method="post" class="form-grid">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="id" value="<?= (int)($edit['id_funcao']??0) ?>"><div class="form-group full"><label>Nome *</label><input name="nome" required value="<?=htmlspecialchars($edit['nome']??'')?>"></div><div class="form-group full"><label>Descrição</label><textarea name="descricao" rows="3"><?=htmlspecialchars($edit['descricao']??'')?></textarea></div><div class="actions full"><button class="btn btn-primary">Guardar</button><?php if($edit):?><a class="btn btn-secondary" href="funcoes.php">Cancelar</a><?php endif;?></div></form></section><section class="panel table-wrap"><table><thead><tr><th>Função</th><th>Estado</th><th>Ações</th></tr></thead><tbody><?php foreach($items as $i):?><tr><td><strong><?=htmlspecialchars($i['nome'])?></strong><br><small><?=htmlspecialchars($i['descricao']?:'')?></small></td><td><?=htmlspecialchars($i['estado'])?></td><td><a class="btn btn-small btn-secondary" href="funcoes.php?editar=<?=$i['id_funcao']?>">Editar</a> <form method="post" style="display:inline">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="acao" value="estado"><input type="hidden" name="id" value="<?=$i['id_funcao']?>"><button class="btn btn-small <?= $i['estado']==='ATIVO'?'btn-danger':'btn-success' ?>"><?= $i['estado']==='ATIVO'?'Encerrar / Inativar':'Reativar' ?></button></form> <form method="post" action="configuracao_eliminar.php" style="display:inline" onsubmit="return confirm('Eliminar esta função? Só será possível se não houver dados associados.');"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8')?>"><input type="hidden" name="tabela" value="funcoes"><input type="hidden" name="id" value="<?=$i['id_funcao']?>"><button class="btn btn-small btn-secondary">Eliminar</button></form></td></tr><?php endforeach;?></tbody></table></section></div></main></div><?php require __DIR__.'/../../layout/footer.php';?>
