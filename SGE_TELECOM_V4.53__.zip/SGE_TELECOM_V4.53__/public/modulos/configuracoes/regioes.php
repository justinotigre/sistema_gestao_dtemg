<?php
require_once __DIR__.'/../../../app/auth.php';
require_once __DIR__.'/../../../app/historico.php';
require_login(); require_permission('REGIOES_GERIR');
$pdo=db(); $msg=''; $erro=''; $edit=null;
if(isset($_GET['editar'])){ $q=$pdo->prepare('SELECT * FROM regioes WHERE id_regiao=?'); $q->execute([(int)$_GET['editar']]); $edit=$q->fetch(PDO::FETCH_ASSOC); }
$provinciasAtivas=$pdo->query("SELECT id_provincia,nome FROM provincias WHERE estado='ATIVO' ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$provinciasSelecionadas=[]; if($edit){$q=$pdo->prepare('SELECT id_provincia FROM regiao_provincias WHERE id_regiao=?');$q->execute([(int)$edit['id_regiao']]);$provinciasSelecionadas=array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));}
if(isset($_GET['sucesso'])) $msg=urldecode((string)$_GET['sucesso']); if(isset($_GET['erro'])) $erro=urldecode((string)$_GET['erro']);
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $acao=$_POST['acao']??''; $id=(int)($_POST['id']??0);
  if($acao==='estado'){
   $q=$pdo->prepare('SELECT * FROM regioes WHERE id_regiao=?');$q->execute([$id]);$a=$q->fetch(PDO::FETCH_ASSOC);
   if($a){$n=$a['estado']==='ATIVO'?'INATIVO':'ATIVO';$pdo->prepare('UPDATE regioes SET estado=? WHERE id_regiao=?')->execute([$n,$id]);$d=$a;$d['estado']=$n;registar_historico($pdo,'regioes',$id,$n==='INATIVO'?'INATIVACAO':'REACTIVACAO',$a,$d);$msg='Estado da região atualizado.';}
  } elseif($acao==='eliminar'){
   $q=$pdo->prepare('SELECT * FROM regioes WHERE id_regiao=?');$q->execute([$id]);$a=$q->fetch(PDO::FETCH_ASSOC);
   if(!$a) throw new RuntimeException('Região não encontrada.');
   $n=(int)$pdo->query('SELECT COUNT(*) FROM dados_servico WHERE id_regiao='.(int)$id)->fetchColumn();$e=(int)$pdo->query('SELECT COUNT(*) FROM equipamentos WHERE id_regiao='.(int)$id)->fetchColumn();$u=(int)$pdo->query('SELECT COUNT(*) FROM utilizador_regiao WHERE id_regiao='.(int)$id)->fetchColumn();
   if($n||$e||$u) throw new RuntimeException('A região não pode ser eliminada porque ainda possui especialistas, equipamentos ou utilizadores associados. Inative-a ou remova primeiro as associações.');
   $pdo->prepare('DELETE FROM regioes WHERE id_regiao=?')->execute([$id]);registar_auditoria($pdo,'CONFIGURACAO','ELIMINACAO','CONFIGURACOES','regioes',$id,'Região eliminada.', $a, null);$msg='Região eliminada.';
  } else {
   $nome=trim($_POST['nome']??'');$sigla=trim($_POST['sigla']??'');$desc=trim($_POST['descricao']??'');
   if($nome==='') throw new RuntimeException('Informe o nome da região.');
   if($id){$q=$pdo->prepare('SELECT * FROM regioes WHERE id_regiao=?');$q->execute([$id]);$a=$q->fetch(PDO::FETCH_ASSOC);$pdo->prepare('UPDATE regioes SET nome=?,sigla=?,descricao=? WHERE id_regiao=?')->execute([$nome,$sigla?:null,$desc?:null,$id]);$q=$pdo->prepare('SELECT * FROM regioes WHERE id_regiao=?');$q->execute([$id]);registar_historico($pdo,'regioes',$id,'ALTERACAO',$a,$q->fetch(PDO::FETCH_ASSOC));$msg='Região atualizada.';}
   else{$pdo->prepare('INSERT INTO regioes(nome,sigla,descricao) VALUES(?,?,?)')->execute([$nome,$sigla?:null,$desc?:null]);$id=(int)$pdo->lastInsertId();$q=$pdo->prepare('SELECT * FROM regioes WHERE id_regiao=?');$q->execute([$id]);registar_historico($pdo,'regioes',$id,'CRIACAO',null,$q->fetch(PDO::FETCH_ASSOC));$msg='Região criada.';}
   if($id){
    $pdo->prepare('DELETE FROM regiao_provincias WHERE id_regiao=?')->execute([$id]);
    $ins=$pdo->prepare('INSERT INTO regiao_provincias(id_regiao,id_provincia) VALUES(?,?)');
    foreach(($_POST['provincias']??[]) as $pid){$pid=(int)$pid;if($pid>0)$ins->execute([$id,$pid]);}
   }
   $edit=null;
  }
 }catch(Throwable $e){$erro='Não foi possível concluir. O nome/sigla pode já existir.';}
}
$regioes=$pdo->query('SELECT * FROM regioes ORDER BY nome')->fetchAll(PDO::FETCH_ASSOC);
$provs=$pdo->query("SELECT p.id_provincia,p.nome,rp.id_regiao FROM provincias p LEFT JOIN regiao_provincias rp ON rp.id_provincia=p.id_provincia WHERE p.estado='ATIVO' ORDER BY p.nome")->fetchAll(PDO::FETCH_ASSOC);
$page_title='Regiões'; require __DIR__.'/../../layout/header.php';
?>
<div class="module-page config-crud-page"><div class="page"><div class="page-header"><div><span class="config-kicker">ORGANIZAÇÃO</span><h1>Regiões</h1><p>Crie, altere e associe as províncias que pertencem a cada região.</p></div><a class="btn btn-secondary" href="configuracoes.php">← Configurações</a></div>
<?php if($msg):?><div class="alert-success"><?=htmlspecialchars($msg)?></div><?php endif;?><?php if($erro):?><div class="alert-error"><?=htmlspecialchars($erro)?></div><?php endif;?>
<div class="config-editor-grid"><section class="panel form-box"><h2><?=$edit?'Editar região':'Nova região'?></h2><form method="post"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="acao" value="guardar"><input type="hidden" name="id" value="<?= (int)($edit['id_regiao']??0) ?>"><div class="form-group"><label>Nome</label><input name="nome" required value="<?=htmlspecialchars($edit['nome']??'')?>"></div><div class="form-group"><label>Sigla</label><input name="sigla" maxlength="30" value="<?=htmlspecialchars($edit['sigla']??'')?>"></div><div class="form-group full"><label>Descrição</label><textarea name="descricao"><?=htmlspecialchars($edit['descricao']??'')?></textarea></div><div class="form-group full"><label>Províncias da região</label><select name="provincias[]" multiple size="10" style="min-height:220px"><?php foreach($provinciasAtivas as $pv):?><option value="<?=$pv['id_provincia']?>" <?=in_array((int)$pv['id_provincia'],$provinciasSelecionadas,true)?'selected':''?>><?=htmlspecialchars($pv['nome'])?></option><?php endforeach;?></select><small>Ctrl + clique permite selecionar várias províncias.</small></div><div class="actions"><button class="btn btn-primary">Guardar</button><?php if($edit):?><a class="btn btn-secondary" href="regioes.php">Cancelar</a><?php endif;?></div></form></section>
<section class="panel"><h2>Regiões cadastradas</h2><div class="table-wrap"><table><thead><tr><th>Região</th><th>Sigla</th><th>Províncias</th><th>Estado</th><th>Ações</th></tr></thead><tbody><?php foreach($regioes as $r): $nomes=[];foreach($provs as $pv)if((int)$pv['id_regiao']===(int)$r['id_regiao'])$nomes[]=$pv['nome'];?><tr><td><strong><?=htmlspecialchars($r['nome'])?></strong></td><td><?=htmlspecialchars($r['sigla']??'—')?></td><td><?=htmlspecialchars($nomes?implode(', ',$nomes):'Nenhuma associada')?></td><td><?=htmlspecialchars($r['estado'])?></td><td class="actions"><a class="btn btn-secondary" href="regioes.php?editar=<?=$r['id_regiao']?>">Editar</a><form method="post" style="display:inline"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="acao" value="estado"><input type="hidden" name="id" value="<?=$r['id_regiao']?>"><button class="btn btn-secondary"><?=$r['estado']==='ATIVO'?'Inativar':'Reativar'?></button></form> <form method="post" style="display:inline" onsubmit="return confirm('Eliminar esta região? A eliminação só será permitida se não houver dados associados.');"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="acao" value="eliminar"><input type="hidden" name="id" value="<?=$r['id_regiao']?>"><button class="btn btn-secondary">Eliminar</button></form></td></tr><?php endforeach;?></tbody></table></div></section></div></div></div><?php require __DIR__.'/../../layout/footer.php'; ?>
