<?php
require_once __DIR__ . '/../../../app/auth.php';
require_login();
require_permission('CONFIGURACOES_VISUALIZAR');
header('Location: formacoes.php');
exit;
